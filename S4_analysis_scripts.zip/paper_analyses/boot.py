import pandas as pd, numpy as np, json, sys
from scipy.optimize import minimize
from scipy.stats import norm, binom
D=pd.read_csv(sys.argv[1],low_memory=False)
D=D[D.nonconverged!=1]
ORD={'none':0,'slight':1,'moderate':2,'extensive':3,'complete':4,'collapse':5}
D['lvl']=D.system_damage_state.map(ORD)
dd=D[[c for c in D.columns if c.startswith('ddrift_')]].max(axis=1)
COL=(D.skipped==1)|(D.completed!=1)|(dd>0.05)
D['lvl']=D['lvl'].clip(upper=4)
D.loc[COL,'lvl']=5
STATES=['slight','moderate','extensive','complete','collapse']
def fit(levels,n,k):
    levels,n,k=map(np.asarray,(levels,n,k)); m=n>0; levels,n,k=levels[m],n[m],k[m]
    def nll(p):
        th,be=np.exp(p); pr=np.clip(norm.cdf(np.log(levels/th)/be),1e-9,1-1e-9)
        return -binom.logpmf(k,n,pr).sum()
    th0=levels[np.argmin(abs(k/n-0.5))]
    r=minimize(nll,[np.log(th0),np.log(0.4)],method='Nelder-Mead'); return np.exp(r.x)
def mat(sub):
    # records x levels matrix of lvl (nan if missing)
    return sub.pivot_table(index='record',columns='sa_t1_g',values='lvl',aggfunc='max')
def fitmat(M,recs=None):
    if recs is not None: M=M.loc[recs]
    lev=M.columns.values.astype(float); out={}
    for i,s in enumerate(STATES,1):
        n=M.notna().sum().values; k=(M>=i).sum().values
        out[s]=fit(lev,n,k)
    return out
rng=np.random.default_rng(1)
NB=int(sys.argv[2]) if len(sys.argv)>2 else 1000
res={}
def boot(M,tag):
    base=fitmat(M); recs=M.index.values; B={s:[] for s in STATES}
    for b in range(NB):
        f=fitmat(M,rng.choice(recs,len(recs)))
        for s in STATES: B[s].append(f[s])
    out={}
    for s in STATES:
        a=np.array(B[s]); out[s]=dict(median=round(base[s][0],3),beta=round(base[s][1],3),
            med_ci=[round(x,3) for x in np.percentile(a[:,0],[5,95])],beta_ci=[round(x,3) for x in np.percentile(a[:,1],[5,95])],
            med_cov=round(np.std(np.log(a[:,0])),3))
    res[tag]=out; return B
Ms={c:mat(D[D.case==c]) for c in D.case.unique()}
# xy matched 33
Ms['xy33']=Ms['xy'].loc[Ms['xyz'].index]
for c in ['xyz','xy33','uniform_kcomm','mse_va1000','mse_va500']: boot(Ms[c],c)
# NF vs FF
S=D.drop_duplicates('record').set_index('record')['set']
for c in ['xyz','xy']:
    for g in ['NF','FF']:
        M=Ms[c]; boot(M.loc[[r for r in M.index if S[r]==g]],f'{c}_{g}')
# paired differences: ratio of medians with same record resample
def paired(a,b,tag):
    A,Bm=Ms[a],Ms[b]; recs=[r for r in A.index if r in Bm.index]; A,Bm=A.loc[recs],Bm.loc[recs]
    fa,fb=fitmat(A),fitmat(Bm); R={s:[] for s in STATES}; Rb={s:[] for s in STATES}
    for i in range(NB):
        rr=rng.choice(recs,len(recs)); x,y=fitmat(A,rr),fitmat(Bm,rr)
        for s in STATES: R[s].append(y[s][0]/x[s][0]); Rb[s].append(y[s][1]-x[s][1])
    res[tag]={s:dict(ratio=round(fb[s][0]/fa[s][0],3),ratio_ci=[round(v,3) for v in np.percentile(R[s],[5,95])],
        p_ratio_gt1=round(np.mean(np.array(R[s])>1),3),dbeta=round(fb[s][1]-fa[s][1],3),dbeta_ci=[round(v,3) for v in np.percentile(Rb[s],[5,95])]) for s in STATES}
paired('xyz','xy33','xy_over_xyz')
paired('uniform_kcomm','mse_va1000','mse1000_over_uniform')
paired('uniform_kcomm','mse_va500','mse500_over_uniform')
# NF vs FF difference (unpaired)
def unp(c):
    M=Ms[c]; nf=[r for r in M.index if S[r]=='NF']; ff=[r for r in M.index if S[r]=='FF']
    R={s:[] for s in STATES}
    for i in range(NB):
        a=fitmat(M,rng.choice(nf,len(nf))); b=fitmat(M,rng.choice(ff,len(ff)))
        for s in STATES: R[s].append(a[s][0]/b[s][0])
    a,b=fitmat(M.loc[nf]),fitmat(M.loc[ff])
    res[f'{c}_NF_over_FF']={s:dict(ratio=round(a[s][0]/b[s][0],3),ratio_ci=[round(v,3) for v in np.percentile(R[s],[5,95])],nNF=len(nf),nFF=len(ff)) for s in STATES}
unp('xyz'); unp('xy')
json.dump(res,open(sys.argv[3],'w'),indent=1)
for k,v in res.items():
    print(k); [print('  ',s,v[s]) for s in STATES]
