"""Sensitivity of the C5/C6 shear-failure fragility to the axial-force terms of the Priestley capacity.
The legs reach net tension at high Sa (axial check, fragility/axial_check.json), so the gravity-load Vp (and Vc) are
not guaranteed. Cases: as used; Vp = 0; Vp = Vc = 0 (all shear from the hoops), for 4 and 2 hoop legs, case xyz.
Run: python shear_no_axial.py <project folder arch-bridge-review>"""
import contextlib, copy, io, json, os, sys
ROOT = sys.argv[1]
sys.path.insert(0, os.path.join(ROOT, "opensees"))
import fragility
out = {}
for legs, f in (("4 legs", os.path.join(ROOT, "fragility", "column_limit_states.json")),
                ("2 legs", os.path.join(ROOT, "paper_analyses", "legs2_bound", "column_limit_states_legs2.json"))):
    L0 = json.load(open(f))
    for tag, zero in (("as used", ()), ("Vp = 0", ("Vp",)), ("Vp = Vc = 0", ("Vp", "Vc"))):
        L = copy.deepcopy(L0)
        for c in ("C5", "C6"):
            for k in zero:
                L[c]["long"]["shear_capacity_mu1"][k] = 0
        tmp = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_ls.json")
        json.dump(L, open(tmp, "w"))
        with contextlib.redirect_stdout(io.StringIO()):
            fragility.main(os.path.join(ROOT, "ida_results"), "xyz", tmp, os.path.join(os.path.dirname(tmp), "_fr"))
        r = json.load(open(os.path.join(os.path.dirname(tmp), "_fr.json")))["states"]["C5/C6 shear failure (Priestley)"]
        out[f"{legs}, {tag}"] = {"median_sa_g": r["median_sa_g"], "beta": r["beta"]}
        print(legs, tag, r["median_sa_g"], r["beta"], flush=True)
json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "shear_no_axial.json"), "w"), indent=1)
