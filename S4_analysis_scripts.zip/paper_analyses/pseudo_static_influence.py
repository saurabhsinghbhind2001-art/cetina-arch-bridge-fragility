"""Nonlinear time history of the fibre model (v3, pinned bearings) for the IDA.
Gravity first (element and nodal masses x g), then uniform excitation from a 3-column record (X long, Y trans, Z vert, m/s2).
Damping: mass-proportional alpha = 0.715 (5 % at T = 0.88 s, as Farahani and the 7-record benchmark). Integration: HHT, alpha = 0.9.
Engineering demand parameters (peaks over the record):
  - column drift ratio in X and Y per column leg (cap node relative to base node, divided by the height)
  - deformation drift in X and Y per leg: chord drift minus the rotation of the base node (damage measure)
  - shear at the base element of every column leg (local y and z, kN) for the shear checks of the short columns
  - arch section curvature about both axes at the two springing sections and the largest anywhere in the arch
  - arch crown and deck crown displacements relative to the ground, measured from the gravity state; residual column drifts
Multi-support: give the .npz of svgm.py instead of the record csv (imposed displacements at every support; case xyz;
committed-stiffness damping; crown displacements relative to the mean springing ground motion).
Run: python nltha.py <record.csv | svgm.npz> <scale> <case: xyz | xy> <out.json> [disp56 | dispspr | dispcol]"""
import json
import os
import sys
import time

import numpy as np

REC, SCALE, CASE, OUT = "x.npz", 1.0, "xyz", "x.json"
# optional "disp56": displacement-based elements in the C5/C6 legs. Used only to repeat runs where the force-based
# elements there fail to converge (their sections go into softening); in converged runs the two agree within 1-2 % on
# drifts, displacements and curvatures, and the disp-based C5/C6 shear is about 10 % higher (check of 24 Oct)
DISP56 = False and len(sys.argv) > 5 and sys.argv[5] in ("disp56", "dispspr", "dispcol")
# optional "dispspr" (implies disp56): displacement-based elements also in the two arch springing elements. Multi-support
# runs only: the differential support motion bends the springings, and the force-based springing element (element 66,
# right springing) fails to find compatible forces at small column drifts (0.2-0.8 %), check of 25 Oct. A
# displacement-based element does not localize, so its end curvature is read without the hinge regularization
DISPSPR = False and len(sys.argv) > 5 and sys.argv[5] in ("dispspr", "dispcol")
# optional "dispcol" (implies dispspr): displacement-based elements in every column leg. Last fallback for
# multi-support runs whose force-based C1 legs fail to converge at small drift (element 111, check of 25 Oct)
DISPCOL = False and len(sys.argv) > 5 and sys.argv[5] == "dispcol"
X_SPR = (118.8 - 140.27 / 2, 118.8 + 140.27 / 2)   # arch springings, as cetina_model.py
sys.argv = ["cetina_model.py", "fibre", "0", "v3", "pinned"]
import openseespy.opensees as _ops

_ELE_MASS = {}
_ELE_TYPE = {}
_element = _ops.element


def _record(*a):
    _ELE_TYPE[a[1]] = a[0]
    if "-mass" in a:
        _ELE_MASS[a[1]] = (a[2], a[3], float(a[a.index("-mass") + 1]))
    if a[0] == "forceBeamColumn":
        ci, cj = _ops.nodeCoord(a[2]), _ops.nodeCoord(a[3])
        if DISP56 and abs(ci[0] - cj[0]) < 1e-6 and abs(ci[1] - cj[1]) < 1e-6 and (DISPCOL or round(ci[0] / 21.6) in (5, 6)):
            a = ("dispBeamColumn",) + tuple(a[1:])
            _ELE_TYPE[a[1]] = "forceBeamColumn"   # still a fibre column for the member lists below
            return _element(*a)
        if DISPSPR and any(abs(c[0] - xs) < 0.05 and abs(c[1]) < 1e-6 for c in (ci, cj) for xs in X_SPR):
            a = ("dispBeamColumn",) + tuple(a[1:])
            _ELE_TYPE[a[1]] = "forceBeamColumn"   # still a fibre arch element for the member lists below
            return _element(*a)
        a = a + ("-iter", 50, 1e-10)   # more element iterations and a 1e-10 element tolerance: the defaults (10, 1e-12) failed in column legs under large cycles (RSN 767 at 0.5 g)
    return _element(*a)


_ops.element = _record
import cetina_model as cm
_ops.element = _element
ops = cm.ops
G = 9.81
t0 = time.time()

# --- members
coord = {n: np.array(ops.nodeCoord(n)) for n in ops.getNodeTags()}
fibre = [e for e, typ in _ELE_TYPE.items() if typ == "forceBeamColumn"]
cols = {}   # (k, side) -> list of elements bottom to top
for e in fibre:
    i, j = ops.eleNodes(e)
    if abs(coord[i][0] - coord[j][0]) < 1e-6 and abs(coord[i][1] - coord[j][1]) < 1e-6:
        k = int(round(coord[i][0] / cm.SPAN_DECK))
        side = "L" if coord[i][1] < 0 else "R"
        cols.setdefault((k, side), []).append(e)
for key in cols:
    cols[key].sort(key=lambda e: coord[ops.eleNodes(e)[0]][2])
arch_set = set(cm.arch_nodes)
arch_els = [e for e in fibre if set(ops.eleNodes(e)) <= arch_set]
arch_els.sort(key=lambda e: coord[ops.eleNodes(e)[0]][0])
spr = {"left": (arch_els[0], 1), "right": (arch_els[-1], 5)}   # springing integration points (Lobatto, 5 points)
col_base = {key: ops.eleNodes(es[0])[0] for key, es in cols.items()}
col_top = {key: ops.eleNodes(es[-1])[1] for key, es in cols.items()}
col_h = {key: coord[col_top[key]][2] - coord[col_base[key]][2] for key in cols}
crown = min(cm.arch_nodes, key=lambda n: abs(coord[n][0] - cm.X_CROWN))
deck_crown = min(cm.deck_nodes, key=lambda n: abs(coord[n][0] - cm.X_CROWN))

# --- gravity with the full (nodal + element) mass
mass = {n: ops.nodeMass(n, 1) for n in coord}
for i, j, m in _ELE_MASS.values():
    L = np.linalg.norm(coord[i] - coord[j])
    mass[i] += 0.5 * m * L
    mass[j] += 0.5 * m * L
ops.constraints("Transformation"); ops.numberer("RCM"); ops.system("UmfPack")
ops.timeSeries("Linear", 1)
ops.pattern("Plain", 1, 1)
for n, m in mass.items():
    if m > 0:
        ops.load(n, 0, 0, -m * G, 0, 0, 0)
ops.test("NormDispIncr", 1e-8, 50); ops.algorithm("Newton")
ops.integrator("LoadControl", 0.1); ops.analysis("Static")
if ops.analyze(10) != 0:
    sys.exit("gravity failed")
ops.loadConst("-time", 0.0)
ops.wipeAnalysis()
grav_u = {n: np.array([ops.nodeDisp(n, k) for k in (1, 2, 3)]) for n in (crown, deck_crown)}
grav_drift = {key: [ops.nodeDisp(col_top[key], d) - ops.nodeDisp(col_base[key], d) for d in (1, 2)] for key in cols}


# --- pseudo-static influence of each support DOF (linear, about the gravity state)
arch_set=set(cm.arch_nodes)
sup = [(n, dof) for n in ops.getFixedNodes() for dof in ops.getFixedDOFs(n) if dof <= 3]
spr_nodes = [n for n in ops.getFixedNodes() if n in arch_set]
base={}
def snap():
    o={}
    ref=np.mean([[ops.nodeDisp(n,k) for k in (1,2,3)] for n in spr_nodes],axis=0)
    o['crown']=np.array([ops.nodeDisp(crown,k) for k in (1,2,3)])-ref
    for key in [(5,'L'),(5,'R'),(6,'L'),(6,'R')]:
        b,tp,h=col_base[key],col_top[key],col_h[key]
        o['ddx%d%s'%key]=(ops.nodeDisp(tp,1)-ops.nodeDisp(b,1))/h-ops.nodeDisp(b,5)
        o['ddy%d%s'%key]=(ops.nodeDisp(tp,2)-ops.nodeDisp(b,2))/h+ops.nodeDisp(b,4)
    for s_,(e,ip) in spr.items():
        d=ops.sectionDeformation(e,ip); o['kv_'+s_]=d[1]; o['kt_'+s_]=d[2]
    return o
b0=snap()
DEL=1e-3
infl={}
ops.constraints("Transformation"); ops.numberer("RCM"); ops.system("UmfPack")
ops.test("NormDispIncr", 1e-8, 100,0); ops.algorithm("Newton")
for n,dof in sup:
    ops.remove("sp",n,dof)
IDX=int(os.environ['IDX']); DEL=float(os.environ.get('DEL','1e-4'))
n,dof=sup[IDX]
ops.timeSeries("Linear",100); ops.pattern("Plain",100,100)
for m,dd in sup: ops.sp(m,dd,DEL if (m,dd)==(n,dof) else 0.0)
ops.integrator("LoadControl",0.1); ops.analysis("Static")
r=ops.analyze(10)
o=snap()
res={k:((o[k]-b0[k])/DEL).tolist() if hasattr(o[k],'tolist') else (o[k]-b0[k])/DEL for k in o}
json.dump(dict(n=n,dof=dof,x=float(coord[n][0]),ok=r,infl=res),open('/tmp/claude-0/ana/infl_%d.json'%IDX,'w'))
print('n_sup',len(sup),IDX,n,dof,r)
