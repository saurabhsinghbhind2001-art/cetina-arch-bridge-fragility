import sys, json, glob, os
P = "/mnt/project-files/arch-bridge-review"; sys.path.insert(0, os.path.join(P, "opensees")); import fragility as F
L = json.load(open(os.path.join(P, "fragility/column_limit_states.json")))
for folder, case in (("ida_results_mse","uniform_kcomm"),("ida_results_mse","mse_va1000"),("ida_results","xyz")):
    first = {}
    for f in sorted(glob.glob(os.path.join(P, folder, case, "*.json"))):
        rec, lv = os.path.basename(f)[:-5].split("_sa"); r = json.load(open(f))
        if not r.get("completed"): continue
        comp, dc = F.component_levels(r, L)
        m = max(v[0] for v in dc.values())
        V = max(abs(0.5*(r["V_long"][f"{c}L"]+r["V_long"][f"{c}R"])) for c in (5,6))
        if m > 1: first.setdefault(rec, []).append((float(lv), round(m,2), round(V), max(comp.values())))
    print(case, {k: sorted(v)[:2] for k, v in first.items()})
