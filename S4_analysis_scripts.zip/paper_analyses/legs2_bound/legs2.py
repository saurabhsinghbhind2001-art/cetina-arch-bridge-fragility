import sys, json, glob, os, copy
P = "/mnt/project-files/arch-bridge-review"
sys.path.insert(0, os.path.join(P, "opensees"))
import fragility as F
L4 = json.load(open(os.path.join(P, "fragility/column_limit_states.json")))
L2 = copy.deepcopy(L4)
for c, v in L2.items():
    if not c.startswith("C"): continue
    for ax in ("long", "trans"):
        for key in ("shear_capacity_mu1", "shear_capacity_mu4"):
            s = v[ax][key]; s["Vs"] /= 2; s["V_EC_truss"] /= 2; s["V"] = s["Vc"] + s["Vs"] + s["Vp"]
json.dump(L2, open("column_limit_states_legs2.json", "w"), indent=1)
cases = [("ida_results", "xyz"), ("ida_results", "xy"), ("ida_results_mse", "uniform_kcomm"), ("ida_results_mse", "mse_va1000"), ("ida_results_mse", "mse_va500")]
res = {}
for folder, case in cases:
    out = {}
    for tag, L in (("legs4", L4), ("legs2", L2)):
        rows = {}
        for f in glob.glob(os.path.join(P, folder, case, "*.json")):
            rec, lv = os.path.basename(f)[:-5].split("_sa")
            r = json.load(open(f))
            dd = max(list(r.get("ddrift_x", {}).values()) + list(r.get("ddrift_y", {}).values()) + [0.0])
            if not r.get("completed") and not r.get("skipped") and dd < F.NUMERICAL_DRIFT: continue
            if r.get("skipped") or not r.get("completed"):
                rows.setdefault(float(lv), []).append((rec, True, None, None)); continue
            drift = max(list(r["ddrift_x"].values()) + list(r["ddrift_y"].values()))
            comp, dc = F.component_levels(r, L)
            rows.setdefault(float(lv), []).append((rec, drift > F.COLLAPSE_DRIFT, comp, dc))
        lv = sorted(rows)
        sh = lambda comp, dc: max(v[0] for v in dc.values()) > 1
        tests = {f"system {ds}": (lambda comp, dc, i=i: max(comp.values()) >= i or sh(comp, dc)) for i, ds in enumerate(F.DS, 1)}
        tests["shear failure"] = sh
        t = {}
        for name, test in tests.items():
            n = [len(rows[l]) for l in lv]
            k = [sum(1 for _, col, comp, dc in rows[l] if col or test(comp, dc)) for l in lv]
            th, be = F.fit(lv, n, k) if 0 < sum(k) < sum(n) else (float("nan"),) * 2
            t[name] = (round(th, 3), round(be, 3))
        # first to fail moderate: shear vs flexure
        out[tag] = t
    res[case] = out
    print(case, json.dumps(out))
json.dump(res, open("legs2_bounds.json", "w"), indent=1)
