"""Results-draft figures: governing component with the matching uniform reference, as-built devices, shear bounds.
Run: python fig_results_extra.py <arch-bridge-review folder>"""
import glob, json, os, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy.stats import norm

ROOT = sys.argv[1]
FR = os.path.join(ROOT, "fragility")
OUT = os.path.join(ROOT, "paper_analyses", "figs")
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9, "axes.titlesize": 10, "axes.labelsize": 9,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": "#e3e3e3",
    "grid.linewidth": 0.6, "axes.axisbelow": True, "legend.frameon": False, "legend.fontsize": 8,
    "xtick.labelsize": 8, "ytick.labelsize": 8, "savefig.bbox": "tight", "savefig.pad_inches": 0.05,
})
DS_C = ["#9ecae1", "#3182bd", "#f39c4a", "#d62728", "#111111"]
DS_L = ["Slight", "Moderate", "Extensive", "Complete", "Collapse"]
X = np.linspace(0.01, 3.6, 500)


def save(fig, name):
    fig.savefig(os.path.join(OUT, name + ".png"), dpi=200)
    fig.savefig(os.path.join(OUT, name + ".pdf"))
    plt.close(fig)
    print("written", name)


def fig_governing():
    groups = [("C5/C6 longitudinal", "#3182bd"), ("Arch springing transverse", "#2a9d8f"),
              ("Arch springing vertical", "#9fd3c7"), ("Other column legs", "#c7c7c7")]
    def grp(k):
        if k in ("C5 long", "C6 long"):
            return 0
        if k == "arch springing transverse":
            return 1
        if k == "arch springing vertical":
            return 2
        return 3
    G = {"Uniform xyz (33)": json.load(open(os.path.join(FR, "fragility_xyz.json")))["governing"],
         "Uniform xy (33)": json.load(open(os.path.join(FR, "fragility_xy_matched33.json")))["governing"],
         "Uniform ref., FB springing": json.load(open(os.path.join(FR, "fragility_uniform_kcomm.json")))["governing"],
         "Uniform ref., DB springing": json.load(open(os.path.join(ROOT, "review_checks", "fragility_uref_dispspr.json")))["governing"],
         "MSE 1000 m/s": json.load(open(os.path.join(FR, "fragility_mse_va1000.json")))["governing"],
         "MSE 500 m/s": json.load(open(os.path.join(FR, "fragility_mse_va500.json")))["governing"]}
    fig, axs = plt.subplots(1, 4, figsize=(7.4, 3.1), sharey=True)
    names = list(G)
    for ax, ds, lab in zip(axs, ["slight", "moderate", "extensive", "complete"], DS_L):
        y = np.arange(len(names))[::-1]
        for yi, c in zip(y, names):
            cnt = np.zeros(4)
            for k, v in G[c][ds].items():
                cnt[grp(k)] += v
            sh = cnt / cnt.sum() * 100
            left = 0
            for g in range(4):
                ax.barh(yi, sh[g], left=left, color=groups[g][1], height=0.7, edgecolor="white", lw=0.8)
                if sh[g] >= 18:
                    ax.text(left + sh[g] / 2, yi, f"{sh[g]:.0f}", ha="center", va="center", fontsize=6.8,
                            color="white" if g in (0, 1) else "#222")
                left += sh[g]
        ax.set_title(lab, loc="left"); ax.set_xlim(0, 100); ax.set_xticks([0, 50, 100]); ax.grid(False)
        ax.set_xlabel("share (%)")
    axs[0].set_yticks(np.arange(len(names))[::-1], names)
    fig.legend(handles=[plt.Rectangle((0, 0), 1, 1, color=c) for _, c in groups], labels=[n for n, _ in groups],
               loc="lower center", ncol=4, bbox_to_anchor=(0.55, -0.08), fontsize=7.5)
    fig.suptitle("First component to reach each damage state (share of first-component counts, ties counted for both)",
                 x=0.01, ha="left", fontsize=9.5)
    fig.tight_layout(rect=(0, 0.05, 1, 1))
    save(fig, "figR_governing_component")


def fig_asbuilt():
    d = json.load(open(os.path.join(ROOT, "paper_analyses", "asbuilt", "asbuilt_final_results.json")))
    runs = []
    for f in glob.glob(os.path.join(ROOT, "ida_results_asbuilt", "asbuilt_final", "*.json")):
        r = json.load(open(f))
        if "damper_force_kN" in r:
            r["_lv"] = float(os.path.basename(f)[:-5].split("_sa")[1])
            runs.append(r)
    fig, axs = plt.subplots(1, 3, figsize=(7.4, 3.0), gridspec_kw=dict(width_ratios=[1.3, 1, 1]))
    ax = axs[0]
    for i, s in enumerate(["slight", "moderate", "extensive", "complete", "collapse"]):
        for case, ls in (("bare", "-"), ("asbuilt", "--")):
            t = d[case][s]
            ax.plot(X, norm.cdf(np.log(X / t["median"]) / t["beta"]), color=DS_C[i], ls=ls, lw=1.7)
    ax.legend(handles=[Line2D([], [], color="k", ls="-", label="Bare"), Line2D([], [], color="k", ls="--", label="As built")]
              + [Line2D([], [], color=DS_C[i], lw=3, label=DS_L[i]) for i in range(5)], fontsize=6.6, loc="lower right")
    ax.set_xlim(0, 3.6); ax.set_ylim(0, 1.02); ax.set_xlabel("Sa(T1) (g)"); ax.set_ylabel("P(DS ≥ ds | Sa)")
    ax.set_title("(a) Fragility, 10 records", loc="left")
    lv = sorted({r["_lv"] for r in runs})
    for ax, key, sc, lab, ttl in ((axs[1], "damper_force_kN", 1e-3, "Peak damper force (MN)", "(b) Abutment damper"),
                                  (axs[2], "fuse_slip_m", 1.0, "Peak C5 bearing slip (m)", "(c) C5 fuse bearing")):
        for r in runs:
            ax.plot(r["_lv"], r[key] * sc, ".", color="#6b6b6b", ms=2.5, alpha=0.4)
        ax.plot(lv, [np.median([r[key] * sc for r in runs if r["_lv"] == l]) for l in lv], "-o", color="#1f4e79", ms=3, lw=1.6)
        ax.set_xlabel("Sa(T1) (g)"); ax.set_ylabel(lab); ax.set_title(ttl, loc="left")
    axs[1].axhline(4.0, color="#d62728", lw=0.9, ls="--"); axs[1].text(3.0, 3.75, "4 MN rating", ha="right", fontsize=7, color="#d62728")
    axs[2].axvline(0.12, color="#d62728", lw=0.9, ls="--"); axs[2].text(0.17, 0.42, "95-yr Sa", fontsize=7, color="#d62728")
    fig.subplots_adjust(wspace=0.45)
    save(fig, "figR_asbuilt_devices")


def fig_shear():
    rows = [("Flexure: moderate (XYZ)", 0.77, "#3182bd"), ("Flexure: complete (XYZ)", 1.67, "#d62728"),
            ("Collapse (XYZ)", 2.37, "#111111"),
            ("Shear, 4 legs (any Vp, Vc)", 2.37, "#9ecae1"),
            ("Shear, 2 legs", 0.62, "#f39c4a"), ("Shear, 2 legs, Vp = 0", 0.44, "#f39c4a"),
            ("Shear, 2 legs, Vp = Vc = 0", 0.28, "#f39c4a")]
    p50 = {"Shear, 2 legs": "2.1 %", "Shear, 2 legs, Vp = 0": "4.5 %", "Shear, 2 legs, Vp = Vc = 0": "13 %"}
    fig, ax = plt.subplots(figsize=(6.4, 2.8))
    y = np.arange(len(rows))[::-1]
    for yi, (n, v, c) in zip(y, rows):
        ax.barh(yi, v, color=c, height=0.62)
        ax.text(v + 0.04, yi, f"{v:.2f} g" + ("  (no shear failure before collapse)" if "4 legs" in n else "")
                + (f"  · 50-yr {p50[n]}" if n in p50 else ""), va="center", fontsize=7.2)
    ax.set_yticks(y, [r[0] for r in rows]); ax.set_xlim(0, 3.6); ax.grid(axis="y", visible=False)
    ax.set_xlabel("Median Sa(T1) (g)"); ax.set_title("C5/C6 shear bounds against the flexural medians", loc="left")
    save(fig, "figR_shear_bounds")


fig_governing()
fig_asbuilt()
fig_shear()
