"""Fig. geometry: (a) elevation with column numbering (existing fig01), (b) column leg section, (c) arch box section,
(d) as-built devices. Dimensions from Farahani and Maalek (2017) Figs 3-4 and Zderic et al. (2007)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from matplotlib.patches import Rectangle, FancyArrowPatch
ROOT = "/mnt/project-files/arch-bridge-review/figures/"
C, E = "#334155", "#94a3b8"
fig = plt.figure(figsize=(11, 6.6))
ax = fig.add_axes([0.0, 0.40, 1.0, 0.60]); ax.imshow(mpimg.imread(ROOT + "fig01_bridge_elevation.png")); ax.axis("off")
ax.text(0.01, 0.97, "(a)", transform=ax.transAxes, fontsize=12, weight="bold", va="top")

def box(a, B, H, t, label, tag, tw=None):
    tw = tw or t
    a.add_patch(Rectangle((0, 0), B, H, fc=E, ec=C, lw=1.2))
    a.add_patch(Rectangle((tw, t), B - 2 * tw, H - 2 * t, fc="white", ec=C, lw=1.0))
    a.set_xlim(-0.35 * B, 1.35 * B); a.set_ylim(-0.45 * H, 1.75 * H); a.set_aspect("equal"); a.axis("off")
    a.annotate("", (0, -0.18 * H), (B, -0.18 * H), arrowprops=dict(arrowstyle="<->", color=C))
    a.text(B / 2, -0.32 * H, f"{B} m", ha="center", va="center", fontsize=9)
    a.annotate("", (-0.12 * B, 0), (-0.12 * B, H), arrowprops=dict(arrowstyle="<->", color=C))
    a.text(-0.2 * B, H / 2, f"{H} m", ha="center", va="center", rotation=90, fontsize=9)
    a.text(B / 2, 1.18 * H, label, ha="center", fontsize=9)
    a.text(-0.33 * B, 1.72 * H, tag, fontsize=12, weight="bold", va="top")

box(fig.add_axes([0.02, 0.02, 0.24, 0.36]), 1.5, 1.8, 0.3,
    "column leg C1, C3-C8\nwalls 0.3 m, 4 % long. steel,\nhoops Φ14 @ 100 mm", "(b)")
box(fig.add_axes([0.27, 0.02, 0.36, 0.36]), 8.0, 2.5, 0.4,
    "arch box C45/55\nwebs 0.5 m, chords 0.4-0.6 m", "(c)", tw=0.5)
a = fig.add_axes([0.65, 0.02, 0.34, 0.36]); a.axis("off"); a.set_xlim(0, 10); a.set_ylim(0, 10)
a.text(0.0, 9.6, "(d)", fontsize=12, weight="bold", va="top")
a.add_patch(Rectangle((0.6, 1.0), 1.4, 5.0, fc="#e7e5e4", ec=C)); a.text(1.3, 0.4, "abutment", ha="center", fontsize=8)
a.add_patch(Rectangle((4.2, 4.6), 5.6, 0.9, fc=C, ec=C)); a.text(7.0, 5.9, "deck end", ha="center", fontsize=8)
for y in (4.85, 5.25):
    a.plot([2.0, 2.6], [y, y], color=C); a.add_patch(Rectangle((2.6, y - 0.13), 1.0, 0.26, fc="#2a9d8f", ec=C))
    a.plot([3.6, 4.2], [y, y], color=C)
a.text(4.6, 7.4, "2 × 2000 kN viscous dampers\nper abutment, F = 195 v^0.4\n(kN, mm/s; Farahani and Maalek 2017)", ha="center", fontsize=8, color="#1f7a70")
a.add_patch(Rectangle((5.4, 1.0), 1.0, 2.2, fc=E, ec=C)); a.add_patch(Rectangle((5.2, 3.2), 1.4, 0.35, fc="#d62828", ec=C))
a.text(7.0, 2.4, "C5 fuse bearings:\nfixed up to 1000 kN,\nthen longitudinally\nmovable", fontsize=8, color="#b01e1e", va="center")
for ext in ("png", "pdf"):
    fig.savefig(f"fig_geometry.{ext}", dpi=200)
print("ok")
