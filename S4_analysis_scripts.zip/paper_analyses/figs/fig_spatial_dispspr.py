"""Manuscript Fig. 4 and Fig. 5 with the uniform reference rerun on displacement-based springings.
Run: python fig_spatial_dispspr.py <arch-bridge-review folder>"""
import glob, json, os, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy.stats import norm

ROOT = sys.argv[1]
FR = os.path.join(ROOT, "fragility")
OUT = os.path.join(ROOT, "paper_analyses", "figs")
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9, "axes.titlesize": 10, "axes.labelsize": 9,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": "#e3e3e3",
    "grid.linewidth": 0.6, "axes.axisbelow": True, "legend.frameon": False, "legend.fontsize": 8,
    "xtick.labelsize": 8, "ytick.labelsize": 8, "savefig.bbox": "tight", "savefig.pad_inches": 0.05,
})
CASE_C = {"xyz": "#1f4e79", "xy": "#e08a2b", "uref": "#6b6b6b", "mse_va1000": "#2a9d8f", "mse_va500": "#c0392b"}
CASE_L = {"xyz": "Uniform xyz (33 rec.)", "xy": "Uniform xy (33 rec.)", "uref": "Uniform reference (10 rec.)",
          "mse_va1000": "Multi-support, 1000 m/s", "mse_va500": "Multi-support, 500 m/s"}
DS_C = ["#9ecae1", "#3182bd", "#f39c4a", "#d62728", "#111111"]
DS_L = ["Slight", "Moderate", "Extensive", "Complete", "Collapse"]
STATES = ["system slight", "system moderate", "system extensive", "system complete", "collapse"]
F = {"xyz": json.load(open(os.path.join(FR, "fragility_xyz.json"))),
     "xy": json.load(open(os.path.join(FR, "fragility_xy_matched33.json"))),
     "uref": json.load(open(os.path.join(ROOT, "review_checks", "fragility_uref_dispspr.json"))),
     "mse_va1000": json.load(open(os.path.join(FR, "fragility_mse_va1000.json"))),
     "mse_va500": json.load(open(os.path.join(FR, "fragility_mse_va500.json")))}
L = json.load(open(os.path.join(FR, "column_limit_states.json")))
X = np.linspace(0.01, 3.6, 500)
DIRS = {"uref": os.path.join(ROOT, "review_checks", "uniform_kcomm_dispspr"),
        "mse_va1000": os.path.join(ROOT, "ida_results_mse", "mse_va1000"),
        "mse_va500": os.path.join(ROOT, "ida_results_mse", "mse_va500")}


def save(fig, name):
    fig.savefig(os.path.join(OUT, name + ".png"), dpi=200)
    fig.savefig(os.path.join(OUT, name + ".pdf"))
    plt.close(fig)
    print("written", name)


def state(c, s):
    t = F[c]["states"].get(s) or F[c]["states"][s.replace("system ", "")]
    return t["median_sa_g"], t["beta"]


def runs(case):
    out = []
    for f in glob.glob(os.path.join(DIRS[case], "*.json")):
        rec, lv = os.path.basename(f)[:-5].split("_sa")
        r = json.load(open(f))
        r["_rec"], r["_lv"] = rec, float(lv)
        dd = max(list(r.get("ddrift_x", {}).values()) + list(r.get("ddrift_y", {}).values()) + [0.0])
        num = bool(r.get("nonconverged")) or (not r.get("completed") and not r.get("skipped") and dd < 0.02)
        r["_col"] = not num and (r.get("skipped") or not r.get("completed") or dd > 0.05)
        out.append(r)
    return out


def fig4():
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.4))
    for ax, cs, title in ((axs[0], [("xyz", "-"), ("xy", "--")], "(a) Vertical component, 33 records"),
                          (axs[1], [("uref", "-"), ("mse_va1000", "--"), ("mse_va500", ":")], "(b) Spatial variation, 10 records")):
        for i, s in enumerate(STATES):
            for c, ls in cs:
                th, be = state(c, s)
                ax.plot(X, norm.cdf(np.log(X / th) / be), color=DS_C[i], ls=ls, lw=1.7)
        h = [Line2D([], [], color="k", ls=ls, label=CASE_L[c]) for c, ls in cs]
        ax.legend(handles=h, loc="upper left", bbox_to_anchor=(0.0, 0.93), fontsize=7)
        ax.set_xlim(0, 3.6); ax.set_ylim(0, 1.02); ax.set_xlabel("Sa(T1) (g)"); ax.set_title(title, loc="left")
    axs[0].set_ylabel("P(DS ≥ ds | Sa)")
    fig.legend(handles=[Line2D([], [], color=DS_C[i], lw=3, label=DS_L[i]) for i in range(5)],
               loc="lower center", ncol=5, bbox_to_anchor=(0.5, -0.06), fontsize=7.5)
    fig.tight_layout(rect=(0, 0.04, 1, 1))
    save(fig, "fig4_fragility_input_cases")


def fig5():
    A = L["arch_springing"]
    ky = A["transverse"]["curvature_1pm"]["slight"]
    def kreg(r):   # regularized as in fragility.py; displacement-based springings are read raw
        k = max(r["springing_curv_trans_1pm"].values())
        return k if (k <= ky or r.get("dispspr")) else ky + (k - ky) * A["ip_weight_m"] / A["hinge_length_m"]["transverse"]
    c56 = lambda r: max(r["ddrift_x"][k] for k in ("5L", "5R", "6L", "6R")) * 100
    fig, axs = plt.subplots(1, 3, figsize=(7.4, 3.0))
    med = {}
    for c in ("uref", "mse_va1000", "mse_va500"):
        rr = [r for r in runs(c) if r.get("completed")]   # runs completed at the level, including those beyond the collapse drift
        lv = sorted({r["_lv"] for r in rr})
        cr = [np.median([abs(r["crown_rel_m"][2]) for r in rr if r["_lv"] == l]) for l in lv]
        dc = [np.median([c56(r) for r in rr if r["_lv"] == l]) for l in lv]
        ku = [np.median([kreg(r) / ky for r in rr if r["_lv"] == l]) for l in lv]
        med[c] = {l: (a, b, d) for l, a, b, d in zip(lv, cr, dc, ku)}
        for r in rr:
            axs[0].plot(r["_lv"], abs(r["crown_rel_m"][2]), ".", color=CASE_C[c], ms=2.5, alpha=0.35)
            axs[1].plot(r["_lv"], c56(r), ".", color=CASE_C[c], ms=2.5, alpha=0.35)
            axs[2].plot(r["_lv"], kreg(r) / ky, ".", color=CASE_C[c], ms=2.5, alpha=0.35)
        axs[0].plot(lv, cr, "-o", color=CASE_C[c], ms=3, lw=1.6, label=CASE_L[c])
        axs[1].plot(lv, dc, "-o", color=CASE_C[c], ms=3, lw=1.6)
        axs[2].plot(lv, ku, "-o", color=CASE_C[c], ms=3, lw=1.6)
    for i, ds in enumerate(["slight", "moderate", "extensive", "complete"]):
        v = L["C5"]["long"]["drift"][ds] * 100
        axs[1].axhline(v, color=DS_C[i], lw=0.9, ls="--"); axs[1].text(0.05, v, DS_L[i], fontsize=7, color=DS_C[i], va="bottom")
        v = A["transverse"]["curvature_1pm"][ds] / ky
        axs[2].axhline(v, color=DS_C[i], lw=0.9, ls="--"); axs[2].text(0.05, v, DS_L[i], fontsize=7, color=DS_C[i], va="top" if ds == "extensive" else "bottom")
    axs[0].set_ylabel("Crown vertical displacement (m)"); axs[0].set_title("(a) Crown vertical", loc="left")
    axs[0].legend(fontsize=6.8, loc="upper center", bbox_to_anchor=(1.75, -0.2), ncol=3)
    axs[1].set_ylim(0, 5); axs[1].set_ylabel("C5/C6 longitudinal drift (%)"); axs[1].set_title("(b) C5/C6 drift", loc="left")
    axs[2].set_yscale("log"); axs[2].set_ylabel("Springing curvature / yield"); axs[2].set_title("(c) Springing transverse", loc="left")
    for ax in axs:
        ax.set_xlabel("Sa(T1) (g)")
    fig.subplots_adjust(wspace=0.42)
    save(fig, "fig5_crown_springing_demand")
    for c in med:
        print(c, "1.8 g: crown %.2f m, C5/C6 drift %.2f %%, spr trans %.1f x yield" % med[c].get(1.8, (np.nan,) * 3))


fig4()
fig5()
