"""As-built IDA driver: the reference uniform 3-component case (10 far-field records, 14 Sa(T1) levels,
committed-stiffness damping) re-run with the as-built seismic devices switched on (AS_BUILT=1 in cetina_model.py):
two 2000 kN viscous dampers per abutment (damper V of Farahani and Maalek 2017) and the longitudinal fuse bearings on C5.
Same climbing, fallbacks and collapse / numerical-failure reading as run_mse.py, so the output is directly
comparable with the uniform_kcomm case.
Run: python run_asbuilt.py <project folder arch-bridge-review> [workers]"""
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import json
from concurrent.futures import ProcessPoolExecutor, as_completed
import run_mse


def main(root, workers=None, case="asbuilt", env=None):
    gm = os.path.join(root, "ground_motions")
    out = os.path.join(root, "ida_results_asbuilt")
    recs = {r["name"]: r for r in json.load(open(os.path.join(gm, "ida36", "processed", "records.json")))["records"]}
    os.makedirs(os.path.join(out, case), exist_ok=True)
    jobs = []
    for name in run_mse.RECORDS:
        lv = sorted(recs[name]["scale"].items(), key=lambda x: float(x[0]))
        jobs.append((os.path.join(gm, "ida36", "processed", f"{name}.csv"), name, lv, case, out,
                     {"NLTHA_DAMPING": "kcomm", "AS_BUILT": "1", **(env or {})}))
    with ProcessPoolExecutor(max_workers=workers or os.cpu_count()) as ex:
        for fut in as_completed([ex.submit(run_mse.job, *j) for j in jobs]):
            name, case, done = fut.result()
            first = next((lv for lv, col in done if col), None)
            print(f"{name:8s} {case:8s} levels {len(done)}  first collapse at Sa {first} g", flush=True)


if __name__ == "__main__":
    # optional third argument "capped": the force-limited damper variant (DAMPER_MODEL=relief), case asbuilt_capped
    # "final": force-limited dampers and the breaking shear-fuse model of the C5 bearings (case asbuilt_final). The
    # asbuilt and asbuilt_capped sets were run with the older hardening fuse (FUSE_MODEL=hardening).
    mode = sys.argv[3] if len(sys.argv) > 3 else ""
    case, env = {"capped": ("asbuilt_capped", {"DAMPER_MODEL": "relief", "FUSE_MODEL": "hardening"}),
                 "final": ("asbuilt_final", {"DAMPER_MODEL": "relief", "FUSE_MODEL": "pin"})}.get(
        mode, ("asbuilt", {"FUSE_MODEL": "hardening"}))
    main(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else None, case, env)
