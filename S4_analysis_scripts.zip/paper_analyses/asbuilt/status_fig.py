import glob, json, os, sys
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fragility as F
R = "/mnt/project-files/arch-bridge-review/"
L = json.load(open(R + "fragility/column_limit_states.json"))
done = [l.split()[0] for l in open(R + "ida_results_asbuilt/driver.log") if "levels" in l]
def load(folder):
    out = {}
    for f in glob.glob(folder + "/*.json"):
        rec, lv = os.path.basename(f)[:-5].split("_sa")
        if rec not in done: continue
        r = json.load(open(f)); lv = float(lv)
        dd = max(list(r.get("ddrift_x", {}).values()) + list(r.get("ddrift_y", {}).values()) + [0.0])
        if not r.get("completed") and not r.get("skipped") and dd < F.NUMERICAL_DRIFT: continue
        col = r.get("skipped") or not r.get("completed") or dd > F.COLLAPSE_DRIFT
        if col: out[(rec, lv)] = dict(lvl=5, c5=np.nan, spr=np.nan, gov=None, dev=r); continue
        comp, _ = F.component_levels(r, L)
        c5 = max(r["ddrift_x"][k] for k in ("5L", "5R", "6L", "6R")) * 100
        lvl = max(comp.values())
        gov = None
        if lvl >= 2:
            gov = "springing" if max(comp["arch springing transverse"], comp["arch springing vertical"]) >= 2 else "C5/C6"
        out[(rec, lv)] = dict(lvl=lvl, c5=c5, gov=gov, dev=r)
    return out
A = load(R + "ida_results_asbuilt/asbuilt"); B = load(R + "ida_results_mse/uniform_kcomm")
lev = sorted({l for _, l in A})
fig, ax = plt.subplots(2, 2, figsize=(12, 8.2))
fig.suptitle("Cetina paper: status at 18:05, 26 Oct", fontsize=14, weight="bold", x=0.02, ha="left")
# (a) progress
a = ax[0, 0]
items = [("Results (all cases + bootstrap)", 1.0), ("Manuscript text, Sections 1-8", 0.92), ("Figures (6) and tables (16)", 0.9),
         ("Open [Author] notes closed", 0.75), ("As-built runs (%d of 140)" % len(glob.glob(R + "ida_results_asbuilt/asbuilt/*.json")),
         len(glob.glob(R + "ida_results_asbuilt/asbuilt/*.json")) / 140), ("As-built section in paper", 0.0), ("Peer-review thread", 0.0)]
for i, (t, p) in enumerate(items[::-1]):
    a.barh(i, 1, color="#e5e7eb"); a.barh(i, p, color="#2a9d8f" if p >= 1 else "#e9a23b" if p > 0 else "#cbd5e1")
    a.text(0.02, i, t, va="center", fontsize=9.5); a.text(0.98, i, f"{p:.0%}", va="center", ha="right", fontsize=9.5, weight="bold")
a.set_xlim(0, 1); a.axis("off"); a.set_title("(a) Progress", loc="left", weight="bold")
# (b) C5/C6 drift
a = ax[0, 1]
for D, c, n in ((B, "#64748b", "bare structure"), (A, "#2a9d8f", "as built (dampers + C5 fuse)")):
    med = [np.nanmedian([D[(r, l)]["c5"] for r in done if (r, l) in D]) for l in lev]
    a.plot(med, lev, "-o", color=c, label=n, ms=4)
a.set_xlabel("median C5/C6 longitudinal drift (%)"); a.set_ylabel("Sa(T1) (g)"); a.legend(fontsize=9)
a.set_title(f"(b) Crown-column demand, same {len(done)} records", loc="left", weight="bold"); a.grid(alpha=0.3)
# (c) fraction >= moderate / collapse
a = ax[1, 0]
for D, c, n in ((B, "#64748b", "bare"), (A, "#2a9d8f", "as built")):
    for k, ls, lab in ((2, "-", "moderate+"), (5, "--", "collapse")):
        fr = [np.mean([D[(r, l)]["lvl"] >= k for r in done if (r, l) in D]) for l in lev]
        a.plot(lev, fr, ls, color=c, label=f"{n}, {lab}")
a.set_xlabel("Sa(T1) (g)"); a.set_ylabel("fraction of records"); a.legend(fontsize=8.5); a.grid(alpha=0.3)
a.set_title("(c) Damage exceedance (preliminary)", loc="left", weight="bold")
# (d) devices
a = ax[1, 1]; a2 = a.twinx()
fd = [np.median([A[(r, l)]["dev"].get("damper_force_kN", np.nan) or np.nan for r in done if (r, l) in A and A[(r, l)]["dev"].get("completed")]) for l in lev]
fs = [np.median([(A[(r, l)]["dev"].get("fuse_slip_m") or 0) * 1000 for r in done if (r, l) in A and A[(r, l)]["dev"].get("completed")]) for l in lev]
a.plot(lev, np.array(fd) / 1000, "-o", color="#2a9d8f", ms=4, label="damper force per abutment")
a.axhline(4.0, color="#2a9d8f", ls=":", lw=1); a.text(0.15, 4.08, "capacity 4 MN", color="#2a9d8f", fontsize=8.5)
a2.plot(lev, fs, "-s", color="#d62828", ms=4, label="C5 fuse slip")
a.set_xlabel("Sa(T1) (g)"); a.set_ylabel("damper force (MN)", color="#1f7a70"); a2.set_ylabel("C5 fuse slip (mm)", color="#b01e1e")
a.set_title("(d) Device demand (median)", loc="left", weight="bold"); a.grid(alpha=0.3)
fig.tight_layout(rect=(0, 0, 1, 0.95))
fig.savefig(R + "status/status_2026-10-26_1805.png", dpi=150)
# numbers
for D, n in ((B, "bare"), (A, "asbuilt")):
    print(n, "gov@moderate+", {g: sum(1 for k, v in D.items() if v["gov"] == g) for g in ("C5/C6", "springing")})
print("done records", done)
print("damper MN", [round(x/1000, 2) for x in fd]); print("fuse mm", [round(x, 1) for x in fs])
