"""As-built case post-processing: fragility of the as-built runs, the record bootstrap of both cases and the
paired bootstrap of the as-built / bare ratios, plus the device demands (damper force and stroke, fuse slip).
Run: python post_asbuilt.py <project folder arch-bridge-review> [bootstrap reps, default 1000]"""
import glob, json, os, sys
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fragility as F

ROOT = sys.argv[1]
NB = int(sys.argv[2]) if len(sys.argv) > 2 else 1000
L = json.load(open(os.path.join(ROOT, "fragility", "column_limit_states.json")))
STATES = ["slight", "moderate", "extensive", "complete", "collapse"]
ASB = os.environ.get("ASB_CASE", "asbuilt")   # asbuilt (damper V, no force limit) or asbuilt_capped (4 MN relief)
CASES = {"asbuilt": os.path.join(ROOT, "ida_results_asbuilt", ASB),
         "bare": os.path.join(ROOT, "ida_results_mse", "uniform_kcomm")}


def levels_matrix(folder):
    """{record: {sa: worst system level 0-5}} plus the governing component counts and the device demands."""
    M, gov, dev = {}, {}, []
    for f in sorted(glob.glob(os.path.join(folder, "*.json"))):
        rec, lv = os.path.basename(f)[:-5].split("_sa")
        r = json.load(open(f))
        dd = max(list(r.get("ddrift_x", {}).values()) + list(r.get("ddrift_y", {}).values()) + [0.0])
        if not r.get("completed") and not r.get("skipped") and dd < F.NUMERICAL_DRIFT:
            continue   # numerical failure: left out at this level
        if r.get("skipped") or not r.get("completed"):
            M.setdefault(rec, {})[float(lv)] = 5
            continue
        drift = max(list(r["ddrift_x"].values()) + list(r["ddrift_y"].values()))
        comp, dc = F.component_levels(r, L)
        M.setdefault(rec, {})[float(lv)] = 5 if drift > F.COLLAPSE_DRIFT else max(comp.values())
        gov.setdefault(rec, {})[float(lv)] = comp
        if r.get("as_built"):
            dev.append({"record": rec, "sa_g": float(lv), **{k: r.get(k) for k in
                        ("damper_force_kN", "damper_stroke_m", "fuse_force_kN", "fuse_slip_m")}})
    return M, gov, dev


def fit_all(M, recs):
    lev = sorted({l for r in recs for l in M[r]})
    out = {}
    for i, s in enumerate(STATES, 1):
        n = [sum(1 for r in recs if l in M[r]) for l in lev]
        k = [sum(1 for r in recs if M[r].get(l, -1) >= i) for l in lev]
        out[s] = F.fit(lev, n, k) if 0 < sum(k) < sum(n) else (float("nan"), float("nan"))
    return out


def first_gov(gov, recs, i):
    """governing component counts at system level i: the component(s) first reaching it, per record"""
    cnt = {}
    for r in recs:
        for l in sorted(gov.get(r, {})):
            names = [c for c, v in gov[r][l].items() if v >= i]
            if names:
                for c in names:
                    cnt[c] = cnt.get(c, 0) + 1
                break
    return dict(sorted(cnt.items(), key=lambda x: -x[1])[:5])


rng = np.random.default_rng(1)
Ms, govs, devs = {}, {}, {}
for c, folder in CASES.items():
    Ms[c], govs[c], devs[c] = levels_matrix(folder)
recs = sorted(set(Ms["asbuilt"]) & set(Ms["bare"]))
res = {"records": recs, "n_records": len(recs)}
for c in CASES:
    base = fit_all(Ms[c], recs)
    B = {s: [] for s in STATES}
    for _ in range(NB):
        f = fit_all(Ms[c], list(rng.choice(recs, len(recs))))
        for s in STATES:
            B[s].append(f[s])
    res[c] = {s: dict(median=round(base[s][0], 3), beta=round(base[s][1], 3),
                      med_ci=[round(v, 3) for v in np.nanpercentile(np.array(B[s])[:, 0], [5, 95])],
                      beta_ci=[round(v, 3) for v in np.nanpercentile(np.array(B[s])[:, 1], [5, 95])])
              for s in STATES}
    res[c + "_governing"] = {ds: first_gov(govs[c], recs, i) for i, ds in enumerate(F.DS, 1)}
# paired: as-built / bare with the same record resample
fa, fb = fit_all(Ms["bare"], recs), fit_all(Ms["asbuilt"], recs)
R = {s: [] for s in STATES}
Rb = {s: [] for s in STATES}
for _ in range(NB):
    rr = list(rng.choice(recs, len(recs)))
    x, y = fit_all(Ms["bare"], rr), fit_all(Ms["asbuilt"], rr)
    for s in STATES:
        R[s].append(y[s][0] / x[s][0])
        Rb[s].append(y[s][1] - x[s][1])
res["asbuilt_over_bare"] = {s: dict(ratio=round(fb[s][0] / fa[s][0], 3),
                                    ratio_ci=[round(v, 3) for v in np.nanpercentile(R[s], [5, 95])],
                                    p_ratio_gt1=round(float(np.mean(np.array(R[s]) > 1)), 3),
                                    dbeta=round(fb[s][1] - fa[s][1], 3),
                                    dbeta_ci=[round(v, 3) for v in np.nanpercentile(Rb[s], [5, 95])])
                            for s in STATES}
d = devs["asbuilt"]
res["devices"] = {"runs": len(d), "by_level": {}}
for lv in sorted({x["sa_g"] for x in d}):
    q = [x for x in d if x["sa_g"] == lv]
    res["devices"]["by_level"][lv] = {k: round(float(np.max([x[k] or 0 for x in q])), 4)
                                      for k in ("damper_force_kN", "damper_stroke_m", "fuse_force_kN", "fuse_slip_m")}
json.dump(res, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), ASB + "_results.json"), "w"), indent=1)
for c in ("bare", "asbuilt"):
    print(c, {s: (res[c][s]["median"], res[c][s]["beta"]) for s in STATES})
print("ratio", {s: (res["asbuilt_over_bare"][s]["ratio"], res["asbuilt_over_bare"][s]["ratio_ci"]) for s in STATES})
for c in ("bare", "asbuilt"):
    print(c, "governing", res[c + "_governing"])
print("devices", res["devices"]["by_level"])
