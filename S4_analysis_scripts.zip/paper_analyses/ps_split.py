import json,glob,numpy as np,pandas as pd
inf=[json.load(open(f)) for f in glob.glob('/tmp/claude-0/ana/infl_*.json')]
D=pd.read_csv('/tmp/claude-0/del/Cetina_IDA_all_results/0_combined_all_cases/ida_all_runs_final_all_cases.csv',low_memory=False)
G='/mnt/project-files/arch-bridge-review/ground_motions/svgm/'
rows=[]
cache={}
for case,va in (('mse_va1000','va1000'),('mse_va500','va500')):
    sub=D[(D.case==case)&(D.completed==1)]
    for rec in sub.record.unique():
        g=np.load(G+f'{rec}_{va}.npz'); xs=g['x']
        # unit-scale pseudo-static histories
        Q={}
        for d in inf:
            j=int(np.argmin(abs(xs-d['x']))); u=g['disp'][d['dof']-1,j]
            for k,v in d['infl'].items():
                if k=='crown':
                    for c,vv in zip('xyz',v): Q['crown_'+c]=Q.get('crown_'+c,0)+vv*u
                else: Q[k]=Q.get(k,0)+v*u
        pk={k:np.max(np.abs(v)) for k,v in Q.items()}
        pk['C56_ddx']=max(pk[f'ddx{c}{s}'] for c in (5,6) for s in 'LR')
        pk['spr_kt']=max(pk['kt_left'],pk['kt_right']); pk['spr_kv']=max(pk['kv_left'],pk['kv_right'])
        for _,r in sub[sub.record==rec].iterrows():
            sf=r.scale
            tot_c56=max(r[f'ddrift_x_{c}{s}'] for c in (5,6) for s in 'LR')
            rows.append(dict(case=case,record=rec,sa=r.sa_t1_g,
              crown_z_tot=r.crown_rel_m_z,crown_z_ps=sf*pk['crown_z'],
              crown_x_tot=r.crown_rel_m_x,crown_x_ps=sf*pk['crown_x'],
              c56_tot=tot_c56,c56_ps=sf*pk['C56_ddx'],
              kt_tot=max(r.springing_curv_trans_1pm_left,r.springing_curv_trans_1pm_right),kt_ps=sf*pk['spr_kt'],
              kv_tot=max(r.springing_curv_vert_1pm_left,r.springing_curv_vert_1pm_right),kv_ps=sf*pk['spr_kv'],
              dispspr=r.dispspr))
R=pd.DataFrame(rows)
for q in ['crown_z','crown_x','c56','kt','kv']: R[q+'_ratio']=R[q+'_ps']/R[q+'_tot']
R.to_csv('/tmp/claude-0/ana/ps_split_runs.csv',index=False)
pd.set_option('display.width',200)
for case in R.case.unique():
    s=R[R.case==case]
    print(case); print(s.groupby('sa')[['crown_z_tot','crown_z_ps','crown_z_ratio','c56_ratio','kt_ratio','kv_ratio']].median().round(3))
