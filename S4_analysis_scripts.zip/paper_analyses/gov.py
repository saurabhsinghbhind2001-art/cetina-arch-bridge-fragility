import sys,json,glob,os
sys.path.insert(0,'/tmp/claude-0/os'); sys.argv=['x']
import fragility as F
L=json.load(open('/mnt/project-files/arch-bridge-review/fragility/column_limit_states.json'))
base='/tmp/claude-0/del/Cetina_IDA_all_results/'
dirs={'xyz':'1_uniform_3component_xyz','xy':'2_uniform_no_vertical_xy','uniform_kcomm':'3c_uniform_reference_same_10_records','mse_va1000':'3a_multisupport_1000ms','mse_va500':'3b_multisupport_500ms_sensitivity'}
out={}
for case,d in dirs.items():
    recs={}
    for f in glob.glob(base+d+'/raw_runs_json/*.json'):
        rec,lv=os.path.basename(f)[:-5].split('_sa'); r=json.load(open(f))
        if r.get('skipped') or not r.get('completed'): continue
        comp,dc=F.component_levels(r,L); recs.setdefault(rec,[]).append((float(lv),comp))
    res={}
    for i,ds in enumerate(F.DS,1):
        grp={'C5/C6':0,'springing':0,'other':0,'springing only':0,'n':0}
        for rec,lst in recs.items():
            lst.sort(key=lambda x:x[0])
            for lv,comp in lst:
                names=[c for c,v in comp.items() if v>=i]
                if names:
                    grp['n']+=1
                    s=any('springing' in c for c in names); c56=any(c in('C5 long','C6 long') for c in names)
                    grp['C5/C6']+=c56; grp['springing']+=s; grp['other']+= (not s and not c56)
                    grp['springing only']+= (s and not c56)
                    break
        res[ds]=grp
    out[case]=res; print(case,res)
json.dump(out,open('/tmp/claude-0/ana/governing_records.json','w'),indent=1)
