"""Compare a solve/ variant folder (e.g. xyz_swap, xyz_uplift) with the archived XYZ runs on the same records.
usage: python3 var_cmp.py <fragility src dir> <archive base> <solve dir> <folder>"""
import sys, json, glob, os
src, base, solve, folder = sys.argv[1:5]
sys.argv = [sys.argv[0], src, base]
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sens.py')).read().split('out = {}')[0])
new = []
for f in glob.glob(os.path.join(solve, folder, '*.json')):
    rec, lv = os.path.basename(f)[:-5].split('_sa'); new.append((rec, float(lv), json.load(open(f))))
recs = {r for r, *_ in new}
RUNS['xyz10'] = [x for x in RUNS['xyz'] if x[0] in recs]; RUNS[folder] = new
print('records', len(recs), 'runs', len(new), 'archived subset runs', len(RUNS['xyz10']))
R = {c: analyse(c, L0) for c in ('xyz10', folder)}
out = {}
for ds in F.DS + ['collapse']:
    a, b = R['xyz10'][0][ds], R[folder][0][ds]
    out[ds] = dict(ref=[round(a[0], 3), round(a[1], 3)], var=[round(b[0], 3), round(b[1], 3)], ratio=round(b[0] / a[0], 3))
    print(f'{ds:10s} ref {a[0]:.3f} ({a[1]:.2f})  {folder} {b[0]:.3f} ({b[1]:.2f})  ratio {b[0]/a[0]:.3f}')
for ds in F.DS:
    for c in ('xyz10', folder):
        g = R[c][1][ds]; out.setdefault('gov', {}).setdefault(c, {})[ds] = dict(C=sum(v == 'C' for v in g.values()), S=sum(v == 'S' for v in g.values()), T=sum(v == 'T' for v in g.values()), n=len(g))
    print(ds, out['gov']['xyz10'][ds], out['gov'][folder][ds])
json.dump(out, open(os.path.join(solve, folder + '_cmp.json'), 'w'), indent=1)
