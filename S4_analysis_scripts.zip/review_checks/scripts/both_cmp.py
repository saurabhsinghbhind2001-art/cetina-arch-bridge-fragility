import sys, os
folder = sys.argv[4]
exec(open('var_cmp.py').read().replace("json.dump(out", "pass  # json.dump(out"))
RUNS['both'] = RUNS['xyz10'] + [(r + '_s', l, d) for r, l, d in RUNS[folder]]
res, gov = analyse('both', L0)
for ds in F.DS + ['collapse']:
    print(ds, 'both orientations', round(res[ds][0], 3), round(res[ds][1], 3), 'ratio to as-recorded', round(res[ds][0] / R['xyz10'][0][ds][0], 3))
out['both_orientations'] = {ds: [round(res[ds][0], 3), round(res[ds][1], 3)] for ds in res}
json.dump(out, open(os.path.join(solve, folder + '_cmp.json'), 'w'), indent=1)
