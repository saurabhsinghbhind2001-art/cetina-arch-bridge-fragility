import sys, json, glob, os
sys.path.insert(0, sys.argv[1])
import numpy as np, fragility as F
from scipy.optimize import minimize
from scipy.stats import norm
from sa_supports import sa
base = sys.argv[2]
L = json.load(open('/mnt/project-files/arch-bridge-review/fragility/column_limit_states.json'))
dirs = {'mse_va1000':'3a_multisupport_1000ms','mse_va500':'3b_multisupport_500ms_sensitivity','uniform_kcomm':'3c_uniform_reference_same_10_records'}
def factor(rec, va):
    g = np.load(f'/mnt/project-files/arch-bridge-review/ground_motions/svgm/{rec}_{va}.npz'); dt = g['t'][1]-g['t'][0]
    s = [np.sqrt(sa(g['acc'][0,j],dt,0.94)*sa(g['acc'][1,j],dt,0.94)) for j in range(7)]
    return float(np.exp(np.mean(np.log(np.array(s)/s[0]))))
def bern_fit(x, y):
    x, y = np.array(x), np.array(y)
    def nll(p):
        th, be = np.exp(p); pr = np.clip(norm.cdf(np.log(x/th)/be), 1e-9, 1-1e-9)
        return -(y*np.log(pr)+(1-y)*np.log(1-pr)).sum()
    r = minimize(nll, [np.log(np.median(x)), np.log(0.4)], method='Nelder-Mead'); return np.exp(r.x)
res = {}
for case, d in dirs.items():
    va = case.split('_')[1] if case.startswith('mse') else None
    fac = {}
    obs = {ds: ([], [], []) for ds in F.DS + ['collapse']}
    for f in glob.glob(base + '/' + d + '/raw_runs_json/*.json'):
        rec, lv = os.path.basename(f)[:-5].split('_sa'); lv = float(lv); r = json.load(open(f))
        if va and rec not in fac: fac[rec] = factor(rec, va)
        dd = max(list(r.get('ddrift_x', {}).values()) + list(r.get('ddrift_y', {}).values()) + [0.0])
        if not r.get('completed') and not r.get('skipped') and dd < F.NUMERICAL_DRIFT: continue
        col = r.get('skipped') or not r.get('completed') or dd > F.COLLAPSE_DRIFT
        comp = None if col else F.component_levels(r, L)[0]
        for i, ds in enumerate(F.DS + ['collapse'], 1):
            y = col or (i <= 4 and max(comp.values()) >= i)
            obs[ds][0].append(lv); obs[ds][1].append(lv * (fac.get(rec, 1.0))); obs[ds][2].append(int(y))
    res[case] = {ds: dict(ref_IM=[round(v, 3) for v in bern_fit(o[0], o[2])], support_avg_IM=[round(v, 3) for v in bern_fit(o[1], o[2])]) for ds, o in obs.items()}
    if va: res[case]['record_factors'] = {k: round(v, 3) for k, v in fac.items()}
    print(case, json.dumps(res[case]))
json.dump(res, open(os.path.dirname(os.path.abspath(__file__)) + '/im_support_avg.json', 'w'), indent=1)
