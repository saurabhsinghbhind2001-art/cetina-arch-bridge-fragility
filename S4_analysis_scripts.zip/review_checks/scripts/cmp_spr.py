import json, sys, os
sys.path.insert(0, sys.argv[1]); import fragility as F
L = json.load(open('/mnt/project-files/arch-bridge-review/fragility/column_limit_states.json')); A = L['arch_springing']
chk = sys.argv[2]; base = sys.argv[3]
def spr(r):
    o = {}
    for q, ax in (('springing_curv_vert_1pm', 'vertical'), ('springing_curv_trans_1pm', 'transverse')):
        ky = A[ax]['curvature_1pm']['slight']; k_ip = max(r[q].values())
        k = k_ip if (k_ip <= ky or r.get('dispspr')) else ky + (k_ip - ky) * A['ip_weight_m'] / A['hinge_length_m'][ax]
        o[ax] = (round(k_ip / ky, 2), round(k / ky, 2))
    comp, _ = F.component_levels(r, L)
    return o, {c: v for c, v in comp.items() if 'springing' in c or c in ('C5 long', 'C6 long')}, round(max(r['ddrift_x']['5L'], r['ddrift_x']['6L']) * 100, 2)
for rec in ('RSN960', 'RSN1111', 'RSN169'):
    for v in ('disp56', 'dispspr'):
        f = f'{chk}/{rec}_{v}.json'
        if os.path.exists(f):
            r = json.load(open(f)); print(rec, v, 'completed', r['completed'], 'curv/ky (raw, as read):', *spr(r))
    a = f'{base}/3c_uniform_reference_same_10_records/raw_runs_json/{rec}_sa1.5.json'
    r = json.load(open(a)); print(rec, 'archived uniform ref', r.get('disp56'), r.get('dispspr'), *spr(r))
    for c in ('3a_multisupport_1000ms',):
        r = json.load(open(f'{base}/{c}/raw_runs_json/{rec}_sa1.5.json')); print(rec, 'archived MSE1000', r.get('dispspr'), *spr(r))
