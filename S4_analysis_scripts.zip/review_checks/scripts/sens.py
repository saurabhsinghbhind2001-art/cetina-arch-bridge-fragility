import sys, json, glob, os, copy
sys.path.insert(0, sys.argv[1]); sys.argv = sys.argv[:1] + sys.argv[2:]
import numpy as np
import fragility as F
from scipy.stats import binomtest
base = sys.argv[1]
L0 = json.load(open('/mnt/project-files/arch-bridge-review/fragility/column_limit_states.json'))
dirs = {'xyz':'1_uniform_3component_xyz','uniform_kcomm':'3c_uniform_reference_same_10_records','mse_va1000':'3a_multisupport_1000ms','mse_va500':'3b_multisupport_500ms_sensitivity'}
def load(case):
    out=[]
    for f in glob.glob(base+'/'+dirs[case]+'/raw_runs_json/*.json'):
        rec, lv = os.path.basename(f)[:-5].split('_sa'); out.append((rec, float(lv), json.load(open(f))))
    return out
RUNS = {c: load(c) for c in dirs}
def analyse(case, L, coll=F.COLLAPSE_DRIFT):
    rows = {}
    for rec, lv, r in RUNS[case]:
        dd = max(list(r.get("ddrift_x", {}).values()) + list(r.get("ddrift_y", {}).values()) + [0.0])
        if not r.get("completed") and not r.get("skipped") and dd < F.NUMERICAL_DRIFT: continue
        if r.get("skipped") or not r.get("completed"):
            rows.setdefault(lv, []).append((rec, True, None)); continue
        drift = max(list(r["ddrift_x"].values()) + list(r["ddrift_y"].values()))
        comp, dc = F.component_levels(r, L)
        rows.setdefault(lv, []).append((rec, drift > coll, comp))
    levels = sorted(rows); res = {}
    for i, ds in enumerate(F.DS + ['collapse'], 1):
        n = [len(rows[l]) for l in levels]
        k = [sum(1 for _, col, comp in rows[l] if col or (i <= 4 and max(comp.values()) >= i)) for l in levels]
        res[ds] = F.fit(levels, n, k)
    gov = {}
    for i, ds in enumerate(F.DS, 1):
        g = {}
        for rec in sorted({r for l in levels for r, *_ in rows[l]}):
            for l in levels:
                hit = [x for x in rows[l] if x[0] == rec]
                if not hit or hit[0][1]: 
                    if hit and hit[0][1]: break
                    continue
                names = [c for c, v in hit[0][2].items() if v >= i]
                if names:
                    s = any('springing' in c for c in names); c56 = any(c in ('C5 long', 'C6 long') for c in names)
                    g[rec] = 'S' if (s and not c56) else ('C' if (c56 and not s) else 'T')
                    break
        gov[ds] = g
    return res, gov
out = {}
for f in [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]:
    L = copy.deepcopy(L0)
    for ax in ('vertical', 'transverse'): L['arch_springing']['hinge_length_m'][ax] *= f
    row = {}
    for c in ('uniform_kcomm', 'mse_va1000', 'mse_va500', 'xyz'):
        res, gov = analyse(c, L)
        row[c] = {ds: [round(res[ds][0], 3), round(res[ds][1], 3)] for ds in res}
        row[c]['springing_first_extensive'] = sum(v in ('S', 'T') for v in gov['extensive'].values())
        row[c]['springing_only_extensive'] = sum(v == 'S' for v in gov['extensive'].values())
        row[c]['n_ext'] = len(gov['extensive'])
        row[c]['_gov'] = gov['extensive']
    gu, gm = row['uniform_kcomm'].pop('_gov'), row['mse_va1000'].pop('_gov'); row['mse_va500'].pop('_gov'); row['xyz'].pop('_gov')
    common = set(gu) & set(gm)
    to_s = sum(1 for r in common if gu[r] != 'S' and gm[r] == 'S'); back = sum(1 for r in common if gu[r] == 'S' and gm[r] != 'S')
    p = binomtest(to_s, to_s + back, 0.5).pvalue if to_s + back else 1.0
    row['mcnemar_ext'] = dict(to_springing=to_s, back=back, p_two_sided=round(p, 4))
    out[f] = row
    print(f"hinge x{f}: uniform springing-only/ext {row['uniform_kcomm']['springing_only_extensive']}/{row['uniform_kcomm']['n_ext']}, "
          f"MSE1000 {row['mse_va1000']['springing_only_extensive']}/{row['mse_va1000']['n_ext']}, MSE500 {row['mse_va500']['springing_only_extensive']}, XYZ {row['xyz']['springing_only_extensive']}/{row['xyz']['n_ext']}, McNemar {row['mcnemar_ext']}")
    for c in ('xyz','uniform_kcomm','mse_va1000'):
        print('   ', c, {ds: row[c][ds][0] for ds in F.DS + ['collapse']})
json.dump(out, open(os.path.dirname(os.path.abspath(__file__)) + '/springing_hinge_sensitivity.json', 'w'), indent=1)
print('--- collapse drift threshold')
for cd in (0.04, 0.05, 0.06):
    for c in ('xyz', 'uniform_kcomm', 'mse_va1000'):
        res, _ = analyse(c, L0, cd); print(cd, c, 'collapse', [round(x, 3) for x in res['collapse']])
