import numpy as np, glob, os, json
def sa(acc, dt, T, z=0.05):
    w=2*np.pi/T; m=1; c=2*z*w; k=w*w
    # Newmark average acceleration, linear SDOF
    g=0.5; b=0.25; u=v=0; a=-acc[0]; umax=0
    kh=k+g/(b*dt)*c+1/(b*dt*dt)
    A=1/(b*dt)+g/b*c; B=1/(2*b)+dt*(g/(2*b)-1)*c
    for i in range(len(acc)-1):
        dp=-(acc[i+1]-acc[i])+A*v+B*a
        du=dp/kh; dv=g/(b*dt)*du-g/b*v+dt*(1-g/(2*b))*a; da=du/(b*dt*dt)-v/(b*dt)-a/(2*b)
        u+=du; v+=dv; a+=da; umax=max(umax,abs(u))
    return w*w*umax
out={}
for va in ('va1000','va500'):
    R=[]
    for f in sorted(glob.glob(f'/mnt/project-files/arch-bridge-review/ground_motions/svgm/*_{va}.npz')):
        g=np.load(f); dt=g['t'][1]-g['t'][0]; acc=g['acc']
        s=[np.sqrt(sa(acc[0,j],dt,0.94)*sa(acc[1,j],dt,0.94)) for j in range(acc.shape[1])]
        r=np.array(s)/s[0]; R.append(r); print(va, os.path.basename(f), np.round(r,2))
    R=np.array(R); out[va]=dict(median_ratio_by_support=np.round(np.median(R,0),3).tolist(), min=float(R[:,1:].min()), max=float(R[:,1:].max()), geo_mean_all_supports=float(np.exp(np.log(R[:,1:]).mean())))
    print(va, out[va])
json.dump(out, open(os.path.dirname(os.path.abspath(__file__))+'/sa_at_supports.json','w'), indent=1)
