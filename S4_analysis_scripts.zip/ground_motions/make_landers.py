"""Landers 1992 Fort Irwin (RSN 855, NGA-West2) -> scaled, rotated ANSYS/OpenSees input.
Scale 3.603 (Farahani Table 10). FN -> Y (transverse), FP -> X (longitudinal), UP -> Z.
FN azimuth 42 deg: the rotation that best reproduces Farahani's scaled PGAs (FN 0.433 g, FP 0.567 g);
NGA-West2 processing differs from the record Farahani used, so PGDs do not match exactly."""
import numpy as np, sys, os
src, out = sys.argv[1], sys.argv[2]
G, SF, AZ_FN = 9.80665, 3.603, 42.0
def rd(f):
    L = open(f).read().split('\n')
    dt = float(L[3].split('DT=')[1].split()[0])
    return np.array([float(v) for l in L[4:] for v in l.split()]), dt
(a0, dt), (a90, _), (aup, _) = [rd(os.path.join(src, f"RSN855_LANDERS_FTI{c}.AT2")) for c in ("000", "090", "-UP")]
t = np.radians(AZ_FN)
fn = a0 * np.cos(t) + a90 * np.sin(t)
fp = -a0 * np.sin(t) + a90 * np.cos(t)
ax, ay, az = SF * G * fp, SF * G * fn, SF * G * aup          # m/s2
time = np.arange(len(ax)) * dt
os.makedirs(out, exist_ok=True)
np.savetxt(os.path.join(out, "landers_XYZ_ms2.csv"), np.column_stack([time, ax, ay, az]),
           delimiter=",", fmt="%.4f", header="time_s,ax_long_ms2,ay_trans_ms2,az_vert_ms2", comments="")
for n, a in (("X", ax), ("Y", ay), ("Z", az)):
    np.savetxt(os.path.join(out, f"landers_{n}_ms2.txt"), np.column_stack([time, a]), fmt="%.4f\t%.5f")
print("dt", dt, "npts", len(ax), "duration", time[-1])
for n, a in (("X (FP)", ax), ("Y (FN)", ay), ("Z (V)", az)):
    print(f"{n}: PGA {abs(a).max()/G:.3f} g")
