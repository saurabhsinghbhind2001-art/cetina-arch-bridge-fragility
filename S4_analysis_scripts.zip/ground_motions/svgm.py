"""Spatially variable ground motions for the multi-support case, by conditional simulation from the recorded motion
(Kameda & Morikawa 1992; Konakli & Der Kiureghian 2012). The recorded (processed, unscaled) record is kept at the first
support (left abutment, x = 0); the motions at the other supports are simulated conditionally on it, per component and
per frequency, from the complex coherency
    gamma_ij(w) = exp(-(alpha w d_ij / v_s)^2) * exp(-i w (x_j - x_i) / v_app)
(incoherence of Luco & Wong 1986, wave passage along the bridge axis). Uniform rock site: no site-response term.
alpha / v_s = 2.5e-4 s/m (rock, Luco & Wong; Zerva 2009). The power spectral density is the smoothed periodogram of
the recorded component, so the simulated motions keep the record's frequency band; their ends get a 1 s cosine taper.
Displacements and velocities (needed for the imposed-motion analysis) are integrated in the frequency domain with the
same 0.1 Hz high-pass as the records, for every support including the recorded one; 10 s of zeros precede the record
so the imposed motion starts from rest (record time is shifted by 10 s).
Supports: abutments x = 0 and 216 m, C1 21.6, C2 43.2, arch springings 48.67 and 188.94, C9 194.4 m.
Run: python3 -I svgm.py <processed folder> <out folder> <v_app m/s> <record names comma separated>"""
import json, os, sys
import numpy as np
from scipy.ndimage import uniform_filter1d

X_SUP = [0.0, 21.6, 43.2, 48.67, 188.94, 194.4, 216.0]
ALPHA_VS = 2.5e-4


def coherency(w, va):
    x = np.array(X_SUP)
    d = np.abs(x[:, None] - x[None, :])
    dx = x[:, None] - x[None, :]   # G[j, 0] = exp(-i w (x_j - x_0) / v): station j lags station 0
    return np.exp(-(ALPHA_VS * w * d) ** 2) * np.exp(-1j * w * dx / va)


def conditional(a, dt, va, rng):
    """a: recorded component at support 0. Returns (n_sup, n) accelerations."""
    n = len(a)
    nf = 2 ** int(np.ceil(np.log2(n))) * 2
    Z1 = np.fft.rfft(a, nf)
    w = 2 * np.pi * np.fft.rfftfreq(nf, dt)
    S = uniform_filter1d(np.abs(Z1) ** 2, 11)          # smoothed periodogram (same scaling as |Z|^2)
    out = np.zeros((len(X_SUP), len(w)), complex)    # conditional mean (the record, delayed and filtered by coherency)
    noise = np.zeros((len(X_SUP), len(w)), complex)  # incoherent part
    out[0] = Z1
    for k in range(1, len(w)):
        G = coherency(w[k], va)
        g_r1 = G[1:, 0]
        C = G[1:, 1:] - np.outer(g_r1, G[0, 1:])
        C = 0.5 * (C + C.conj().T) + 1e-10 * np.eye(len(X_SUP) - 1)
        lam, V = np.linalg.eigh(C)
        Lm = V * np.sqrt(np.clip(lam, 0, None))
        xi = (rng.standard_normal(len(X_SUP) - 1) + 1j * rng.standard_normal(len(X_SUP) - 1)) / np.sqrt(2)
        out[1:, k] = g_r1 * Z1[k]
        noise[1:, k] = np.sqrt(S[k]) * (Lm @ xi)
    # the noise is stationary over the whole window; shape it with the record's envelope (mean square kept), so it
    # stays inside the strong motion instead of filling the quiet lead-in and tail
    env = np.sqrt(np.clip(uniform_filter1d(a ** 2, max(3, int(1.0 / dt))), 0, None))
    env /= np.sqrt(np.mean(env ** 2))
    return np.fft.irfft(out, nf, axis=1)[:, :n] + np.fft.irfft(noise, nf, axis=1)[:, :n] * env


def taper(x, dt, t_end=1.0):
    """Cosine taper over the first and last second (the simulated ends are not exactly zero)."""
    n = int(t_end / dt)
    w = np.ones(len(x))
    ramp = 0.5 * (1 - np.cos(np.pi * np.arange(n) / n))
    w[:n], w[-n:] = ramp, ramp[::-1]
    return x * w


def integrate(a, dt, f_lo=0.1):
    """Acceleration, velocity and displacement from one high-passed spectrum (4th-order Butterworth magnitude at f_lo,
    the record filter; D = -A / w^2), so the three imposed series are consistent with each other."""
    nf = 2 ** int(np.ceil(np.log2(len(a)))) * 2
    A = np.fft.rfft(a, nf)
    f = np.fft.rfftfreq(nf, dt)
    w = 2 * np.pi * f
    hp = np.zeros_like(f)
    hp[1:] = 1 / np.sqrt(1 + (f_lo / f[1:]) ** 8)
    D = np.zeros_like(A)
    D[1:] = -A[1:] * hp[1:] / w[1:] ** 2
    V = np.zeros_like(A)
    V[1:] = A[1:] * hp[1:] / (1j * w[1:])
    return (np.fft.irfft(A * hp, nf)[:len(a)], np.fft.irfft(V, nf)[:len(a)], np.fft.irfft(D, nf)[:len(a)])


def main(proc, out, va, names):
    os.makedirs(out, exist_ok=True)
    summary = {}
    for name in names:
        rec = np.loadtxt(os.path.join(proc, name + ".csv"), delimiter=",", skiprows=1)
        t, dt = rec[:, 0], rec[1, 0] - rec[0, 0]
        pad = int(10 / dt)                                  # 10 s of zeros so the wave passage delay fits
        pre = int(10 / dt)   # 10 s of zeros in front: the zero-phase high-pass spreads displacement ahead of the first
        # arrival, and without room for it the imposed displacement would start with a step (a shock on the supports)
        acc = np.zeros((3, len(X_SUP), pre + len(t) + pad))
        rng = np.random.default_rng(int(name[3:]) * 7 + int(va))
        for c in range(3):
            a0 = np.r_[np.zeros(pre), rec[:, 1 + c], np.zeros(pad)]
            sim = conditional(a0, dt, va, rng)
            sim[0] = a0
            acc[c] = [taper(s, dt) if j else s for j, s in enumerate(sim)]
        tt = np.arange(acc.shape[2]) * dt
        vel, disp = np.zeros_like(acc), np.zeros_like(acc)
        win = taper(np.ones(acc.shape[2]), dt, 5.0)     # 5 s ramps inside the quiet lead-in and tail
        for c in range(3):
            for j in range(len(X_SUP)):
                # displacement from the high-passed spectrum, windowed so it starts and ends at rest; velocity and
                # acceleration are its derivatives, so the three imposed series are exactly consistent
                disp[c, j] = integrate(acc[c, j], dt)[2] * win
                vel[c, j] = np.gradient(disp[c, j], dt)
                acc[c, j] = np.gradient(vel[c, j], dt)
        np.savez_compressed(os.path.join(out, f"{name}_va{int(va)}.npz"), t=tt, acc=acc, vel=vel, disp=disp,
                            x=np.array(X_SUP))
        pga = (np.abs(acc).max(axis=2) / 9.80665).round(3)
        pgd = np.abs(disp).max(axis=2).round(4)
        summary[name] = dict(pga_g=pga.tolist(), pgd_m=pgd.tolist())
        print(f"{name} va {va:.0f}: PGA X per support {pga[0]} g; PGD X {pgd[0]} m; |d(t=0)| max {np.abs(disp[:, :, 0]).max():.1e} m")
    json.dump(summary, open(os.path.join(out, f"summary_va{int(va)}.json"), "w"), indent=1)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], float(sys.argv[3]), sys.argv[4].split(","))
