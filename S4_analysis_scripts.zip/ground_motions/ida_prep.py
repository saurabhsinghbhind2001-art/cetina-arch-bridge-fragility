"""IDA records (FEMA P695 FF 22 + NF-pulse 14, ida_record_set.md) -> unit-scale OpenSees input and scale factors.
Same filter as make_records.py (0.1-25 Hz 4th-order zero-phase Butterworth, linear detrend, 30 s zero pads), then
the pads and the quiet ends are trimmed to the 0.05-99.95 % Arias window of the three components plus 2 s each side,
which roughly halves the analysis time; nltha.py adds 5 s of free vibration after the record.
As-recorded H1 (first horizontal file by name) -> X (longitudinal), H2 -> Y (transverse), V -> Z. Units m/s2, unscaled.
IM: Sa(T1 = 0.94 s, 5 %) of the geometric mean of the two horizontals. One factor per record and level for all
three components, so V/H stays as recorded.
Run: python3 -I ida_prep.py <folder with the unzipped NGA-West2 files (any sub-folders)> <out folder>"""
import csv, glob, json, os, sys
import numpy as np
from scipy.signal import butter, sosfiltfilt, detrend

G = 9.80665
T1, XI = 0.94, 0.05
FF = [953, 960, 1602, 1787, 169, 174, 1111, 1116, 1158, 1148, 900, 848, 752, 767, 1633, 721, 725, 829, 1244, 1485, 68, 125]
NF = [181, 182, 292, 723, 802, 821, 828, 879, 1063, 1086, 1165, 1503, 1529, 1605]
# Sa(T1) stripes in g: dense through the range of the benchmark (0.4 g PGA), sparser towards collapse
LEVELS = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.8, 1.0, 1.2, 1.5, 1.8, 2.2, 2.6, 3.0]   # 2.6 and 3.0 added 24 Oct to reach collapse
VERT = ("UP", "-V", "V", "DWN", "DN", "-Z", "VER", "VRT")


def read(path):
    lines = open(path).read().split("\n")
    head = lines[3].upper()
    dt = float(head.split("DT=")[1].split()[0].rstrip(","))
    return np.array([float(v) for l in lines[4:] for v in l.split()]), dt, lines[1].strip()


def bandpass(a, dt, lo=0.1, hi=25.0):
    fs = 1 / dt
    if hi < 0.45 * fs:
        sos = butter(4, [lo, hi], btype="bandpass", fs=fs, output="sos")
    else:
        sos = butter(4, lo, btype="highpass", fs=fs, output="sos")
    npad = int(30 / dt)
    padded = np.concatenate([np.zeros(npad), detrend(a, type="linear"), np.zeros(npad)])
    return sosfiltfilt(sos, padded, padtype=None)


def sa(a, dt, T=T1, xi=XI):
    """Pseudo-spectral acceleration (same units as a), Newmark average acceleration on the record steps."""
    w = 2 * np.pi / T
    k, c = w * w, 2 * xi * w
    kh = k + 2 * c / dt + 4 / dt ** 2
    u = v = 0.0
    acc = -a[0]
    umax = 0.0
    for i in range(1, len(a)):
        dp = -(a[i] - a[i - 1]) + (4 / dt + 2 * c) * v + 2 * acc
        du = dp / kh
        dv = 2 * du / dt - 2 * v
        u, v = u + du, v + dv
        acc = -a[i] - c * v - k * u
        umax = max(umax, abs(u))
    return w * w * umax


def components(files, m):
    """(h1, h2, v) of one record: the file names PEER lists in _SearchResults.csv, else the component tags.
    v is None for records without a vertical component (RSN 723 and 725)."""
    names = {os.path.basename(f): f for f in files}
    listed = [m.get(k, "") for k in ("Horizontal-1 Acc. Filename", "Horizontal-2 Acc. Filename", "Vertical Acc. Filename")]
    if listed[0] in names and listed[1] in names:
        return names[listed[0]], names[listed[1]], names.get(listed[2])
    v = [f for f in files if os.path.basename(f)[:-4].upper().endswith(VERT)]
    h = sorted(f for f in files if f not in v)
    if len(v) > 1 or len(h) != 2:
        raise ValueError("cannot identify components: " + ", ".join(map(os.path.basename, files)))
    return h[0], h[1], (v[0] if v else None)


def main(src, out):
    meta = {}
    for f in glob.glob(os.path.join(src, "**", "_SearchResults.csv"), recursive=True):
        rows = list(csv.reader(open(f, encoding="latin-1")))
        hdr = next((i for i, r in enumerate(rows) if r and r[0].strip().startswith("Result")), None)
        if hdr is None:
            continue
        cols = [c.strip() for c in rows[hdr]]
        for r in rows[hdr + 1:]:
            if len(r) < len(cols) or not r[0].strip():
                break
            d = dict(zip(cols, (x.strip().strip('"').strip() for x in r)))
            rsn = d.get(" Record Sequence Number", d.get("Record Sequence Number"))
            if rsn and rsn.isdigit():
                meta[int(rsn)] = d
    at2 = glob.glob(os.path.join(src, "**", "RSN*.AT2"), recursive=True)
    by_rsn = {}
    for f in at2:
        rsn = int(os.path.basename(f)[3:].split("_")[0])
        by_rsn.setdefault(rsn, []).append(f)
    os.makedirs(out, exist_ok=True)
    table, missing = [], []
    for group, rsns in (("FF", FF), ("NF", NF)):
        for rsn in rsns:
            if rsn not in by_rsn:
                missing.append(rsn)
                continue
            m = meta.get(rsn, {})
            fh1, fh2, fv = components(by_rsn[rsn], m)
            (a1, dt, title), (a2, dt2, _) = read(fh1), read(fh2)
            av, dt3, _ = read(fv) if fv else (np.zeros(len(a1)), dt, "")
            if not dt == dt2 == dt3:
                raise ValueError(f"RSN{rsn}: components have different dt")
            n = min(len(a1), len(a2), len(av))
            a1, a2, av = (bandpass(x[:n], dt) * G for x in (a1, a2, av))
            ai = np.cumsum(a1 ** 2 + a2 ** 2 + av ** 2)
            ai /= ai[-1]
            i0 = max(0, np.searchsorted(ai, 0.0005) - int(2 / dt))
            i1 = min(len(ai), np.searchsorted(ai, 0.9995) + int(2 / dt))
            a1, a2, av = (x[i0:i1] for x in (a1, a2, av))
            t = np.arange(len(a1)) * dt
            name = f"RSN{rsn}"
            np.savetxt(os.path.join(out, name + ".csv"), np.column_stack([t, a1, a2, av]), delimiter=",", fmt="%.6g",
                       header="time_s,ax_long_ms2,ay_trans_ms2,az_vert_ms2", comments="")
            s1, s2 = sa(a1, dt) / G, sa(a2, dt) / G
            sa_gm = float(np.sqrt(s1 * s2))
            table.append(dict(
                name=name, rsn=rsn, set=group, title=title,
                event=m.get("Earthquake Name", ""), station=m.get("Station Name", ""), magnitude=m.get("Magnitude", ""),
                rrup_km=m.get("Rrup (km)", ""), files=[os.path.basename(x) for x in (fh1, fh2, fv) if x], has_vertical=fv is not None,
                dt=dt, duration_s=round(float(t[-1]), 2),
                pga_x_g=round(float(abs(a1).max() / G), 4), pga_y_g=round(float(abs(a2).max() / G), 4),
                pga_z_g=round(float(abs(av).max() / G), 4), sa_t1_x_g=round(s1, 4), sa_t1_y_g=round(s2, 4),
                sa_t1_gm_g=round(sa_gm, 4), scale={str(L): round(L / sa_gm, 4) for L in LEVELS}))
            r = table[-1]
            print(f"{name:8s} {group} {r['event'][:22]:22s} {r['station'][:24]:24s} dt {dt:.4f} T {r['duration_s']:6.1f} s  "
                  f"PGA {r['pga_x_g']:.3f}/{r['pga_y_g']:.3f}/{r['pga_z_g']:.3f} g  Sa(T1) gm {sa_gm:.3f} g")
    json.dump(dict(T1_s=T1, damping=XI, levels_sa_g=LEVELS, records=table, missing_rsn=missing),
              open(os.path.join(out, "records.json"), "w"), indent=1)
    if missing:
        print("missing RSN:", missing)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
