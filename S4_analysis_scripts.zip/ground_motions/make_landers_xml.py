"""Write Mechanical load-history XML (Magnitude > Import) for the Landers X/Y/Z base accelerations (SI, m/s2)."""
import numpy as np, os, sys
d = sys.argv[1]
def lv(name, t, a):
    return f"""   <LoadVariation>
    <BulkDetails>
     <Name>{name}</Name>
     <Form><Description/></Form>
     <PropertyData property="pr1">
      <Data format="float">{",".join(f"{v:.5f}" for v in a)}</Data>
      <Qualifier>Acceleration</Qualifier>
      <ParameterValue format="float" parameter="pa1">{",".join(f"{v:.4f}" for v in t)}</ParameterValue>
     </PropertyData>
    </BulkDetails>
    <Metadata>
     <ParameterDetails id="pa1"><Name>Time</Name></ParameterDetails>
     <PropertyDetails id="pr1"><Name>Acceleration</Name></PropertyDetails>
    </Metadata>
   </LoadVariation>
"""
def doc(body):
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<ANSYS_EnggData>
 <LoadVariationData>
  <MatML_Doc>
{body}  </MatML_Doc>
 </LoadVariationData>
</ANSYS_EnggData>
"""
parts = []
for c in "XYZ":
    t, a = np.loadtxt(os.path.join(d, f"landers_{c}_ms2.txt"), unpack=True)
    body = lv(f"Landers {c}", t, a)
    parts.append(body)
    open(os.path.join(d, f"landers_{c}_ms2.xml"), "w").write(doc(body))
open(os.path.join(d, "landers_XYZ_ms2.xml"), "w").write(doc("".join(parts)))
