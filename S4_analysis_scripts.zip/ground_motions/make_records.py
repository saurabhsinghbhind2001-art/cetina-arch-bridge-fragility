"""Farahani's 7 benchmark records (Tables 9-10) -> scaled, rotated OpenSees/ANSYS input.
Same recipe as make_landers.py: one scale factor for all three components (Table 10), the horizontal
pair rotated to the FN azimuth that best reproduces Farahani's scaled FN/FP PGAs (NGA-West2 does not
give FN/FP directly). FN -> Y (transverse), FP -> X (longitudinal), V -> Z. Units m/s2.
Farahani filtered with a 0.1-25 Hz Butterworth band-pass and a linear baseline correction, so the same is
done here (4th order, zero phase, 30 s zero pads kept in the record). The azimuth fit uses PGA and, with half weight, PGD.
Run: python3 -I make_records.py <folder with one sub-folder of unzipped NGA-West2 files per record>"""
import glob, json, os, sys
import numpy as np
from scipy.signal import butter, sosfiltfilt, detrend

G = 9.80665
HERE = os.path.dirname(os.path.abspath(__file__))
# record: (RSN prefix, H1 tag, H2 tag, V tag, scale factor, Farahani PGA FN, FP, V (g), PGD FN, FP, V (m))
RECORDS = {
    "landers_fort-irwin":     ("RSN855_LANDERS_FTI",   "000",  "090", "-UP", 3.603, (0.433, 0.567, 0.194), (0.446, 0.438, 0.095)),
    "kocaeli_goynuk":         ("RSN1162_KOCAELI_GYN",  "000",  "090", "-UP", 3.283, (0.443, 0.449, 0.345), (0.098, 0.118, 0.229)),
    "chi-chi_hwa032":         ("RSN1281_CHICHI_HWA032", "-N",  "-E",  "-V",  3.284, (0.478, 0.381, 0.274), (0.041, 0.105, 0.134)),
    "chi-chi_hwa056":         ("RSN1301_CHICHI_HWA056", "-N",  "-E",  "-V",  4.000, (0.515, 0.359, 0.245), (0.247, 0.167, 0.184)),
    "chi-chi_ILA067":         ("RSN1350_CHICHI_ILA067", "-N",  "-E",  "-V",  2.269, (0.472, 0.436, 0.212), (0.204, 0.148, 0.156)),
    "hector-mine_fort-irwin": ("RSN1783_HECTOR_32577", "360",  "090", "-UP", 3.690, (0.479, 0.406, 0.213), (0.234, 0.142, 0.168)),
    "denali_carlo":           ("RSN2107_DENALI_CARLO", "360",  "-90", "-UP", 4.000, (0.365, 0.381, 0.279), (0.168, 0.130, 0.111)),
}


def read(path):
    lines = open(path).read().split("\n")
    dt = float(lines[3].upper().split("DT=")[1].split()[0].rstrip(","))
    return np.array([float(v) for l in lines[4:] for v in l.split()]), dt


def bandpass(a, dt, lo=0.1, hi=25.0):
    fs = 1 / dt
    if hi < 0.45 * fs:
        sos = butter(4, [lo, hi], btype="bandpass", fs=fs, output="sos")
    else:  # 25 Hz is at or above Nyquist for dt = 0.02 s
        sos = butter(4, lo, btype="highpass", fs=fs, output="sos")
    npad = int(30 / dt)  # zero pads (Boore 2005) so the acausal filter leaves a consistent velocity and displacement
    padded = np.concatenate([np.zeros(npad), detrend(a, type="linear"), np.zeros(npad)])
    return sosfiltfilt(sos, padded, padtype=None)


def disp(a, dt):
    v = np.cumsum(a) * dt
    return np.cumsum(v) * dt


def main(src):
    summary = {}
    for name, (pre, h1, h2, v, sf, pga_ref, pgd_ref) in RECORDS.items():
        d = os.path.join(src, name)
        f = {k: glob.glob(os.path.join(d, f"{pre}{tag}.AT2"))[0] for k, tag in (("h1", h1), ("h2", h2), ("v", v))}
        (a1, dt), (a2, _), (av, _) = (read(f[k]) for k in ("h1", "h2", "v"))
        n = min(len(a1), len(a2), len(av))
        a1, a2, av = (bandpass(x[:n], dt) for x in (a1, a2, av))
        n = len(a1)
        dd = {"h1": disp(a1, dt) * G, "h2": disp(a2, dt) * G, "v": disp(av, dt) * G}  # m per unit-g record
        best = None
        for az in np.arange(0.0, 180.0, 0.5):
            t = np.radians(az)
            fn = a1 * np.cos(t) + a2 * np.sin(t)
            fp = -a1 * np.sin(t) + a2 * np.cos(t)
            dfn = dd["h1"] * np.cos(t) + dd["h2"] * np.sin(t)
            dfp = -dd["h1"] * np.sin(t) + dd["h2"] * np.cos(t)
            err = ((sf * abs(fn).max() / pga_ref[0] - 1) ** 2 + (sf * abs(fp).max() / pga_ref[1] - 1) ** 2
                   + 0.5 * ((sf * abs(dfn).max() / pgd_ref[0] - 1) ** 2 + (sf * abs(dfp).max() / pgd_ref[1] - 1) ** 2))
            if best is None or err < best[0]:
                best = (err, az, fn, fp)
        _, az, fn, fp = best
        t = np.radians(az)
        d_fn = dd["h1"] * np.cos(t) + dd["h2"] * np.sin(t)
        d_fp = -dd["h1"] * np.sin(t) + dd["h2"] * np.cos(t)
        ax, ay, az_ = sf * G * fp, sf * G * fn, sf * G * av
        time = np.arange(n) * dt
        out = os.path.join(HERE, "benchmark7", name)
        os.makedirs(out, exist_ok=True)
        # 5 s of zeros so the free-vibration tail sees no held acceleration
        tail = np.arange(1, int(5 / dt) + 1) * dt + time[-1]
        acc = np.vstack([np.column_stack([time, ax, ay, az_]), np.column_stack([tail, 0 * tail, 0 * tail, 0 * tail])])
        np.savetxt(os.path.join(out, "XYZ_ms2.csv"), acc, delimiter=",", fmt="%.5f",
                   header="time_s,ax_long_ms2,ay_trans_ms2,az_vert_ms2", comments="")
        gd = np.column_stack([time, sf * d_fp, sf * d_fn, sf * dd["v"]])
        np.savetxt(os.path.join(out, "ground_disp_XYZ_m.csv"), gd, delimiter=",", fmt="%.5f",
                   header="time_s,ux_m,uy_m,uz_m", comments="")
        pga = [abs(ay).max() / G, abs(ax).max() / G, abs(az_).max() / G]
        pgd = [abs(gd[:, 2]).max(), abs(gd[:, 1]).max(), abs(gd[:, 3]).max()]
        summary[name] = dict(scale=sf, fn_azimuth_deg=float(az), dt=dt, duration=float(time[-1]),
                             pga_fn_fp_v=[round(x, 3) for x in pga], farahani_pga=pga_ref,
                             pgd_fn_fp_v=[round(x, 3) for x in pgd], farahani_pgd=pgd_ref)
        print(f"{name:24s} az {az:5.1f}  PGA FN/FP/V {pga[0]:.3f}/{pga[1]:.3f}/{pga[2]:.3f} g "
              f"(F {pga_ref[0]}/{pga_ref[1]}/{pga_ref[2]})  PGD {pgd[0]:.3f}/{pgd[1]:.3f}/{pgd[2]:.3f} m "
              f"(F {pgd_ref[0]}/{pgd_ref[1]}/{pgd_ref[2]})  dt {dt}  T {time[-1]:.1f} s")
    json.dump(summary, open(os.path.join(HERE, "benchmark7", "summary.json"), "w"), indent=1)


if __name__ == "__main__":
    main(sys.argv[1])
