import json,glob,os,re,csv,sys
root='/mnt/project-files/arch-bridge-review/'
cases={'xyz':'review_checks/xyz_dispspr_combined/runs','xyz_forcebased_springings':'ida_results/xyz','xy':'ida_results/xy','uniform_kcomm':'ida_results_mse/uniform_kcomm','mse_va1000':'ida_results_mse/mse_va1000','mse_va500':'ida_results_mse/mse_va500','mse_va2000':'review_checks/mse_va2000',
 'uniform_kcomm_dispspr':'review_checks/uniform_kcomm_dispspr','uniform_rayleigh':'review_checks/uniform_rayleigh','xyz_swap':'review_checks/xyz_swap','asbuilt':'ida_results_asbuilt/asbuilt_final','xyz_compression_only_bearings':'review_checks/xyz_uplift','axial_check_0.8g':'review_checks/extra_0p8g','axial_check_0.8g_compression_only':'review_checks/extra_uplift_0p8g','relanding_contact_stiffness':'review_checks/uplift_k','relanding_time_step':'review_checks/uplift_dt'}
def mx(v):
    if isinstance(v,dict): v=list(v.values())
    if isinstance(v,list):
        f=[abs(x) for x in v if isinstance(x,(int,float))]
        return max(f) if f else ''
    return abs(v) if isinstance(v,(int,float)) else ''
rows=[]
for c,d in cases.items():
    for p in sorted(glob.glob(root+d+'/*.json')):
        b=os.path.basename(p)[:-5]
        mr=re.match(r'(RSN\d+)',b)
        if not mr: continue
        ms=re.search(r'sa([\d.]+)$',b)
        variant=b[len(mr.group(1)):].strip('_')
        if ms: variant=variant[:-(len(ms.group(0)))].strip('_')
        r=json.load(open(p))
        dx=r.get('drift_x',{}) or {}; dy=r.get('drift_y',{}) or {}
        ddx=r.get('ddrift_x',{}) or {}; ddy=r.get('ddrift_y',{}) or {}
        cr=r.get('crown_rel_m'); dcr=r.get('deck_crown_rel_m')
        c56=[k for k in dx if k[0] in '56']
        rows.append(dict(case=c,record=mr.group(1),variant=variant,Sa_T1_g=float(ms.group(1)) if ms else '',scale_factor=r.get('scale'),
          damping=r.get('damping','mass'),crown_cols_dispBeam=r.get('disp56',False),springing_dispBeam=r.get('dispspr',False),
          completed=r.get('completed'),nonconverged=r.get('nonconverged',''),collapsed=r.get('collapsed',''),
          C5C6_ddrift_long=round(max(abs(ddx[k]) for k in ddx if k[0] in '56'),6) if any(k[0] in '56' for k in ddx) else '',
          C5C6_ddrift_trans=round(max(abs(ddy[k]) for k in ddy if k[0] in '56'),6) if any(k[0] in '56' for k in ddy) else '',
          C5C6_drift_long_chord=round(max(dx[k] for k in c56),6) if c56 else '',
          C5C6_drift_trans_chord=round(max(dy[k] for k in c56 if k in dy),6) if c56 and dy else '',
          max_col_drift_long_chord=round(mx(dx),6) if dx else '',max_col_drift_trans_chord=round(mx(dy),6) if dy else '',
          C5C6_shear_long_kN=round(max(r['V_long'][k] for k in c56),1) if c56 and r.get('V_long') else '',
          springing_curv_vert_1pm=mx(r.get('springing_curv_vert_1pm')),springing_curv_trans_1pm=mx(r.get('springing_curv_trans_1pm')),
          crown_rel_vert_m=round(abs(cr[2]),6) if isinstance(cr,list) and len(cr)>2 else '',deck_crown_rel_vert_m=round(abs(dcr[2]),6) if isinstance(dcr,list) and len(dcr)>2 else '',
          crown_rel_disp_max_component_m=mx(cr),deck_crown_rel_disp_max_component_m=mx(dcr),
          residual_drift_max=mx(r.get('residual_drift')),
          damper_force_kN=r.get('damper_force_kN',''),fuse_slip_m=r.get('fuse_slip_m','')))
out=root+'deliverables/supplementary/S2_all_runs_peak_responses.csv'
with open(out,'w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
from collections import Counter
print(len(rows),Counter(r['case'] for r in rows))
