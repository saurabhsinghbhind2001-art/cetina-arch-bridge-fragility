import sys, json, glob, os
R='/mnt/project-files/arch-bridge-review/'
src=open(R+'review_checks/scripts/sens.py').read()
pre, rest = src.split('RUNS = {c: load(c) for c in dirs}')
body = rest.split('out = {}')[0]
sys.argv=['x', R+'paper_analyses/asbuilt', R]
exec(pre.split("dirs = {")[0])
dirs={'uref':R+'review_checks/uniform_kcomm_dispspr','v2000':R+'review_checks/mse_va2000','v1000':R+'ida_results_mse/mse_va1000','v500':R+'ida_results_mse/mse_va500'}
def load(case):
    out=[]
    for f in glob.glob(dirs[case]+'/*.json'):
        rec, lv = os.path.basename(f)[:-5].split('_sa'); out.append((rec, float(lv), json.load(open(f))))
    return out
RUNS={c: load(c) for c in dirs}
exec(body)
res={}
for c in dirs:
    r,g=analyse(c,L0)
    res[c]={ds:dict(C=sum(v=='C' for v in g[ds].values()),S=sum(v=='S' for v in g[ds].values()),T=sum(v=='T' for v in g[ds].values()),n=len(g[ds])) for ds in g}
    res[c]['levels']=sorted({l for _,l,_ in RUNS[c]})
    print(c,len(RUNS[c]),{ds:res[c][ds] for ds in F.DS})
json.dump(res,open(R+'paper_analyses/figs_final/governing_counts_full_levels.json','w'),indent=1)
