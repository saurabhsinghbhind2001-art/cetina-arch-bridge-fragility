"""Final-manuscript figures from existing results (no new analyses): governing component, wave speed,
as-built devices, hazard, and the updated shear bounds. Run: python fig_final.py <arch-bridge-review folder>"""
import glob, json, os, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy.stats import norm

ROOT = sys.argv[1]
RC = os.path.join(ROOT, "review_checks")
OUT = os.path.join(ROOT, "paper_analyses", "figs_final")
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9, "axes.titlesize": 9.5, "axes.labelsize": 9,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": "#e3e3e3",
    "grid.linewidth": 0.6, "axes.axisbelow": True, "legend.frameon": False, "legend.fontsize": 7.5,
    "xtick.labelsize": 8, "ytick.labelsize": 8, "savefig.bbox": "tight", "savefig.pad_inches": 0.05,
})
DS = ["slight", "moderate", "extensive", "complete", "collapse"]
DS_C = ["#9ecae1", "#3182bd", "#f39c4a", "#d62728", "#111111"]
DS_L = ["Slight", "Moderate", "Extensive", "Complete", "Collapse"]
XYZ = json.load(open(os.path.join(RC, "xyz_dispspr_combined", "fragility_xyz_db.json")))["states"]


def st(s):
    return XYZ["collapse" if s == "collapse" else "system " + s]


def save(fig, name):
    fig.savefig(os.path.join(OUT, name + ".png"), dpi=600)
    fig.savefig(os.path.join(OUT, name + ".pdf"))
    plt.close(fig)
    print("written", name)


def fig_governing():
    a = json.load(open(os.path.join(RC, "xyz_dispspr_cmp.json")))["gov"]["xyz_db"]
    b = json.load(open(os.path.join(OUT, "governing_counts_full_levels.json")))
    cases = [("Uniform XYZ, 33 records", {d: a[d] for d in DS[:4]}),
             ("Uniform reference, 10 rec.", b["uref"]),
             ("Multi-support 2000 m/s*", b["v2000"]),
             ("Multi-support 1000 m/s", b["v1000"]),
             ("Multi-support 500 m/s*", b["v500"])]
    groups = [("C", "Column first (C5/C6)", "#3182bd"), ("T", "Tied", "#b9b9b9"), ("S", "Springing first", "#2a9d8f")]
    fig, axs = plt.subplots(1, 4, figsize=(7.4, 2.9), sharey=True)
    y = np.arange(len(cases))[::-1]
    for ax, ds, lab in zip(axs, DS[:4], DS_L[:4]):
        for yi, (name, g) in zip(y, cases):
            c = g[ds]; left = 0
            for key, _, col in groups:
                sh = 100 * c[key] / c["n"]
                ax.barh(yi, sh, left=left, color=col, height=0.7, edgecolor="white", lw=0.8)
                if sh >= 15:
                    ax.text(left + sh / 2, yi, str(c[key]), ha="center", va="center", fontsize=6.8,
                            color="white" if key != "T" else "#222")
                left += sh
            ax.text(101, yi, f"n={c['n']}", va="center", fontsize=6.3, color="#555")
        ax.set_title(lab, loc="left"); ax.set_xlim(0, 100); ax.set_xticks([0, 50, 100]); ax.grid(False)
        ax.set_xlabel("records (%)")
    axs[0].set_yticks(y, [c[0] for c in cases])
    fig.legend(handles=[plt.Rectangle((0, 0), 1, 1, color=c) for _, _, c in groups], labels=[l for _, l, _ in groups],
               loc="lower center", ncol=3, bbox_to_anchor=(0.6, -0.06))
    fig.tight_layout(rect=(0, 0.06, 0.98, 1)); fig.subplots_adjust(wspace=0.42)
    save(fig, "fig_governing_component")


def fig_wave_speed():
    d = json.load(open(os.path.join(RC, "va2000_cmp.json")))
    keys = ["uref_dispspr", "mse_va2000", "mse_va1000", "mse_va500"]
    xl = ["Uniform", "2000", "1000", "500"]
    x = np.arange(4)
    fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.7), gridspec_kw=dict(width_ratios=[1.2, 1, 0.8]))
    for i, s in enumerate(DS):
        axs[0].plot(x, [d[s][k][0] for k in keys], "-o", color=DS_C[i], ms=3.5, lw=1.5, label=DS_L[i])
        axs[1].plot(x, [d[s][k][1] for k in keys], "-o", color=DS_C[i], ms=3.5, lw=1.5)
    axs[0].set_ylabel("Median Sa(T1) (g)"); axs[0].set_title("(a) Medians", loc="left"); axs[0].set_ylim(0, 3.0)
    axs[1].set_ylabel("Record-to-record β"); axs[1].set_title("(b) Dispersion", loc="left"); axs[1].set_ylim(0, 0.55)
    dr = [100 * d["at_1p8g"][k]["c56_ddrift_median"] for k in keys]
    axs[2].bar(x, dr, color=["#6b6b6b", "#9ecae1", "#3182bd", "#1f4e79"], width=0.65)
    for xi, v in zip(x, dr):
        axs[2].text(xi, v + 0.05, f"{v:.1f}", ha="center", fontsize=7)
    axs[2].set_ylabel("Median C5/C6 drift (%)"); axs[2].set_title("(c) Drift at 1.8 g", loc="left")
    axs[2].set_ylim(0, 3.2); axs[2].grid(axis="x", visible=False)
    for ax in axs:
        ax.set_xticks(x, ["Unif."] + xl[1:]); ax.set_xlabel("Apparent wave speed (m/s)")
    fig.legend(handles=[Line2D([], [], color=DS_C[i], marker="o", ms=3.5, lw=1.5, label=DS_L[i]) for i in range(5)],
               loc="lower center", ncol=5, bbox_to_anchor=(0.5, -0.07))
    fig.tight_layout(rect=(0, 0.06, 1, 1))
    save(fig, "fig_wave_speed")


def fig_asbuilt():
    d = json.load(open(os.path.join(ROOT, "paper_analyses", "asbuilt", "asbuilt_final_results.json")))
    runs = []
    for f in glob.glob(os.path.join(ROOT, "ida_results_asbuilt", "asbuilt_final", "*.json")):
        r = json.load(open(f))
        if "damper_force_kN" in r:
            r["_lv"] = float(os.path.basename(f)[:-5].split("_sa")[1])
            runs.append(r)
    X = np.linspace(0.01, 3.6, 500)
    fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.8), gridspec_kw=dict(width_ratios=[1.3, 1, 1]))
    ax = axs[0]
    for i, s in enumerate(DS):
        for case, ls in (("bare", "-"), ("asbuilt", "--")):
            t = d[case][s]
            ax.plot(X, norm.cdf(np.log(X / t["median"]) / t["beta"]), color=DS_C[i], ls=ls, lw=1.5)
    ax.legend(handles=[Line2D([], [], color="k", ls="-", label="Bare"), Line2D([], [], color="k", ls="--", label="As built")]
              + [Line2D([], [], color=DS_C[i], lw=3, label=DS_L[i]) for i in range(5)], fontsize=6.4, loc="upper center",
              bbox_to_anchor=(0.5, -0.2), ncol=4)
    ax.set_xlim(0, 3.6); ax.set_ylim(0, 1.02); ax.set_xlabel("Sa(T1) (g)"); ax.set_ylabel("P(DS ≥ ds | Sa)")
    ax.set_title("(a) Fragility, 10 records", loc="left")
    lv = sorted({r["_lv"] for r in runs})
    for ax, key, sc, lab, ttl in ((axs[1], "damper_force_kN", 1e-3, "Peak damper force (MN)", "(b) Abutment damper"),
                                  (axs[2], "fuse_slip_m", 1.0, "Peak C5 bearing slip (m)", "(c) C5 fuse bearing")):
        for r in runs:
            ax.plot(r["_lv"], r[key] * sc, ".", color="#6b6b6b", ms=2.5, alpha=0.4)
        ax.plot(lv, [np.median([r[key] * sc for r in runs if r["_lv"] == l]) for l in lv], "-o", color="#1f4e79", ms=3, lw=1.5)
        ax.set_xlabel("Sa(T1) (g)"); ax.set_ylabel(lab); ax.set_title(ttl, loc="left")
    axs[1].axhline(4.0, color="#d62728", lw=0.9, ls="--"); axs[1].text(3.0, 3.75, "4 MN rating", ha="right", fontsize=7, color="#d62728")
    axs[2].axvline(0.12, color="#d62728", lw=0.9, ls="--"); axs[2].text(0.17, 0.42, "95-yr Sa", fontsize=7, color="#d62728")
    fig.subplots_adjust(wspace=0.45)
    save(fig, "fig_asbuilt_devices")


def fig_hazard():
    T1, TC, BC, K = 0.94, 0.4, 0.30, 2.32
    sa475 = lambda ag: 2.5 * ag * TC / T1
    fig, axs = plt.subplots(1, 2, figsize=(7.4, 2.9), gridspec_kw=dict(width_ratios=[1, 1.15]))
    ax = axs[0]
    sa = np.logspace(np.log10(0.05), np.log10(4), 200)
    for k, ls in ((K, "-"), (3.0, "--")):
        ax.loglog(sa, (1 / 475) * (sa / sa475(0.22)) ** -k, color="#1f4e79", ls=ls, lw=1.5, label=f"k = {k:g}")
    for tr in (95, 475, 2475):
        s = sa475(0.22) * (tr / 475) ** (1 / K)
        ax.plot(s, 1 / tr, "o", color="#1f4e79", ms=4); ax.text(s * 0.9, 1 / tr * 2.2, f"{tr} yr", fontsize=7, ha="right")
    for i, s in enumerate(DS):
        ax.axvline(st(s)["median_sa_g"], color=DS_C[i], lw=1.0, ls=":")
    ax.set_xlabel("Sa(T1 = 0.94 s) (g)"); ax.set_ylabel("Annual frequency of exceedance")
    ax.set_title("(a) Hazard curve, agR = 0.22 g", loc="left"); ax.legend(loc="upper right")
    ax.set_ylim(1e-6, 0.1)
    ax = axs[1]
    w = 0.26
    for j, (ag, col) in enumerate(((0.22, "#3182bd"), (0.25, "#f39c4a"), (0.30, "#d62728"))):
        p = []
        for s in DS:
            th, b = st(s)["median_sa_g"], st(s)["beta"]; bt = np.hypot(b, BC)
            lam = (1 / 475) * (th / sa475(ag)) ** -K * np.exp(0.5 * K ** 2 * bt ** 2)
            p.append(100 * (1 - np.exp(-50 * lam)))
        ax.bar(np.arange(5) + (j - 1) * w, p, w, color=col, label=f"agR = {ag:.2f} g")
        if ag == 0.22:
            for xi, v in enumerate(p):
                ax.text(xi - w, v * 1.15, f"{v:.2g}", ha="center", fontsize=6.5)
    ax.set_yscale("log"); ax.set_ylim(0.01, 60); ax.set_xticks(np.arange(5), DS_L); ax.grid(axis="x", visible=False)
    ax.set_ylabel("Probability in 50 years (%)"); ax.set_title("(b) 50-year exceedance, k = 2.32", loc="left")
    ax.legend(loc="upper right")
    fig.tight_layout()
    save(fig, "fig_hazard")


def fig_shear():
    rows = [("Flexure: moderate", st("moderate")["median_sa_g"], "#3182bd"),
            ("Flexure: complete", st("complete")["median_sa_g"], "#d62728"),
            ("Collapse", st("collapse")["median_sa_g"], "#111111"),
            ("Shear, 4 legs", XYZ["C5/C6 shear failure (Priestley)"]["median_sa_g"], "#9ecae1"),
            ("Shear, 2 legs", 0.62, "#f39c4a"), ("Shear, 2 legs, Vp = 0", 0.44, "#f39c4a"),
            ("Shear, 2 legs, Vp = Vc = 0", 0.28, "#f39c4a")]
    p50 = {"Shear, 2 legs": "2.1 %", "Shear, 2 legs, Vp = 0": "4.5 %", "Shear, 2 legs, Vp = Vc = 0": "13 %"}
    fig, ax = plt.subplots(figsize=(6.4, 2.8))
    y = np.arange(len(rows))[::-1]
    for yi, (n, v, c) in zip(y, rows):
        ax.barh(yi, v, color=c, height=0.62)
        ax.text(v + 0.04, yi, f"{v:.2f} g" + ("  (coincides with collapse)" if "4 legs" in n else "")
                + (f"  · 50-yr {p50[n]}" if n in p50 else ""), va="center", fontsize=7.2)
    ax.set_yticks(y, [r[0] for r in rows]); ax.set_xlim(0, 3.6); ax.grid(axis="y", visible=False)
    ax.set_xlabel("Median Sa(T1) (g)"); ax.set_title("C5/C6 shear bounds against the flexural medians, uniform XYZ", loc="left")
    save(fig, "fig_shear_bounds")


fig_governing(); fig_wave_speed(); fig_asbuilt(); fig_hazard(); fig_shear()
