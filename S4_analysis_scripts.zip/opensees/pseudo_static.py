"""Independent cross-check of paper_analyses/ps_split.py (26 Oct): same per-run ratios within a few %.
Quasi-static part of the multi-support response (Clough & Penzien; Der Kiureghian & Neuenhofer 1992).
Under imposed support motion the total response is the quasi-static response to the support displacements, u_s(t) =
influence x u_g(t), plus a dynamic part. The quasi-static part is zero under uniform excitation (rigid-body motion), so
it isolates what the differential support motion itself does to the bridge.
Method: fibre model (v3, pinned, as nltha.py), initial stiffness. One static solve per imposed support DOF (the
translations nltha.py imposes), with a 0.1 mm displacement (elastic range), gives influence coefficients for the
damage measures of fragility.py: springing section curvature about both axes, and the deformation drift of every
column leg in X and Y. The quasi-static history is the influence matrix times the scaled support displacements of
svgm.py; its peaks are compared with the peaks of the total multi-support run (nltha.py) at the same record and level,
at levels where the structure is nearly elastic. Gravity is solved first so the total-run springing curvature can be
taken relative to the gravity state.
Run: python pseudo_static.py <project folder arch-bridge-review> [va ...]  (default 1000 500)"""
import glob, json, os, sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.argv, ARGS = ["cetina_model.py", "fibre", "0", "v3", "pinned"], sys.argv[1:]
import openseespy.opensees as _ops

_ELE_TYPE = {}
_element = _ops.element


def _record(*a):
    _ELE_TYPE[a[1]] = a[0]
    return _element(*a)


_ops.element = _record
sys.path.insert(0, HERE)
import cetina_model as cm
_ops.element = _element
ops = cm.ops
DELTA = 1e-4

coord = {n: np.array(ops.nodeCoord(n)) for n in ops.getNodeTags()}
fibre = [e for e, typ in _ELE_TYPE.items() if typ == "forceBeamColumn"]
cols = {}
for e in fibre:
    i, j = ops.eleNodes(e)
    if abs(coord[i][0] - coord[j][0]) < 1e-6 and abs(coord[i][1] - coord[j][1]) < 1e-6:
        k = int(round(coord[i][0] / cm.SPAN_DECK))
        cols.setdefault((k, "L" if coord[i][1] < 0 else "R"), []).append(e)
for key in cols:
    cols[key].sort(key=lambda e: coord[ops.eleNodes(e)[0]][2])
arch_set = set(cm.arch_nodes)
arch_els = sorted([e for e in fibre if set(ops.eleNodes(e)) <= arch_set], key=lambda e: coord[ops.eleNodes(e)[0]][0])
spr = {"left": (arch_els[0], 1), "right": (arch_els[-1], 5)}
col_base = {k: ops.eleNodes(es[0])[0] for k, es in cols.items()}
col_top = {k: ops.eleNodes(es[-1])[1] for k, es in cols.items()}
col_h = {k: coord[col_top[k]][2] - coord[col_base[k]][2] for k in cols}
NAMES = [f"spr_{s}_vert" for s in spr] + [f"spr_{s}_trans" for s in spr] + \
        [f"ddx_{k[0]}{k[1]}" for k in sorted(cols)] + [f"ddy_{k[0]}{k[1]}" for k in sorted(cols)]


def response():
    r = [ops.sectionDeformation(e, ip)[1] for e, ip in spr.values()] + \
        [ops.sectionDeformation(e, ip)[2] for e, ip in spr.values()]
    for q in ("x", "y"):
        for k in sorted(cols):
            b, tp, h = col_base[k], col_top[k], col_h[k]
            if q == "x":
                r.append((ops.nodeDisp(tp, 1) - ops.nodeDisp(b, 1)) / h - ops.nodeDisp(b, 5))
            else:
                r.append((ops.nodeDisp(tp, 2) - ops.nodeDisp(b, 2)) / h + ops.nodeDisp(b, 4))
    return np.array(r)


def analysis():
    ops.wipeAnalysis()
    ops.constraints("Transformation"); ops.numberer("RCM"); ops.system("UmfPack")
    ops.test("NormDispIncr", 1e-10, 50); ops.algorithm("Newton")
    ops.integrator("LoadControl", 1.0); ops.analysis("Static")


# gravity state (total-run curvatures include it)
mass = {n: ops.nodeMass(n, 1) for n in coord}
ops.timeSeries("Linear", 1)
ops.pattern("Plain", 1, 1)
for n, m in mass.items():
    if m > 0:
        ops.load(n, 0, 0, -m * 9.81, 0, 0, 0)
analysis()
ops.integrator("LoadControl", 0.1)
assert ops.analyze(10) == 0
r_grav = response()
ops.remove("loadPattern", 1)
ops.reset()

sup = [(n, dof) for n in ops.getFixedNodes() for dof in ops.getFixedDOFs(n) if dof <= 3]
for n, dof in sup:
    ops.remove("sp", n, dof)
infl = np.zeros((len(sup), len(NAMES)))
ops.timeSeries("Constant", 2)
for i, (n, dof) in enumerate(sup):
    ops.pattern("Plain", 100 + i, 2)
    for m, d in sup:
        ops.sp(m, d, DELTA if (m, d) == (n, dof) else 0.0)
    analysis()
    assert ops.analyze(1) == 0, (n, dof)
    infl[i] = response() / DELTA
    ops.remove("loadPattern", 100 + i)
    ops.reset()
# rigid-body check: equal unit displacement of every support in one direction gives no deformation
rigid = {d: float(np.abs(infl[[i for i, s in enumerate(sup) if s[1] == d]].sum(axis=0)).max()) for d in (1, 2, 3)}


def main(root, vas):
    recs = {r["name"]: r for r in json.load(open(os.path.join(root, "ground_motions", "ida36", "processed",
                                                                "records.json")))["records"]}
    out = {"influence_rigid_body_residual": rigid, "gravity": dict(zip(NAMES, r_grav.tolist())), "cases": {}}
    for va in vas:
        case = f"mse_va{va}"
        rows = []
        files = sorted(glob.glob(os.path.join(root, "ground_motions", "svgm*", f"*_va{va}.npz")))
        for npz in files:
            name = os.path.basename(npz).split("_va")[0]
            g = np.load(npz)
            xs = g["x"]
            ug = np.array([g["disp"][dof - 1, int(np.argmin(abs(xs - coord[n][0])))] for n, dof in sup])
            qs1 = infl.T @ ug   # quasi-static history per unit scale
            for lv, sf in sorted(recs[name]["scale"].items(), key=lambda x: float(x[0])):
                f = os.path.join(root, "ida_results_mse", case, f"{name}_sa{lv}.json")
                if not os.path.exists(f):
                    continue
                r = json.load(open(f))
                if not r.get("completed"):
                    continue
                qs = dict(zip(NAMES, (sf * np.abs(qs1).max(axis=1)).tolist()))
                tot = {}
                for s in ("left", "right"):
                    tot[f"spr_{s}_vert"] = r["springing_curv_vert_1pm"][s]
                    tot[f"spr_{s}_trans"] = r["springing_curv_trans_1pm"][s]
                for k, v in r["ddrift_x"].items():
                    tot[f"ddx_{k}"] = v
                for k, v in r["ddrift_y"].items():
                    tot[f"ddy_{k}"] = v
                rows.append(dict(record=name, sa_g=float(lv), scale=sf,
                                 max_col_drift=max(list(r["drift_x"].values()) + list(r["drift_y"].values())),
                                 quasi_static=qs, total=tot))
        out["cases"][case] = rows
        # summary over nearly elastic runs (max column drift < 0.5 %): share of the total peak that the quasi-static
        # part alone reaches, per damage measure group
        el = [x for x in rows if x["max_col_drift"] < 0.005]
        summ = {}
        for grp, keys in (("springing vertical", ["spr_left_vert", "spr_right_vert"]),
                          ("springing transverse", ["spr_left_trans", "spr_right_trans"]),
                          ("C5/C6 long", ["ddx_5L", "ddx_5R", "ddx_6L", "ddx_6R"]),
                          ("C1/C2/C9 long", ["ddx_1L", "ddx_1R", "ddx_2L", "ddx_2R", "ddx_9L", "ddx_9R"])):
            rat = []
            for x in el:
                for k in keys:
                    tot = x["total"][k] - (abs(out["gravity"][k]) if k.startswith("spr") else 0.0)
                    if tot > 0:
                        rat.append(x["quasi_static"][k] / tot)
            summ[grp] = dict(n=len(rat), median_ratio=round(float(np.median(rat)), 3) if rat else None,
                             p84_ratio=round(float(np.percentile(rat, 84)), 3) if rat else None)
        out[f"summary_{case}"] = dict(n_runs=len(el), **summ)
        print(case, json.dumps(out[f"summary_{case}"]))
    print("rigid-body residual", rigid)
    json.dump(out, open(os.path.join(root, "fragility", "pseudo_static.json"), "w"), indent=1)


if __name__ == "__main__":
    main(ARGS[0], [int(v) for v in ARGS[1:]] or [1000, 500])
