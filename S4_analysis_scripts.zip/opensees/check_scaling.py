"""Scaling-bias check (e.g. Luco & Bazzurro 2007): for each record, the Sa(T1) at which it first reaches a damage state
(collapse, complete, extensive) against the scale factor needed to get there. A significant trend of ln(Sa_ds) with
ln(SF) means that heavily scaled records bias the fragility. Also gives the total dispersion with a capacity term.
Run: python check_scaling.py <ida_results> <case> <limit_states.json> <out.json>"""
import glob, json, os, sys
import numpy as np
from scipy import stats

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fragility import component_levels, COLLAPSE_DRIFT, NUMERICAL_DRIFT

out, case, lsf, OUT = sys.argv[1:5]
L = json.load(open(lsf))
BETA_C = 0.30   # capacity / modelling dispersion (FEMA P695 "good" quality range); combined by SRSS
first = {}
for f in glob.glob(os.path.join(out, case, "*.json")):
    rec, lv = os.path.basename(f)[:-5].split("_sa")
    r = json.load(open(f))
    sf = float(r.get("scale", np.nan))
    dd = max(list(r.get("ddrift_x", {}).values()) + list(r.get("ddrift_y", {}).values()) + [0.0])
    if not r.get("completed") and not r.get("skipped") and dd < NUMERICAL_DRIFT:
        continue   # numerical non-convergence at small drift, left out as in fragility.py
    if r.get("skipped") or not r.get("completed"):
        lvl = 5
    else:
        comp, _ = component_levels(r, L)
        drift = max(list(r["ddrift_x"].values()) + list(r["ddrift_y"].values()))
        lvl = 5 if drift > COLLAPSE_DRIFT else max(comp.values())
    first.setdefault(rec, []).append((float(lv), sf, lvl))
res = {}
for name, need in (("extensive", 3), ("complete", 4), ("collapse", 5)):
    sa, sfs = [], []
    for rec, rows in first.items():
        rows.sort()
        hit = [(l, s) for l, s, k in rows if k >= need and not np.isnan(s)]
        if hit:
            sa.append(hit[0][0]); sfs.append(hit[0][1])
    x, y = np.log(sfs), np.log(sa)
    slope, icpt, rr, p, se = stats.linregress(x, y)
    res[name] = dict(n_records=len(sa), slope=round(slope, 3), p_value=round(p, 4), r=round(rr, 3),
                     sf_range=[round(min(sfs), 2), round(max(sfs), 2)])
    print(f"{name:10s} n {len(sa):2d}  ln(Sa) vs ln(SF): slope {slope:+.3f}  r {rr:+.2f}  p {p:.3f}  SF {min(sfs):.1f}-{max(sfs):.1f}")
frag = json.load(open(os.path.join(os.path.dirname(lsf), f"fragility_{case}.json")))
tot = {k: round(float(np.hypot(v["beta"], BETA_C)), 3) for k, v in frag["states"].items() if v["beta"] == v["beta"]}
res["beta_total_with_capacity_0.30"] = tot
json.dump(res, open(OUT, "w"), indent=1)
print("total beta:", {k: v for k, v in tot.items() if k.startswith("system") or k == "collapse"})
