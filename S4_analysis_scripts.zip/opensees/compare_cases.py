"""Three-case comparison: uniform 3-component, no vertical, multi-support. Fits every case with fragility.py and writes
one table (median, beta, governing component) and one figure.
  - xyz vs xy: the 33 records with a vertical component (ida_results);
  - multi-support (1000 m/s base, 500 m/s sensitivity) vs uniform with the same committed-stiffness damping, on the
    same 10 far-field records (ida_results_mse).
Run: python compare_cases.py <project folder arch-bridge-review>"""
import io, json, os, sys, contextlib
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fragility

ROOT = sys.argv[1]
FR = os.path.join(ROOT, "fragility")
LS = os.path.join(FR, "column_limit_states.json")
STATES = ["system slight", "system moderate", "system extensive", "system complete", "collapse"]


def fit(folder, case, prefix):
    with contextlib.redirect_stdout(io.StringIO()):
        fragility.main(folder, case, LS, prefix)
    return json.load(open(prefix + ".json"))


cases = {
    "uniform xyz (33 rec)": fit(os.path.join(ROOT, "ida_results"), "xyz", os.path.join(FR, "fragility_xyz")),
    "no vertical xy (33 rec)": json.load(open(os.path.join(FR, "fragility_xy_matched33.json"))),
    "uniform, k-damping (10 rec)": fit(os.path.join(ROOT, "ida_results_mse"), "uniform_kcomm", os.path.join(FR, "fragility_uniform_kcomm")),
    "multi-support 1000 m/s (10 rec)": fit(os.path.join(ROOT, "ida_results_mse"), "mse_va1000", os.path.join(FR, "fragility_mse_va1000")),
    "multi-support 500 m/s (10 rec)": fit(os.path.join(ROOT, "ida_results_mse"), "mse_va500", os.path.join(FR, "fragility_mse_va500")),
}
rows = []
for name, c in cases.items():
    row = {"case": name}
    for s in STATES:
        t = c["states"][s]
        row[s.replace("system ", "")] = (t["median_sa_g"], t["beta"])
    row["first to reach moderate"] = c.get("governing", {}).get("moderate", {})
    rows.append(row)
json.dump(rows, open(os.path.join(FR, "compare_cases.json"), "w"), indent=1)
for r in rows:
    print(r["case"], {k: v for k, v in r.items() if k != "case"})

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import norm
fig, axs = plt.subplots(1, 2, figsize=(12, 4.6), sharey=True)
x = np.linspace(0.01, 3.5, 400)
cols = ["#4C78A8", "#59A14F", "#F28E2B", "#E15759", "#000000"]
for ax, pair, title in ((axs[0], ("uniform xyz (33 rec)", "no vertical xy (33 rec)"), "Vertical component (33 records)"),
                        (axs[1], ("uniform, k-damping (10 rec)", "multi-support 1000 m/s (10 rec)", "multi-support 500 m/s (10 rec)"),
                         "Spatial variation (10 records)")):
    for name, ls in zip(pair, ("-", "--", ":")):
        for s, c in zip(STATES, cols):
            t = cases[name]["states"][s]
            if np.isnan(t["median_sa_g"]):
                continue
            ax.plot(x, norm.cdf(np.log(x / t["median_sa_g"]) / t["beta"]), color=c, ls=ls)
        ax.plot([], [], "k", ls=ls, label=name)
    for s, c in zip(STATES, cols):
        ax.plot([], [], color=c, label=s.replace("system ", ""))
    ax.set_title(title); ax.set_xlabel("Sa(T1 = 0.94 s) (g)"); ax.set_ylim(0, 1); ax.legend(fontsize=7, loc="lower right")
axs[0].set_ylabel("P(exceed)")
fig.tight_layout()
fig.savefig(os.path.join(FR, "compare_cases.png"), dpi=150)
print("written", os.path.join(FR, "compare_cases.png"))
