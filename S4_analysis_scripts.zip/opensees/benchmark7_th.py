"""Linear 3-component time history of one of Farahani's 7 benchmark records (same model and settings as landers_th.py).
Run: python benchmark7_th.py <record>   (record = a folder name in ground_motions/benchmark7)
Writes benchmark7_<record>.json with peak relative and absolute displacements at the arch crown and deck right end."""
import json, os, sys
import numpy as np

REC = sys.argv[1]
sys.argv = ["cetina_model.py", "elastic", "0", "v3", "pinned"]
import cetina_model as cm
ops = cm.ops

HERE = os.path.dirname(os.path.abspath(__file__))
GM = os.path.join(HERE, "..", "ground_motions", "benchmark7", REC)
d = np.loadtxt(os.path.join(GM, "XYZ_ms2.csv"), delimiter=",", skiprows=1)
ug = np.loadtxt(os.path.join(GM, "ground_disp_XYZ_m.csv"), delimiter=",", skiprows=1)
dt_gm = d[1, 0] - d[0, 0]

def nearest(x, y, z):
    return min(ops.getNodeTags(), key=lambda n: np.linalg.norm(np.array(ops.nodeCoord(n)) - (x, y, z)))
crown = nearest(cm.X_CROWN, 0.0, cm.arch_z(cm.X_CROWN))
deck_end = cm.deck_at[cm.N_SPANS]

ops.constraints("Transformation"); ops.numberer("RCM"); ops.system("UmfPack")
ops.eigen(3)
ops.rayleigh(0.715, 0.0, 0.0, 0.0)
for i, dof in enumerate((1, 2, 3)):
    ops.timeSeries("Path", 10 + i, "-dt", dt_gm, "-values", *d[:, 1 + i])
    ops.pattern("UniformExcitation", 10 + i, dof, "-accel", 10 + i)
ops.test("NormDispIncr", 1e-8, 10); ops.algorithm("Linear"); ops.integrator("Newmark", 0.5, 0.25)
ops.analysis("Transient")
dt = min(dt_gm, 0.01)
nsteps = int(d[-1, 0] / dt)
hist = np.zeros((nsteps, 7))
for s in range(nsteps):
    if ops.analyze(1, dt) != 0:
        sys.exit(f"failed at {s * dt}")
    hist[s] = [(s + 1) * dt] + [ops.nodeDisp(crown, k + 1) for k in range(3)] + [ops.nodeDisp(deck_end, k + 1) for k in range(3)]

g = np.column_stack([np.interp(hist[:, 0], ug[:, 0], ug[:, 1 + k], right=ug[-1, 1 + k]) for k in range(3)])
res = dict(record=REC,
           crown_rel=np.abs(hist[:, 1:4]).max(0).round(4).tolist(),
           deck_rel=np.abs(hist[:, 4:7]).max(0).round(4).tolist(),
           crown_abs=np.abs(hist[:, 1:4] + g).max(0).round(4).tolist(),
           deck_abs_x=round(float(np.abs(hist[:, 4] + g[:, 0]).max()), 4),
           pgd=np.abs(ug[:, 1:4]).max(0).round(4).tolist())
json.dump(res, open(os.path.join(HERE, f"benchmark7_{REC}.json"), "w"), indent=1)
print(res)
