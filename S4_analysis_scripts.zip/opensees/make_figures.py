"""Publication figures for the results section, all drawn from the saved run data and fit results.
Writes figures/figNN_<name>.png (200 dpi) and .pdf.
Run: python make_figures.py <project folder arch-bridge-review>"""
import csv, glob, json, os, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy.stats import norm

ROOT = sys.argv[1]
FR = os.path.join(ROOT, "fragility")
OUT = os.path.join(ROOT, "figures")
os.makedirs(OUT, exist_ok=True)
G = 9.80665
T1 = 0.94

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9, "axes.titlesize": 10, "axes.labelsize": 9,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": "#e3e3e3",
    "grid.linewidth": 0.6, "axes.axisbelow": True, "legend.frameon": False, "legend.fontsize": 8,
    "xtick.labelsize": 8, "ytick.labelsize": 8, "savefig.bbox": "tight", "savefig.pad_inches": 0.05,
})
CASE_C = {"xyz": "#1f4e79", "xy": "#e08a2b", "uniform_kcomm": "#6b6b6b", "mse_va1000": "#2a9d8f", "mse_va500": "#c0392b"}
CASE_L = {"xyz": "Uniform xyz (33 rec.)", "xy": "Uniform xy, no vertical (33 rec.)",
          "uniform_kcomm": "Uniform xyz, k-comm damping (10 rec.)", "mse_va1000": "Multi-support, 1000 m/s",
          "mse_va500": "Multi-support, 500 m/s"}
DS_C = ["#9ecae1", "#3182bd", "#f39c4a", "#d62728", "#111111"]
DS_L = ["Slight", "Moderate", "Extensive", "Complete", "Collapse"]
STATES = ["system slight", "system moderate", "system extensive", "system complete", "collapse"]
FRAG = {"xyz": "fragility_xyz.json", "xy": "fragility_xy_matched33.json", "uniform_kcomm": "fragility_uniform_kcomm.json",
        "mse_va1000": "fragility_mse_va1000.json", "mse_va500": "fragility_mse_va500.json"}
F = {c: json.load(open(os.path.join(FR, f))) for c, f in FRAG.items()}
L = json.load(open(os.path.join(FR, "column_limit_states.json")))
X = np.linspace(0.01, 3.6, 500)


def save(fig, name):
    fig.savefig(os.path.join(OUT, name + ".png"), dpi=200)
    fig.savefig(os.path.join(OUT, name + ".pdf"))
    plt.close(fig)
    print("written", name)


def tag(ax, s):
    ax.text(-0.02, 1.04, s, transform=ax.transAxes, fontsize=11, fontweight="bold", ha="right", va="bottom")


def curve(th, be):
    return norm.cdf(np.log(X / th) / be)


def runs(folder, case):
    out = []
    for f in glob.glob(os.path.join(ROOT, folder, case, "*.json")):
        rec, lv = os.path.basename(f)[:-5].split("_sa")
        r = json.load(open(f))
        r["_rec"], r["_lv"] = rec, float(lv)
        dd = max(list(r.get("ddrift_x", {}).values()) + list(r.get("ddrift_y", {}).values()) + [0.0])
        r["_dd"] = dd
        r["_num"] = bool(r.get("nonconverged")) or (not r.get("completed") and not r.get("skipped") and dd < 0.02)
        r["_col"] = not r["_num"] and (r.get("skipped") or not r.get("completed") or dd > 0.05)
        out.append(r)
    return out


# ---------------------------------------------------------------- fig 1: bridge elevation and supports
def fig_bridge():
    span, L_arch, rise = 21.6, 140.27, 20.58
    xc = 5.5 * span
    xs = np.linspace(xc - L_arch / 2, xc + L_arch / 2, 200)
    za = rise * (1 - ((xs - xc) / (L_arch / 2)) ** 2)
    z_deck = 20.5 + 3.83 + 1.4 + 0.45 + 1.0
    fig, ax = plt.subplots(figsize=(7.2, 2.9))
    ax.grid(False)
    ax.fill_between(xs, za - 1.25, za + 1.25, color="#9aa7b5", lw=0)
    ax.plot([0, 216], [z_deck, z_deck], color="#2f3b48", lw=3.2, solid_capstyle="butt")
    for i in range(1, 10):
        x = i * span
        base = 24.33 - 12.0 if i == 1 else (3.83 if i in (2, 9) else rise * (1 - ((x - xc) / (L_arch / 2)) ** 2) + 1.25)
        hi = i in (5, 6)
        ax.plot([x, x], [base, z_deck - 0.5], color="#d62728" if hi else "#2f3b48", lw=2.4 if hi else 1.8)
        ax.text(x, z_deck + 1.6, f"C{i}", ha="center", fontsize=8, color="#d62728" if hi else "#2f3b48",
                fontweight="bold" if hi else "normal")
    sup = [0, 21.6, 43.2, xc - L_arch / 2, xc + L_arch / 2, 194.4, 216]
    zs = [z_deck - 1.0, 24.33 - 12.0, 3.83, 0, 0, 3.83, z_deck - 1.0]
    ax.scatter(sup, [z - 0.9 for z in zs], marker="^", s=55, color="#2a9d8f", zorder=5, edgecolor="white", lw=0.6)
    ground_x = [-6, 0, 10, 30, 46, xc - L_arch / 2, xc, xc + L_arch / 2, 194.4, 206, 216, 222]
    ground_z = [z_deck - 1.5, z_deck - 1.5, 18, 10, 2.5, -1.2, -14, -1.2, 2.5, 14, z_deck - 1.5, z_deck - 1.5]
    ax.fill_between(ground_x, ground_z, -16, color="#efe6d6", lw=0, zorder=0)
    ax.plot(ground_x, ground_z, color="#b9a98a", lw=0.8, zorder=0)
    ax.annotate("", xy=(165, -7.5), xytext=(75, -7.5), arrowprops=dict(arrowstyle="-|>", color="#2a9d8f", lw=1.4))
    ax.text(120, -12.5, "wave passage, v_app = 1000 / 500 m/s", ha="center", fontsize=8, color="#2a9d8f")
    ax.text(xc, 12.0, "RC box arch, L = 140.3 m, f = 20.6 m", ha="center", fontsize=8, color="#44505c")
    ax.text(xc, 6.0, "C5/C6: short crown columns (governing)", ha="center", fontsize=8, color="#d62728")
    ax.legend(handles=[Line2D([], [], marker="^", ls="", color="#2a9d8f", label="independent support motion (7 points)")],
              loc="upper left", fontsize=8, bbox_to_anchor=(0.0, -0.25))
    ax.set_xlim(-8, 224); ax.set_ylim(-16, z_deck + 5)
    ax.set_aspect("equal"); ax.set_xlabel("x (m)"); ax.set_ylabel("z (m)")
    ax.spines["left"].set_visible(False); ax.set_yticks([])
    save(fig, "fig01_bridge_elevation")


# ---------------------------------------------------------------- fig 2: modal comparison
def fig_modal():
    names = ["1st transverse", "1st longitudinal", "1st vertical", "Antisym. arch", "Main vertical"]
    an = [0.939, 0.653, 0.391, 0.294, 0.282]
    os_ = [0.941, 0.672, 0.401, 0.322, 0.290]
    ma = ["Y 65.0", "X 16.7", "Z 7.5", "X 47.3", "Z 52.6"]
    mo = ["Y 68.4", "X 15.9", "Z 11.6", "X 48.3", "Z 52.2"]
    fig, ax = plt.subplots(figsize=(7.2, 2.8))
    x = np.arange(5)
    ax.bar(x - 0.19, an, 0.36, color="#9aa7b5", label="ANSYS solid model (V3)")
    ax.bar(x + 0.19, os_, 0.36, color="#1f4e79", label="OpenSees fibre model")
    for i in range(5):
        d = [0.2, 2.9, 2.6, 9.4, 2.8][i]   # from modal_check_vs_ansys.md (unrounded periods)
        ax.text(x[i] + 0.19, os_[i] + 0.02, f"{d:+.1f} %", ha="center", fontsize=8, color="#1f4e79", fontweight="bold")
        ax.text(x[i] - 0.19, 0.015, ma[i], ha="center", va="bottom", fontsize=6.5, color="#222", rotation=90)
        ax.text(x[i] + 0.19, 0.015, mo[i], ha="center", va="bottom", fontsize=6.5, color="white", rotation=90)
    ax.set_xticks(x, names); ax.set_ylabel("Period T (s)"); ax.set_ylim(0, 1.08)
    ax.legend(loc="upper right"); ax.grid(axis="x", visible=False)
    ax.set_title("Dominant modes: periods within 3 % for four of five modes (bar labels: mass participation %)", loc="left")
    save(fig, "fig02_modal_check")


# ---------------------------------------------------------------- fig 3: record spectra
def spectra(acc, dt, T, z=0.05):
    w = 2 * np.pi / T
    c, k = 2 * z * w, w * w
    kh = k + 2 * c / dt + 4 / dt ** 2
    u = np.zeros_like(T); v = np.zeros_like(T); a = np.full_like(T, -acc[0]); um = np.zeros_like(T)
    for p in -acc[1:]:
        dp = p + (4 * u / dt ** 2 + 4 * v / dt + a) + c * (2 * u / dt + v)
        un = dp / kh
        vn = 2 * (un - u) / dt - v
        a = 4 * (un - u) / dt ** 2 - 4 * v / dt - a
        u, v = un, vn
        um = np.maximum(um, np.abs(u))
    return w * w * um / G


def fig_spectra():
    recs = json.load(open(os.path.join(ROOT, "ground_motions", "ida36", "processed", "records.json")))["records"]
    T = np.geomspace(0.05, 4.0, 60)
    S = {"FF": [], "NF": []}
    cache = os.path.join(OUT, "_spectra_cache.npz")
    if os.path.exists(cache):
        z = np.load(cache, allow_pickle=True); S = z["S"].item()
    else:
        for r in recs:
            d = np.loadtxt(os.path.join(ROOT, "ground_motions", "ida36", "processed", r["name"] + ".csv"), delimiter=",", skiprows=1)
            dt = d[1, 0] - d[0, 0]
            s = np.sqrt(spectra(d[:, 1], dt, T) * spectra(d[:, 2], dt, T))
            s1 = np.interp(np.log(T1), np.log(T), s)
            S["FF" if r["set"] == "FF" else "NF"].append(s / s1)
        np.savez(cache, S=np.array(S, dtype=object))
    fig, ax = plt.subplots(figsize=(7.2, 3.2))
    allS = np.array(S["FF"] + S["NF"])
    for s in S["FF"]:
        ax.loglog(T, s, color="#9aa7b5", lw=0.5, alpha=0.7)
    for s in S["NF"]:
        ax.loglog(T, s, color="#e9b384", lw=0.5, alpha=0.7)
    ax.loglog(T, np.exp(np.log(allS).mean(0)), color="#1f4e79", lw=2.2, label="geometric mean, 35 records")
    ax.loglog(T, np.exp(np.log(allS).mean(0) + np.log(allS).std(0)), color="#1f4e79", lw=1, ls="--", label="mean ± 1σ")
    ax.loglog(T, np.exp(np.log(allS).mean(0) - np.log(allS).std(0)), color="#1f4e79", lw=1, ls="--")
    tb, tc, td = 0.15, 0.4, 2.0
    ec = np.where(T < tb, 1 + T / tb * 1.5, np.where(T < tc, 2.5, np.where(T < td, 2.5 * tc / T, 2.5 * tc * td / T ** 2)))
    ec = ec / (2.5 * tc / T1)
    ax.loglog(T, ec, color="#d62728", lw=1.8, label="EC8 Type 1, ground A (shape)")
    ax.axvline(T1, color="#444", lw=0.8, ls=":")
    ax.text(T1 * 1.04, 0.08, "T1 = 0.94 s", fontsize=8)
    ax.plot([], [], color="#9aa7b5", label="far-field records"); ax.plot([], [], color="#e9b384", label="near-field records")
    ax.set_xlabel("Period T (s)"); ax.set_ylabel("Sa(T) / Sa(T1)"); ax.set_xlim(0.05, 4); ax.set_ylim(0.05, 12)
    ax.legend(loc="lower left", ncol=2)
    ax.set_title("Record spectra scaled to Sa(T1): the suite brackets the EC8 shape around T1", loc="left")
    save(fig, "fig03_record_spectra")


# ---------------------------------------------------------------- fig 4: support motions
def fig_svgm():
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.3), sharey=True)
    names = ["Abutment A", "C1", "C2", "Springing L", "Springing R", "C9", "Abutment B"]
    for ax, va, t in zip(axs, (1000, 500), ("(a) v_app = 1000 m/s", "(b) v_app = 500 m/s")):
        d = np.load(os.path.join(ROOT, "ground_motions", "svgm", f"RSN953_va{va}.npz"))
        tt, disp = d["t"], d["disp"][1]
        off = 0.0
        sc = 1.0 / np.abs(disp).max() * 0.8
        for j in range(7):
            col = plt.cm.viridis(j / 6.5)
            ax.plot(tt, disp[j] * sc - j, color=col, lw=0.9)
            if va == 1000:
                ax.text(tt[0] - 0.5, -j, names[j], ha="right", va="center", fontsize=7.5, color=col)
        ax.set_title(t, loc="left"); ax.set_xlabel("t (s)"); ax.set_yticks([]); ax.grid(axis="y", visible=False)
        ax.set_xlim(8, 40)
        ax.spines["left"].set_visible(False)
    fig.suptitle("Transverse support displacements, RSN 953 (Northridge, Beverly Hills), conditional simulation",
                 x=0.01, ha="left", fontsize=10)
    fig.tight_layout()
    save(fig, "fig04_support_motions")


# ---------------------------------------------------------------- fig 5: IDA curves
def fig_ida():
    rr = runs("ida_results", "xyz")
    lim = L["C5"]["long"]["drift"]
    fig, ax = plt.subplots(figsize=(7.2, 3.6))
    recs = sorted({r["_rec"] for r in rr})
    for rec in recs:
        pts = sorted([(r["_lv"], r["_dd"], r["_col"]) for r in rr if r["_rec"] == rec and not r["_num"]])
        ok = [(l, d) for l, d, c in pts if not c]
        if ok:
            ax.plot([d * 100 for _, d in ok], [l for l, _ in ok], color="#b9c3cd", lw=0.7)
        col = [l for l, d, c in pts if c and not any(True for r in rr if r["_rec"] == rec and r["_lv"] < l and r["_col"])]
        if col and ok:
            ax.plot([ok[-1][1] * 100, 6.0], [ok[-1][0], col[0]], color="#b9c3cd", lw=0.7, ls=":")
            ax.plot(6.0, col[0], "x", color="#555", ms=4)
    levels = sorted({r["_lv"] for r in rr})
    for q, ls, lw in ((16, "--", 1.2), (50, "-", 2.4), (84, "--", 1.2)):
        v = []
        for l in levels:
            d = [r["_dd"] * 100 if not r["_col"] else 99 for r in rr if r["_lv"] == l and not r["_num"]]
            v.append(np.percentile(d, q))
        v = np.array(v); m = v < 6
        ax.plot(v[m], np.array(levels)[m], color="#1f4e79", ls=ls, lw=lw, label=f"{q}th percentile")
    for i, ds in enumerate(["slight", "moderate", "extensive", "complete"]):
        ax.axvline(lim[ds] * 100, color=DS_C[i], lw=1.2)
        ax.text(lim[ds] * 100 + 0.04, 3.05, DS_L[i], rotation=90, fontsize=7.5, color=DS_C[i], va="top")
    ax.axvline(5.0, color="#111", lw=1.2); ax.text(5.04, 3.05, "Collapse 5 %", rotation=90, fontsize=7.5, va="top")
    ax.plot([], [], color="#b9c3cd", label="single record"); ax.plot([], [], "x", color="#555", label="collapse")
    ax.set_xlim(0, 6.2); ax.set_ylim(0, 3.1)
    ax.set_xlabel("Peak deformation drift, any column leg (%)"); ax.set_ylabel("Sa(T1 = 0.94 s) (g)")
    ax.legend(loc="lower right", ncol=2)
    ax.set_title("IDA curves, uniform xyz, 33 records (vertical lines: C5 longitudinal drift limits)", loc="left")
    save(fig, "fig05_ida_curves_xyz")


# ---------------------------------------------------------------- fig 6: fragility xyz, system and components
def fig_frag_xyz():
    f = F["xyz"]; lv = np.array(f["levels_sa_g"])
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.3), sharey=True)
    ax = axs[0]
    for i, s in enumerate(STATES):
        t = f["states"][s]
        ax.plot(X, curve(t["median_sa_g"], t["beta"]), color=DS_C[i], lw=2,
                label=f"{DS_L[i]}: {t['median_sa_g']:.2f} g, β {t['beta']:.2f}")
        ax.plot(lv, np.array(t["k"]) / np.array(t["n"]), "o", color=DS_C[i], ms=3.2, mec="white", mew=0.4)
    ax.set_title("(a) System damage states", loc="left"); ax.set_xlabel("Sa(T1) (g)"); ax.set_ylabel("P(DS ≥ ds | Sa)")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.17), fontsize=7); ax.set_xlim(0, 3.4); ax.set_ylim(0, 1.02)
    ax = axs[1]
    comp = [("C5 long moderate", "C5 longitudinal, moderate", "#3182bd", "-"),
            ("C1 trans moderate", "C1 transverse, moderate", "#8c6bb1", "-"),
            ("arch springing transverse moderate", "Springing transverse, moderate", "#2a9d8f", "-"),
            ("arch springing vertical moderate", "Springing vertical, moderate", "#7fb3a8", "--"),
            ("C5/C6 shear failure (Priestley)", "C5/C6 shear (Priestley)", "#d62728", "-"),
            ("C5/C6 shear failure (EC truss, lower bound)", "C5/C6 shear (EC truss, lower bound)", "#d62728", ":")]
    for k, lab, c, ls in comp:
        t = f["states"][k]
        if np.isnan(t["median_sa_g"]):
            continue
        ax.plot(X, curve(t["median_sa_g"], t["beta"]), color=c, ls=ls, lw=1.8, label=f"{lab}: {t['median_sa_g']:.2f} g")
    ax.set_title("(b) Components", loc="left"); ax.set_xlabel("Sa(T1) (g)")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.17), fontsize=7)
    ax.set_xlim(0, 3.4)
    save(fig, "fig06_fragility_xyz")


# ---------------------------------------------------------------- fig 7: vertical component
def fig_vertical():
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.2), gridspec_kw=dict(width_ratios=[1.35, 1]))
    ax = axs[0]
    for i, s in enumerate(STATES):
        for c, ls in (("xyz", "-"), ("xy", "--")):
            t = F[c]["states"][s]
            ax.plot(X, curve(t["median_sa_g"], t["beta"]), color=DS_C[i], ls=ls, lw=1.8)
    h = [Line2D([], [], color="k", ls="-", label="with vertical (xyz)"), Line2D([], [], color="k", ls="--", label="without (xy)")]
    h += [Line2D([], [], color=DS_C[i], lw=3, label=DS_L[i]) for i in range(5)]
    ax.legend(handles=h, loc="upper center", bbox_to_anchor=(0.5, -0.17), fontsize=7, ncol=4); ax.set_xlim(0, 3.4); ax.set_ylim(0, 1.02)
    ax.set_xlabel("Sa(T1) (g)"); ax.set_ylabel("P(DS ≥ ds | Sa)"); ax.set_title("(a) Fragility, 33 matched records", loc="left")
    ax = axs[1]
    ch = [(F["xyz"]["states"][s]["median_sa_g"] / F["xy"]["states"][s]["median_sa_g"] - 1) * 100 for s in STATES]
    y = np.arange(5)[::-1]
    ax.barh(y, ch, color=[DS_C[i] for i in range(5)], height=0.6)
    for yi, v in zip(y, ch):
        ax.text(v - 0.3 if v < 0 else v + 0.3, yi, f"{v:+.1f} %", va="center", ha="right" if v < 0 else "left", fontsize=8)
    ax.axvline(0, color="#333", lw=0.8); ax.set_yticks(y, DS_L); ax.set_xlim(-10, 3)
    ax.set_xlabel("Change in median from adding vertical (%)"); ax.set_title("(b) Median change", loc="left")
    ax.grid(axis="y", visible=False)
    save(fig, "fig07_vertical_effect")


# ---------------------------------------------------------------- fig 8: spatial variation
def fig_mse():
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.3), gridspec_kw=dict(width_ratios=[1.35, 1]))
    ax = axs[0]
    cs = [("uniform_kcomm", "-"), ("mse_va1000", "--"), ("mse_va500", ":")]
    for i, s in enumerate(STATES):
        for c, ls in cs:
            t = F[c]["states"][s]
            ax.plot(X, curve(t["median_sa_g"], t["beta"]), color=DS_C[i], ls=ls, lw=1.8)
    h = [Line2D([], [], color="k", ls=ls, label=CASE_L[c]) for c, ls in cs]
    h += [Line2D([], [], color=DS_C[i], lw=3, label=DS_L[i]) for i in range(5)]
    ax.legend(handles=h, loc="upper center", bbox_to_anchor=(0.5, -0.17), fontsize=7, ncol=3); ax.set_xlim(0, 3.6); ax.set_ylim(0, 1.02)
    ax.set_xlabel("Sa(T1) at reference support (g)"); ax.set_ylabel("P(DS ≥ ds | Sa)")
    ax.set_title("(a) Fragility, 10 far-field records", loc="left")
    ax = axs[1]
    x = np.arange(5); w = 0.26
    for j, (c, _) in enumerate(cs):
        b = [F[c]["states"][s]["beta"] for s in STATES]
        ax.bar(x + (j - 1) * w, b, w, color=CASE_C[c], label=["Uniform, k-comm", "MSE 1000 m/s", "MSE 500 m/s"][j])
    ax.set_xticks(x, DS_L, rotation=30); ax.set_ylabel("Record-to-record β"); ax.set_ylim(0, 0.55)
    ax.set_title("(b) Dispersion", loc="left"); ax.legend(fontsize=6.6, loc="upper left"); ax.grid(axis="x", visible=False)
    save(fig, "fig08_spatial_variation")


# ---------------------------------------------------------------- fig 9: governing component
def fig_governing():
    groups = [("C5/C6 longitudinal", "#3182bd"), ("Arch springing transverse", "#2a9d8f"),
              ("Arch springing vertical", "#9fd3c7"), ("Other column legs", "#c7c7c7")]
    def grp(k):
        if k in ("C5 long", "C6 long"):
            return 0
        if k == "arch springing transverse":
            return 1
        if k == "arch springing vertical":
            return 2
        return 3
    cases = ["xyz", "xy", "uniform_kcomm", "mse_va1000", "mse_va500"]
    fig, axs = plt.subplots(1, 4, figsize=(7.2, 2.9), sharey=True)
    for ax, ds, lab in zip(axs, ["slight", "moderate", "extensive", "complete"], DS_L):
        y = np.arange(len(cases))[::-1]
        for yi, c in zip(y, cases):
            cnt = np.zeros(4)
            for k, v in F[c]["governing"][ds].items():
                cnt[grp(k)] += v
            sh = cnt / cnt.sum() * 100
            left = 0
            for g in range(4):
                ax.barh(yi, sh[g], left=left, color=groups[g][1], height=0.7, edgecolor="white", lw=0.5)
                if sh[g] >= 18:
                    ax.text(left + sh[g] / 2, yi, f"{sh[g]:.0f}", ha="center", va="center", fontsize=6.8,
                            color="white" if g in (0, 1) else "#222")
                left += sh[g]
        ax.set_title(lab, loc="left"); ax.set_xlim(0, 100); ax.set_xticks([0, 50, 100]); ax.grid(False)
        ax.set_xlabel("share (%)")
    axs[0].set_yticks(np.arange(len(cases))[::-1], ["Uniform xyz", "Uniform xy", "Uniform, k-comm", "MSE 1000 m/s", "MSE 500 m/s"])
    fig.legend(handles=[plt.Rectangle((0, 0), 1, 1, color=c) for _, c in groups], labels=[n for n, _ in groups],
               loc="lower center", ncol=4, bbox_to_anchor=(0.55, -0.08), fontsize=7.5)
    fig.suptitle("First component to reach each damage state (share of records)", x=0.01, ha="left", fontsize=10)
    fig.tight_layout(rect=(0, 0.05, 1, 1))
    save(fig, "fig09_governing_component")


# ---------------------------------------------------------------- fig 10: crown displacement and springing curvature
def fig_crown():
    A = L["arch_springing"]
    ky = A["transverse"]["curvature_1pm"]["slight"]
    def kreg(r):   # regularized as in fragility.py
        k = max(r["springing_curv_trans_1pm"].values())
        return k if (k <= ky or r.get("dispspr")) else ky + (k - ky) * A["ip_weight_m"] / A["hinge_length_m"]["transverse"]
    fig, axs = plt.subplots(1, 3, figsize=(7.4, 3.0))
    c56 = lambda r: max(r["ddrift_x"][k] for k in ("5L", "5R", "6L", "6R")) * 100
    for c in ("uniform_kcomm", "mse_va1000", "mse_va500"):
        rr = [r for r in runs("ida_results_mse", c) if r.get("completed") and not r["_col"]]
        lv = sorted({r["_lv"] for r in rr})
        cr = [np.median([abs(r["crown_rel_m"][2]) for r in rr if r["_lv"] == l]) for l in lv]
        ku = [np.median([kreg(r) / ky for r in rr if r["_lv"] == l]) for l in lv]
        dc = [np.median([c56(r) for r in rr if r["_lv"] == l]) for l in lv]
        for r in rr:
            axs[1].plot(r["_lv"], c56(r), ".", color=CASE_C[c], ms=2.5, alpha=0.35)
        axs[1].plot(lv, dc, "-o", color=CASE_C[c], ms=3, lw=1.6)
        for r in rr:
            axs[0].plot(r["_lv"], abs(r["crown_rel_m"][2]), ".", color=CASE_C[c], ms=2.5, alpha=0.35)
            axs[2].plot(r["_lv"], kreg(r) / ky, ".", color=CASE_C[c], ms=2.5, alpha=0.35)
        axs[0].plot(lv, cr, "-o", color=CASE_C[c], ms=3, lw=1.6, label=CASE_L[c])
        axs[2].plot(lv, ku, "-o", color=CASE_C[c], ms=3, lw=1.6)
    axs[0].set_xlabel("Sa(T1) (g)"); axs[0].set_ylabel("Crown vertical displacement (m)")
    axs[0].set_title("(a) Vertical crown displacement", loc="left"); axs[0].legend(fontsize=6.8, loc="upper center", bbox_to_anchor=(1.75, -0.2), ncol=3)
    for i, ds in enumerate(["slight", "moderate", "extensive", "complete"]):
        v = L["C5"]["long"]["drift"][ds] * 100
        axs[1].axhline(v, color=DS_C[i], lw=0.9, ls="--"); axs[1].text(0.05, v, DS_L[i], fontsize=7, color=DS_C[i], va="bottom")
    axs[1].set_ylim(0, 5); axs[1].set_xlabel("Sa(T1) (g)"); axs[1].set_ylabel("C5/C6 longitudinal drift (%)")
    axs[1].set_title("(b) C5/C6 drift", loc="left")
    axs[2].set_yscale("log")
    for i, ds in enumerate(["slight", "moderate", "extensive", "complete"]):
        v = A["transverse"]["curvature_1pm"][ds] / ky
        axs[2].axhline(v, color=DS_C[i], lw=0.9, ls="--"); axs[2].text(0.05, v, DS_L[i], fontsize=7, color=DS_C[i], va="top" if ds == "extensive" else "bottom")
    axs[2].set_xlabel("Sa(T1) (g)"); axs[2].set_ylabel("Springing curvature / yield")
    axs[2].set_title("(c) Springing transverse", loc="left")
    axs[0].set_title("(a) Crown vertical", loc="left")
    fig.subplots_adjust(wspace=0.42)
    save(fig, "fig10_crown_springing_demand")


# ---------------------------------------------------------------- fig 11: damping check
def fig_damping():
    d = json.load(open(os.path.join(FR, "damping_check_10rec.json")))["states"]
    keys = [("xyz_33rec_mass", "33 records, mass-proportional", "#1f4e79"),
            ("xyz_10rec_mass", "10 records, mass-proportional", "#6f9cc7"),
            ("xyz_10rec_kcomm", "10 records, committed-stiffness", "#6b6b6b")]
    fig, ax = plt.subplots(figsize=(7.2, 2.9))
    x = np.arange(5); w = 0.26
    for j, (k, lab, c) in enumerate(keys):
        v = [d[s][k][0] for s in STATES]
        ax.bar(x + (j - 1) * w, v, w, color=c, label=lab)
        for xi, vi in zip(x, v):
            ax.text(xi + (j - 1) * w, vi + 0.04, f"{vi:.2f}", ha="center", fontsize=6.8)
    ax.set_xticks(x, DS_L); ax.set_ylabel("Median Sa(T1) (g)"); ax.legend(loc="upper left")
    ax.grid(axis="x", visible=False)
    ax.set_title("Damping model, not record subset, explains the higher low-state medians of the 10-record reference", loc="left")
    save(fig, "fig11_damping_check")


# ---------------------------------------------------------------- fig 12: IM efficiency
def fig_im():
    d = json.load(open(os.path.join(FR, "im_compare_xyz.json")))["states"]
    ims = [("Sa(T1) geo. mean", "Sa(T1)", "#1f4e79"), ("Sa(T1) transverse", "Sa(T1) transverse", "#6f9cc7"),
           ("Sa_avg(0.2-1.5 T1)", "Sa_avg (0.2–1.5 T1)", "#2a9d8f"), ("PGA geo. mean", "PGA", "#e08a2b"),
           ("PGV geo. mean (m/s)", "PGV", "#b9a98a")]
    st = ["slight", "moderate", "extensive", "complete", "collapse"]
    fig, ax = plt.subplots(figsize=(7.2, 3.0))
    x = np.arange(5); w = 0.16
    for j, (k, lab, c) in enumerate(ims):
        v = [d[s][k]["beta"] for s in st]
        bars = ax.bar(x + (j - 2) * w, v, w, color=c, label=lab)
        for s_i, s in enumerate(st):
            if d[s][k]["p_lnR"] < 0.05:
                ax.text(x[s_i] + (j - 2) * w, v[s_i] + 0.008, "*", ha="center", fontsize=9, color="#c0392b")
    ax.set_xticks(x, DS_L); ax.set_ylabel("Dispersion of record capacity β"); ax.set_ylim(0, 0.55)
    ax.legend(ncol=5, loc="upper right", fontsize=7); ax.grid(axis="x", visible=False)
    ax.text(0.0, -0.2, "* not sufficient with respect to rupture distance (p < 0.05)", transform=ax.transAxes, fontsize=7, color="#c0392b")
    ax.set_title("Sa_avg is the most efficient intensity measure at every damage state (xyz, 33 records)", loc="left")
    save(fig, "fig12_im_efficiency")


# ---------------------------------------------------------------- fig 13: sensitivity tornado
def fig_tornado():
    rows = list(csv.DictReader(open(os.path.join(FR, "sensitivity_tornado.csv"))))
    cases = [("xyz", "(a) Uniform xyz"), ("mse_va1000", "(b) Multi-support 1000 m/s")]
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.4), sharey=True)
    for ax, (c, title) in zip(axs, cases):
        rs = [r for r in rows if r["case"] == c]
        y = np.arange(len(rs))[::-1]
        for yi, r in zip(y, rs):
            lo, hi = float(r["low_pct"]), float(r["high_pct"])
            ax.barh(yi, lo, color="#6f9cc7", height=0.62)
            ax.barh(yi, hi, color="#e08a2b", height=0.62)
            if abs(lo) < 0.05 and abs(hi) < 0.05:
                ax.text(1.5, yi, "no change", va="center", fontsize=7, color="#777")
            for v in (lo, hi):
                if abs(v) > 0.05:
                    ax.text(v + (1.5 if v > 0 else -1.5), yi, f"{v:+.0f}", va="center", ha="left" if v > 0 else "right", fontsize=7)
        ax.axvline(0, color="#333", lw=0.8)
        ax.set_yticks(y, [f"{r['quantity']}\n{r['assumption']}" for r in rs], fontsize=6.4)
        ax.set_title(title, loc="left"); ax.set_xlabel("Change in median (%)"); ax.set_xlim(-85, 30); ax.grid(axis="y", visible=False)
    fig.legend(handles=[plt.Rectangle((0, 0), 1, 1, color="#6f9cc7"), plt.Rectangle((0, 0), 1, 1, color="#e08a2b")],
               labels=["lower value (25 mm, −25 %, 2 legs)", "upper value (40 mm, +25 %, 6 legs)"],
               loc="lower center", ncol=2, bbox_to_anchor=(0.6, -0.06))
    fig.tight_layout(rect=(0, 0.04, 1, 1))
    save(fig, "fig13_sensitivity_tornado")


# ---------------------------------------------------------------- fig 14: EC8 hazard
def fig_hazard():
    rows = list(csv.DictReader(open(os.path.join(FR, "ec8_hazard_all_cases.csv"))))
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.3), gridspec_kw=dict(width_ratios=[1, 1.15]))
    ax = axs[0]
    sa = np.geomspace(0.03, 3.5, 200)
    for agr, ls in ((0.22, "-"), (0.25, ":"), (0.30, "--")):
        s475 = 2.5 * agr * 0.4 / T1
        ax.loglog(sa, (1 / 475) * (sa / s475) ** -2.32, color="#444", ls=ls, lw=1.3, label=f"agR = {agr:.2f} g")
    s475 = 2.5 * 0.22 * 0.4 / T1
    for tr, m in ((95, "o"), (475, "s"), (2475, "D")):
        s = s475 * (tr / 475) ** (1 / 2.32)
        ax.plot(s, 1 / tr, m, color="#d62728", ms=5); ax.text(s * 1.25, 1 / tr, f"{tr} yr", fontsize=7.5, va="center")
    for i, s in enumerate(STATES):
        th = F["xyz"]["states"][s]["median_sa_g"]
        ax.axvline(th, color=DS_C[i], lw=1.4)
    ax.text(0.05, 0.05, "vertical lines: xyz medians\n(slight to collapse)", transform=ax.transAxes, fontsize=7)
    ax.set_xlabel("Sa(T1) (g)"); ax.set_ylabel("Annual frequency of exceedance"); ax.set_ylim(1e-6, 1e-1)
    ax.set_title("(a) Hazard, ground A (k = 2.32)", loc="left"); ax.legend(loc="upper right", fontsize=7)
    ax = axs[1]
    cases = ["xyz", "xy (33 matched)", "uniform k-damping (10 rec)", "multi-support 1000 m/s", "multi-support 500 m/s"]
    ck = ["xyz", "xy", "uniform_kcomm", "mse_va1000", "mse_va500"]
    st = ["slight", "moderate", "extensive", "collapse"]
    x = np.arange(len(st)); w = 0.16
    for j, (c, k) in enumerate(zip(cases, ck)):
        v = [float(next(r for r in rows if r["k"] == "2.32" and r["agR_g"] == "0.22" and r["case"] == c and r["state"] == s)["p50yr"]) * 100 for s in st]
        ax.bar(x + (j - 2) * w, v, w, color=CASE_C[k], label=CASE_L[k])
    ax.set_yscale("log"); ax.set_xticks(x, [s.capitalize() for s in st]); ax.set_ylabel("Probability in 50 years (%)")
    ax.set_ylim(0.01, 50); ax.legend(fontsize=6.2, loc="upper right"); ax.grid(axis="x", visible=False)
    ax.set_title("(b) 50-year probability, agR = 0.22 g", loc="left")
    save(fig, "fig14_ec8_hazard")


for fn in (fig_bridge, fig_modal, fig_spectra, fig_svgm, fig_ida, fig_frag_xyz, fig_vertical, fig_mse, fig_governing,
           fig_crown, fig_damping, fig_im, fig_tornado, fig_hazard):
    fn()
