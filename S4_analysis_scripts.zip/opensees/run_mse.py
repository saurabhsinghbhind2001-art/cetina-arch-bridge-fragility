"""Multi-support (spatial variation) IDA driver. Ten far-field records, three cases:
  mse_va1000      imposed support motions from svgm.py, apparent wave speed 1000 m/s (base case), all 14 levels;
  mse_va500       the same with 500 m/s (sensitivity), 6 levels;
  uniform_kcomm   uniform 3-component excitation with the same committed-stiffness damping (reference), all 14 levels.
The Sa(T1) scale of each level is that of the recorded motion (support 0), from records.json, for all three cases.
Climbing as run_ida.py, with one more fallback and a different reading of non-convergence:
  - a run that stops early is repeated with disp-based C5/C6 legs (disp56), then also with disp-based arch springing
    elements (dispspr), then with disp-based elements in every column leg (dispcol, see nltha.py);
  - collapse = a drift above 5 %, or non-convergence of all three element variants at a peak deformation drift of
    at least 2 %. A run that still does not converge below 2 % drift is a numerical failure, not collapse: it is
    flagged "nonconverged", left out of the fragility fit at that level, and the record keeps climbing.
Run: python run_mse.py <project folder arch-bridge-review> [workers]"""
import json, os, subprocess, sys
from concurrent.futures import ProcessPoolExecutor, as_completed

HERE = os.path.dirname(os.path.abspath(__file__))
COLLAPSE_DRIFT = 0.05
NUMERICAL_DRIFT = 0.02   # non-convergence below this deformation drift is read as numerical, not as collapse
TIMEOUT_S = 4 * 3600   # imposed-motion runs use a 0.0025 s step and take 15-60 min
RECORDS = ["RSN953", "RSN960", "RSN1602", "RSN1787", "RSN169", "RSN174", "RSN1111", "RSN1116", "RSN1158", "RSN1148"]
SUBSET = ("0.2", "0.4", "0.8", "1.2", "1.8", "2.6")


def job(rec, name, scales, case, out, env):
    done, collapsed = [], False
    for level, sf in scales:
        f = os.path.join(out, case, f"{name}_sa{level}.json")
        if collapsed:
            if not os.path.exists(f):
                json.dump({"record": name, "case": case, "sa_g": float(level), "scale": sf, "collapsed": True,
                           "skipped": True}, open(f, "w"))
            continue
        def run(extra):
            try:
                subprocess.run([sys.executable, os.path.join(HERE, "nltha.py"), rec, str(sf), "xyz", f] + extra,
                               cwd=HERE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=TIMEOUT_S,
                               env={**os.environ, **env})
            except subprocess.TimeoutExpired:
                pass
        if not os.path.exists(f):
            # multi-support runs start with the disp-based springing elements: about half the force-based runs above
            # 0.5 g failed there and were repeated anyway, and the two agree on drifts, shear and crown displacement
            # within about 3 % (RSN 960 at 0.5 g, 1000 m/s, check of 25 Oct)
            run(["dispspr"] if case.startswith("mse") else [])
        modes = ("disp56", "dispspr", "dispcol")   # each includes the ones before it (see nltha.py)
        for i, mode in enumerate(modes):
            r = json.load(open(f)) if os.path.exists(f) else {}
            if r.get("completed") or r.get("skipped") or any(r.get(m) for m in modes[i:]):
                continue
            run([mode])
        if not os.path.exists(f):
            json.dump({"record": name, "case": case, "scale": sf, "completed": False}, open(f, "w"))
        r = json.load(open(f))
        r["case"] = case
        drift = max(list(r.get("drift_x", {}).values()) + list(r.get("drift_y", {}).values()) + [0.0])
        ddrift = max(list(r.get("ddrift_x", {}).values()) + list(r.get("ddrift_y", {}).values()) + [0.0])
        numerical = not r.get("completed", False) and not r.get("skipped", False) and ddrift < NUMERICAL_DRIFT
        r["nonconverged"] = numerical
        collapsed = not numerical and (r.get("skipped", False) or not r.get("completed", False) or drift > COLLAPSE_DRIFT)
        r["collapsed"] = collapsed
        json.dump(r, open(f, "w"), indent=1)
        done.append((level, collapsed))
    return name, case, done


def main(root, workers=None):
    gm = os.path.join(root, "ground_motions")
    out = os.path.join(root, "ida_results_mse")
    recs = {r["name"]: r for r in json.load(open(os.path.join(gm, "ida36", "processed", "records.json")))["records"]}
    jobs = []
    for name in RECORDS:
        lv = sorted(recs[name]["scale"].items(), key=lambda x: float(x[0]))
        jobs += [(os.path.join(gm, "svgm", f"{name}_va1000.npz"), name, lv, "mse_va1000", out, {}),
                 (os.path.join(gm, "ida36", "processed", f"{name}.csv"), name, lv, "uniform_kcomm", out,
                  {"NLTHA_DAMPING": "kcomm"}),
                 (os.path.join(gm, "svgm", f"{name}_va500.npz"), name, [x for x in lv if x[0] in SUBSET], "mse_va500",
                  out, {})]
    for c in ("mse_va1000", "mse_va500", "uniform_kcomm"):
        os.makedirs(os.path.join(out, c), exist_ok=True)
    with ProcessPoolExecutor(max_workers=workers or os.cpu_count()) as ex:
        for fut in as_completed([ex.submit(job, *j) for j in jobs]):
            name, case, done = fut.result()
            first = next((lv for lv, col in done if col), None)
            print(f"{name:8s} {case:13s} levels {len(done)}  first collapse at Sa {first} g", flush=True)


if __name__ == "__main__":
    main(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else None)
