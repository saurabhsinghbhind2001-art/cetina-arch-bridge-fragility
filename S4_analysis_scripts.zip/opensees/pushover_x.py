"""Longitudinal (X) pushover of the fibre model, same loading as the ANSYS 'Pushover X' run:
gravity first, then a uniform acceleration in X on every mass (forces = nodal mass x a).
The Y load is applied under displacement control of the deck node over the crown, so the
curve continues past the peak (ANSYS, being load controlled, stops at the peak).
Run: python pushover_x.py [target_m]  ->  pushover_x.csv (deck crown ux, base shear X, equivalent acceleration in g)."""
import os
import sys

import numpy as np

TARGET = float(sys.argv[1]) if len(sys.argv) > 1 else 1.0
sys.argv = ["cetina_model.py", "fibre", "0", "v3", "pinned"]
import openseespy.opensees as _ops

# element "-mass" (t/m) is not returned by nodeMass, so record it while the model is built
_ELE_MASS = {}
_element = _ops.element


def _record(*a):
    if "-mass" in a:
        _ELE_MASS[a[1]] = (a[2], a[3], float(a[a.index("-mass") + 1]))
    return _element(*a)


_ops.element = _record
import cetina_model as cm
_ops.element = _element
ops = cm.ops
G = 9.81

nodes = ops.getNodeTags()
mass = {n: ops.nodeMass(n, 1) for n in nodes}
for i, j, m in _ELE_MASS.values():  # lump half of each element's mass at each end
    L = np.linalg.norm(np.array(ops.nodeCoord(i)) - np.array(ops.nodeCoord(j)))
    mass[i] += 0.5 * m * L
    mass[j] += 0.5 * m * L
M = sum(mass.values())
deck_crown = min(cm.deck_nodes, key=lambda n: abs(ops.nodeCoord(n)[0] - cm.X_CROWN))
print(f"total mass {M:.0f} t, control node {deck_crown} at x = {ops.nodeCoord(deck_crown)[0]:.1f} m")

ops.constraints("Transformation"); ops.numberer("RCM"); ops.system("UmfPack")

# --- gravity
ops.timeSeries("Linear", 1)
ops.pattern("Plain", 1, 1)
for n, m in mass.items():
    if m > 0:
        ops.load(n, 0, 0, -m * G, 0, 0, 0)
ops.test("NormDispIncr", 1e-8, 50); ops.algorithm("Newton")
ops.integrator("LoadControl", 0.1); ops.analysis("Static")
if ops.analyze(10) != 0:
    sys.exit("gravity failed")
ops.loadConst("-time", 0.0)
ops.reactions()
rz = sum(ops.nodeReaction(n, 3) for n in nodes)
print(f"gravity: sum Rz = {rz / 1e3:.2f} MN, deck crown uz = {ops.nodeDisp(deck_crown, 3) * 1e3:.1f} mm")

# --- uniform X acceleration pattern, unit = 1 g
ops.timeSeries("Linear", 2)
ops.pattern("Plain", 2, 2)
for n, m in mass.items():
    if m > 0:
        ops.load(n, m * G, 0, 0, 0, 0, 0)
du = 0.005
ops.integrator("DisplacementControl", deck_crown, 1, du)
ops.analysis("Static")
out = [(0.0, 0.0, 0.0)]
u = 0.0
while u < TARGET:
    ok = ops.analyze(1)
    if ok != 0:  # try smaller steps and other algorithms before giving up
        for alg, step in ((("ModifiedNewton", "-initial"), du / 5), (("KrylovNewton",), du / 10), (("NewtonLineSearch",), du / 20)):
            ops.algorithm(*alg)
            ops.integrator("DisplacementControl", deck_crown, 1, step)
            ok = ops.analyze(1)
            if ok == 0:
                break
        ops.algorithm("Newton")
        ops.integrator("DisplacementControl", deck_crown, 1, du)
    if ok != 0:
        print(f"stopped at ux = {u:.3f} m")
        break
    u = ops.nodeDisp(deck_crown, 1)
    lam = ops.getLoadFactor(2)
    if lam < 0.3 * max(o[2] for o in out):  # well past the peak, or a spurious jump: keep the last good point
        break
    out.append((u, lam * M * G, lam))

out = np.array(out)
f = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pushover_x.csv")
np.savetxt(f, out, delimiter=",", fmt="%.6g", header="deck_crown_ux_m,base_shear_X_kN,acc_g", comments="")
i = int(np.argmax(out[:, 2]))
print(f"peak {out[i, 2]:.3f} g = {out[i, 1] / 1e3:.1f} MN at ux = {out[i, 0] * 1e3:.0f} mm; written {f}")
