# Cetina fibre-beam model (OpenSeesPy), draft v0.2 (V12 geometry, v2 moduli)

Run with `python cetina_model.py elastic 30 v2` (elastic, ANSYS v2 moduli) or `... elastic 30 paper` (Farahani Table 1 moduli); use `fibre` instead of `elastic` for fibre arch and columns.
Requires `pip install openseespy` (tested with 3.8.0).

## What is in it
- **Arch:** parabolic centreline, 140.27 × 20.58 m, fixed springings. Single-cell box 8.0 × 2.5 m with 0.5 m webs; the chords go from 0.4 m to 0.6 m at the springings.
- **Columns:** 9 column pairs at ±3.25 m. C2 and C9 are 2.4 × 1.8 m; the others are 1.5 × 1.8 m with 0.3 m walls. C1 is 12.0 m high, C2 and C9 are 20.5 m.
- **Supports:** cap beams 1.4 × 1.5 × 8.3 m. C1–C3, C8 and C9 are monolithic. C4–C7 sit on bearings fixed in all three translations with rotations free.
- **Deck:** elastic spine of slab plus 5 T-girders, with torsional mass inertia. The abutments are free longitudinally and fixed transversely and vertically.
- **Mass:** non-structural mass is calibrated so that each component mass matches the ANSYS v2 solid model (arch 3,813 t, columns + caps 1,546 t, deck 2,678 t, surfacing 449 t, cross girders 471 t).
- **Fibre option:** Concrete02 for C45/55 and C30/37, Steel02 B500, and 4 % longitudinal rebar (Farahani p. 612).

## First modal check against v2 (elastic, 30 modes)

| | v0.1 OpenSees | v2 ANSYS solid | Diff |
|---|---|---|---|
| Total mass | 8,957 t | 9,026 t | −0.8 % |
| 1st transverse | 1.039 Hz (Y 68 %) | 1.136 Hz (Y 64 %) | −8.5 % |
| 1st longitudinal | 1.450 Hz (X 17 %) | 1.609 Hz (X 17 %) | −10 % |
| 1st vertical | 2.462 Hz (Z 16 %) | 2.711 Hz (Z 7 %) | −9 % |
| Main vertical | 3.297 Hz (Z 48 %) | 3.740 Hz (Z 53 %) | −12 % |
| Main longitudinal | 4.00 / 4.81 Hz (X 23 + 32 %) | 4.047 Hz (X 46 %) | split into two modes |

The mode order and mass distribution already match v2. The beam model is uniformly 9–12 % too soft. Likely reasons, to fix next:
1. **ASSUMED levels.** The cap-beam soffit is at +22.5 m above the springing centreline, which sets every column height except C1 and C2. These need replacing with the v2 coordinates.
2. **Arch centreline shape.** v0.1 uses a parabola; v2 may use a different curve.
3. **No rigid joint zones.** Column–cap and column–arch intersections are flexible in the beam model but solid in v2.
4. **Concrete moduli.** These need confirming against the values used in v2.

The repeated modes near 3.1 Hz and 5.7 Hz carry no mass. They are local deck-torsion modes of the spine idealisation and can be ignored for now.

## Next
1. Calibrate the frequencies to within 5 % of v2 once the v2 geometry is in.
2. Add a gravity stage, then a pushover compared against v2.
3. Run the 7 Farahani records as the nonlinear benchmark (their Table 12).
4. Add the IDA driver and fragility post-processing.

## v0.2 calibration against v2 (V12 geometry, v2 Engineering Data moduli)

| Mode | OpenSees v0.2 | ANSYS v2 | Diff |
|---|---|---|---|
| 1st transverse | 1.125 Hz (Y 67 %) | 1.136 Hz (Y 64 %) | −1.0 % |
| 1st longitudinal | 1.687 Hz (X 17 %) | 1.609 Hz (X 17 %) | +4.8 % |
| 1st vertical | 2.808 Hz (Z 13 %) | 2.711 Hz (Z 7 %) | +3.6 % |
| Main vertical | 3.702 Hz (Z 51 %) | 3.740 Hz (Z 53 %) | −1.0 % |
| Main longitudinal | 4.145 Hz (X 49 %) | 4.047 Hz (X 46 %) | +2.4 % |

All governing modes are within 5 %, so the beam model is calibrated to the solid model.
With Farahani's static moduli (`paper`), every frequency drops by about 12 % (mode 1 is 0.985 Hz).

## v0.3 calibration against the V3 solid model (19 Oct)
Run: `python cetina_model.py elastic 40 v3 pinned`.
- `v3` selects the transformed-section moduli (arch 43.2 GPa, columns 40.1 GPa, deck 36.2 GPa) and the V13 deck section (web 0.4 × 1.09 plus flange 1.9 × 0.11).
- It also selects the V3 component masses: arch 3,727 t, columns + caps 1,392 t, girders + slab 2,899 t, cross girders 401 t, surfacing 449 t.

| Mode | OpenSees v3 pinned (Hz) | V3 solid (Hz) | Diff |
|---|---|---|---|
| 1st transverse (Y 67.5 / 65.0 %) | 1.068 | 1.065 | +0.3 % |
| 1st longitudinal (X 15.6 / 16.7 %) | 1.526 | 1.532 | −0.4 % |
| 1st vertical (Z 12.5 / 7.5 %) | 2.530 | 2.559 | −1.1 % |
| Antisymmetric arch (X 48.4 / 47.3 %) | 3.259 | 3.402 | −4.2 % |
| Main vertical (Z 50.8 / 52.6 %) | 3.494 | 3.551 | −1.6 % |

All governing modes are within 5 %, so **OpenSees v0.3 is calibrated to V3**. Use `v3 pinned` for every later OpenSees run.

With `v3 fixed` (bearing rotations fixed), the antisymmetric mode is +15 % and the longitudinal mode +5 %. So the small bonded steel bearing blocks in the solid model (about 0.064 m³ each) behave close to rotational hinges between the 1.4 m caps and the cross girders.
The secondary transverse mode (V3 3.98 Hz, Y 11 %) splits into two modes in the beam model (3.16 Hz Y 5 %, 4.54 Hz Y 6 %). This is the expected limit of a spine deck model.

## Pushover Y (fibre model, uncalibrated), 21 Oct
`python3 -B pushover_y.py [target_m]` → `pushover_y.csv` (deck crown uy, base shear Y, equivalent g).
Gravity, then uniform Y acceleration on every mass, displacement control at the deck node over the crown (x = 118.8 m). Same loading as the ANSYS "Pushover Y" run.
Element masses are lumped to the nodes for the loads (nodeMass alone misses them): total 8,816 t, gravity ΣRz 86.5 MN.
First run: initial stiffness 3.0 g/m, softening from about 0.2 g (cracking), 0.96 g at 0.49 m with no peak yet. It stopped there on a numerical failure. Compare with ANSYS before tuning.

## Pushover X (longitudinal)
`pushover_x.py` (same as `pushover_y.py` with the uniform acceleration and the displacement control in X; control node deck crown). Output `pushover_x.csv` (deck_crown_ux_m, base_shear_X_kN, acc_g).
Result (v3, pinned bearings): initial stiffness about 24 g/m (0.1 g at 4.1 mm, 0.3 g at 14.1 mm), peak 1.575 g (136 MN) at ux = 454 mm, 1.55 g at 0.50 m. The first step (5 mm) already reaches 0.12 g, so the elastic branch is coarse.

## IDA time-history settings (nltha.py, run_ida.py), 23–24 Oct
- **Integration: HHT with α = 0.9.** Average-acceleration Newmark left a step-to-step oscillation in the shear and axial force of the short C5/C6 legs, with shear spikes to 13 MN. HHT removes it, and drifts and displacements are unchanged (within 1–3 %). The 114 Newmark runs are in `ida_results_newmark_superseded`.
- **Force-based elements: `-iter 50 1e-10`.** The defaults (10 iterations, 1e-12) stopped some runs early.
- **Disp-based fallback for C5/C6.** Some runs still stop early, because the C5/C6 base sections go into softening and the force-based element cannot find a compatible state. Those runs are repeated with displacement-based elements in the C5/C6 legs (`disp56`, flagged in the result JSON). In converged runs the two element types agree within 1–2 % on drift, displacement and curvature. The disp-based C5/C6 shear is about 10 % higher.
- **Collapse:** a run that still does not converge, or a column drift above 5 %. Higher levels of that record are then marked collapsed without running.
- **Screening:** `screen_ida.py` lists runs that did not converge and any column shear above the bending limits (7 MN longitudinal, 10 MN transverse).
