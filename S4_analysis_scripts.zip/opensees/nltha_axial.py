"""Copy of nltha.py (26 Oct) that also records the axial force range of every column leg (N_min, N_max at the base
element, kN, compression negative), for the check of how the vertical component acts on the short crown columns.
Only the extra bookkeeping differs; the analysis is identical.

Nonlinear time history of the fibre model (v3, pinned bearings) for the IDA.
Gravity first (element and nodal masses x g), then uniform excitation from a 3-column record (X long, Y trans, Z vert, m/s2).
Damping: mass-proportional alpha = 0.715 (5 % at T = 0.88 s, as Farahani and the 7-record benchmark). Integration: HHT, alpha = 0.9.
Engineering demand parameters (peaks over the record):
  - column drift ratio in X and Y per column leg (cap node relative to base node, divided by the height)
  - deformation drift in X and Y per leg: chord drift minus the rotation of the base node (damage measure)
  - shear at the base element of every column leg (local y and z, kN) for the shear checks of the short columns
  - arch section curvature about both axes at the two springing sections and the largest anywhere in the arch
  - arch crown and deck crown displacements relative to the ground, measured from the gravity state; residual column drifts
Multi-support: give the .npz of svgm.py instead of the record csv (imposed displacements at every support; case xyz;
committed-stiffness damping; crown displacements relative to the mean springing ground motion).
Run: python nltha.py <record.csv | svgm.npz> <scale> <case: xyz | xy> <out.json> [disp56 | dispspr | dispcol]"""
import json
import os
import sys
import time

import numpy as np

REC, SCALE, CASE, OUT = sys.argv[1], float(sys.argv[2]), sys.argv[3], sys.argv[4]
# optional "disp56": displacement-based elements in the C5/C6 legs. Used only to repeat runs where the force-based
# elements there fail to converge (their sections go into softening); in converged runs the two agree within 1-2 % on
# drifts, displacements and curvatures, and the disp-based C5/C6 shear is about 10 % higher (check of 24 Oct)
DISP56 = len(sys.argv) > 5 and sys.argv[5] in ("disp56", "dispspr", "dispcol")
# optional "dispspr" (implies disp56): displacement-based elements also in the two arch springing elements. Multi-support
# runs only: the differential support motion bends the springings, and the force-based springing element (element 66,
# right springing) fails to find compatible forces at small column drifts (0.2-0.8 %), check of 25 Oct. A
# displacement-based element does not localize, so its end curvature is read without the hinge regularization
DISPSPR = len(sys.argv) > 5 and sys.argv[5] in ("dispspr", "dispcol")
# optional "dispcol" (implies dispspr): displacement-based elements in every column leg. Last fallback for
# multi-support runs whose force-based C1 legs fail to converge at small drift (element 111, check of 25 Oct)
DISPCOL = len(sys.argv) > 5 and sys.argv[5] == "dispcol"
X_SPR = (118.8 - 140.27 / 2, 118.8 + 140.27 / 2)   # arch springings, as cetina_model.py
sys.argv = ["cetina_model.py", "fibre", "0", "v3", "pinned"]
import openseespy.opensees as _ops

_ELE_MASS = {}
_ELE_TYPE = {}
_element = _ops.element


def _record(*a):
    _ELE_TYPE[a[1]] = a[0]
    if "-mass" in a:
        _ELE_MASS[a[1]] = (a[2], a[3], float(a[a.index("-mass") + 1]))
    if a[0] == "forceBeamColumn":
        ci, cj = _ops.nodeCoord(a[2]), _ops.nodeCoord(a[3])
        if DISP56 and abs(ci[0] - cj[0]) < 1e-6 and abs(ci[1] - cj[1]) < 1e-6 and (DISPCOL or round(ci[0] / 21.6) in (5, 6)):
            a = ("dispBeamColumn",) + tuple(a[1:])
            _ELE_TYPE[a[1]] = "forceBeamColumn"   # still a fibre column for the member lists below
            return _element(*a)
        if DISPSPR and any(abs(c[0] - xs) < 0.05 and abs(c[1]) < 1e-6 for c in (ci, cj) for xs in X_SPR):
            a = ("dispBeamColumn",) + tuple(a[1:])
            _ELE_TYPE[a[1]] = "forceBeamColumn"   # still a fibre arch element for the member lists below
            return _element(*a)
        a = a + ("-iter", 50, 1e-10)   # more element iterations and a 1e-10 element tolerance: the defaults (10, 1e-12) failed in column legs under large cycles (RSN 767 at 0.5 g)
    return _element(*a)


_ops.element = _record
import cetina_model as cm
_ops.element = _element
ops = cm.ops
G = 9.81
t0 = time.time()

# --- members
coord = {n: np.array(ops.nodeCoord(n)) for n in ops.getNodeTags()}
fibre = [e for e, typ in _ELE_TYPE.items() if typ == "forceBeamColumn"]
cols = {}   # (k, side) -> list of elements bottom to top
for e in fibre:
    i, j = ops.eleNodes(e)
    if abs(coord[i][0] - coord[j][0]) < 1e-6 and abs(coord[i][1] - coord[j][1]) < 1e-6:
        k = int(round(coord[i][0] / cm.SPAN_DECK))
        side = "L" if coord[i][1] < 0 else "R"
        cols.setdefault((k, side), []).append(e)
for key in cols:
    cols[key].sort(key=lambda e: coord[ops.eleNodes(e)[0]][2])
arch_set = set(cm.arch_nodes)
arch_els = [e for e in fibre if set(ops.eleNodes(e)) <= arch_set]
arch_els.sort(key=lambda e: coord[ops.eleNodes(e)[0]][0])
spr = {"left": (arch_els[0], 1), "right": (arch_els[-1], 5)}   # springing integration points (Lobatto, 5 points)
col_base = {key: ops.eleNodes(es[0])[0] for key, es in cols.items()}
col_top = {key: ops.eleNodes(es[-1])[1] for key, es in cols.items()}
col_h = {key: coord[col_top[key]][2] - coord[col_base[key]][2] for key in cols}
crown = min(cm.arch_nodes, key=lambda n: abs(coord[n][0] - cm.X_CROWN))
deck_crown = min(cm.deck_nodes, key=lambda n: abs(coord[n][0] - cm.X_CROWN))

# --- gravity with the full (nodal + element) mass
mass = {n: ops.nodeMass(n, 1) for n in coord}
for i, j, m in _ELE_MASS.values():
    L = np.linalg.norm(coord[i] - coord[j])
    mass[i] += 0.5 * m * L
    mass[j] += 0.5 * m * L
ops.constraints("Transformation"); ops.numberer("RCM"); ops.system("UmfPack")
ops.timeSeries("Linear", 1)
ops.pattern("Plain", 1, 1)
for n, m in mass.items():
    if m > 0:
        ops.load(n, 0, 0, -m * G, 0, 0, 0)
ops.test("NormDispIncr", 1e-8, 50); ops.algorithm("Newton")
ops.integrator("LoadControl", 0.1); ops.analysis("Static")
if ops.analyze(10) != 0:
    sys.exit("gravity failed")
ops.loadConst("-time", 0.0)
ops.wipeAnalysis()
grav_u = {n: np.array([ops.nodeDisp(n, k) for k in (1, 2, 3)]) for n in (crown, deck_crown)}
grav_drift = {key: [ops.nodeDisp(col_top[key], d) - ops.nodeDisp(col_base[key], d) for d in (1, 2)] for key in cols}

# --- excitation
MSE = REC.endswith(".npz")
if MSE:
    # multi-support: imposed ground displacements per support from svgm.py (stations at X_SUP); all three components
    g = np.load(REC)
    dt_gm = float(g["t"][1] - g["t"][0])
    t_rec_end = float(g["t"][-1])
    xs = g["x"]
    sup = [(n, dof) for n in ops.getFixedNodes() for dof in ops.getFixedDOFs(n) if dof <= 3]
    spr_nodes = [n for n in ops.getFixedNodes() if n in arch_set]
    for n, dof in sup:
        ops.remove("sp", n, dof)   # the imposed motion replaces the homogeneous fix on that DOF
    ops.pattern("MultipleSupport", 10)
    tag = 10
    for n, dof in sup:
        j = int(np.argmin(abs(xs - coord[n][0])))
        ts = []
        for q in ("disp", "vel", "acc"):   # all three given (consistent, from svgm.py), so OpenSees does not differentiate
            tag += 1
            ops.timeSeries("Path", tag, "-dt", dt_gm, "-values", *(SCALE * g[q][dof - 1, j]))
            ts.append(tag)
        ops.groundMotion(tag, "Plain", "-disp", ts[0], "-vel", ts[1], "-accel", ts[2])
        ops.imposedMotion(n, dof, tag)
else:
    d = np.loadtxt(REC, delimiter=",", skiprows=1)
    dt_gm = d[1, 0] - d[0, 0]
    t_rec_end = d[-1, 0]
    dirs = (1, 2, 3) if CASE == "xyz" else (1, 2)
    for k, dof in enumerate(dirs):
        ops.timeSeries("Path", 10 + k, "-dt", dt_gm, "-values", *(SCALE * d[:, dof]))
        ops.pattern("UniformExcitation", 10 + k, dof, "-accel", 10 + k)
# damping: mass-proportional (default, as calibrated) or, with NLTHA_DAMPING=kcomm, committed-stiffness-proportional
# 5 % at T1 = 0.94 s. Multi-support runs need the latter (mass-proportional damping acts on the absolute velocity and
# would damp the rigid-body ground motion); their uniform reference runs use it too, so the comparison is like for like
DAMPING = "kcomm" if MSE else os.environ.get("NLTHA_DAMPING", "mass")
if DAMPING == "kcomm":
    ops.rayleigh(0.0, 0.0, 0.0, 0.05 * 0.94 / np.pi)
else:
    ops.rayleigh(0.715, 0.0, 0.0, 0.0)
ops.constraints("Transformation"); ops.numberer("RCM"); ops.system("UmfPack")
ops.test("NormDispIncr", 1e-6, 30); ops.algorithm("Newton")
ops.integrator("HHT", 0.9); ops.analysis("Transient")   # HHT alpha 0.9: damps the step-to-step shear and axial oscillation of the
# short crown columns that average-acceleration Newmark left undamped (C5/C6 shear spikes to 13 MN, check of 23 Oct)
DT = min(0.0025 if MSE else 0.01, dt_gm)   # multi-support: at 0.01 s the supports move up to 2.4 mm per step and the
# stiff arch springings take that as trial deformation, so the solution diverges (identical-support check of 25 Oct:
# at 0.0025 s the imposed-motion model reproduces the uniform run within 1 %; 0.005 s still fails)
t_end = t_rec_end + 5.0

pk = {"drift_x": {}, "drift_y": {}, "V_long": {}, "V_trans": {}, "ddrift_x": {}, "ddrift_y": {}}
for key in cols:
    for q in pk:
        pk[q][key] = 0.0
pk_spr = {s: [0.0, 0.0] for s in spr}
pk_arch = [0.0, 0.0, None]
pk_disp = {"crown": np.zeros(3), "deck_crown": np.zeros(3)}


def step(dt):
    if ops.analyze(1, dt) == 0:
        return True
    if MSE:   # first fallback with imposed motion: plain Newton on substeps (smaller support increments)
        for n_sub in (4, 16):
            if all(ops.analyze(1, dt / n_sub) == 0 for _ in range(n_sub)):
                return True
    for alg, n_sub in ((("ModifiedNewton", "-initial"), 2), (("KrylovNewton",), 4), (("NewtonLineSearch",), 8)):
        ops.algorithm(*alg)
        ok = all(ops.analyze(1, dt / n_sub) == 0 for _ in range(n_sub))
        ops.algorithm("Newton")
        if ok:
            return True
    # last resort: small substeps with a relaxed tolerance and more iterations, then the normal test again
    ops.test("NormDispIncr", 1e-4, 100)
    for alg, n_sub in ((("KrylovNewton",), 20), (("NewtonLineSearch",), 50), (("ModifiedNewton", "-initial"), 100)):
        ops.algorithm(*alg)
        ok = all(ops.analyze(1, dt / n_sub) == 0 for _ in range(n_sub))
        if ok:
            break
    ops.algorithm("Newton")
    ops.test("NormDispIncr", 1e-6, 30)
    return ok


NMIN, NMAX = {}, {}
N_GRAV = {key: ops.eleResponse(cols[key][0], "localForce")[0] for key in cols}
t, ok = 0.0, True
while t < t_end - 1e-9:
    if not step(DT):
        ok = False
        break
    t = ops.getTime()
    for key in cols:
        b, tp, h = col_base[key], col_top[key], col_h[key]
        pk["drift_x"][key] = max(pk["drift_x"][key], abs(ops.nodeDisp(tp, 1) - ops.nodeDisp(b, 1)) / h)
        pk["drift_y"][key] = max(pk["drift_y"][key], abs(ops.nodeDisp(tp, 2) - ops.nodeDisp(b, 2)) / h)
        f = ops.eleResponse(cols[key][0], "localForce")   # N, Vy, Vz, T, My, Mz at node i, then node j
        pk["V_long"][key] = max(pk["V_long"][key], abs(f[1]))   # local y = global X for columns
        pk["V_trans"][key] = max(pk["V_trans"][key], abs(f[2]))
        NMIN[key] = min(NMIN.get(key, 1e30), f[0]); NMAX[key] = max(NMAX.get(key, -1e30), f[0])
        # deformation drift: chord drift minus the rigid rotation of the base node (the legs standing on the arch turn
        # with it; for C5/C6 that rotation is most of the transverse chord drift). This is the damage measure.
        pk["ddrift_x"][key] = max(pk["ddrift_x"][key], abs((ops.nodeDisp(tp, 1) - ops.nodeDisp(b, 1)) / h - ops.nodeDisp(b, 5)))
        pk["ddrift_y"][key] = max(pk["ddrift_y"][key], abs((ops.nodeDisp(tp, 2) - ops.nodeDisp(b, 2)) / h + ops.nodeDisp(b, 4)))
    for s, (e, ip) in spr.items():
        dfm = ops.sectionDeformation(e, ip)   # eps, kz, ky, twist
        pk_spr[s] = [max(pk_spr[s][0], abs(dfm[1])), max(pk_spr[s][1], abs(dfm[2]))]
    for e in arch_els[1:-1]:
        for ip in (1, 5):
            dfm = ops.sectionDeformation(e, ip)
            if abs(dfm[2]) > pk_arch[1]:
                pk_arch[1], pk_arch[2] = abs(dfm[2]), float(coord[ops.eleNodes(e)[0 if ip == 1 else 1]][0])
            pk_arch[0] = max(pk_arch[0], abs(dfm[1]))
    ref = np.mean([[ops.nodeDisp(n, k) for k in (1, 2, 3)] for n in spr_nodes], axis=0) if MSE else 0.0
    for name, n in (("crown", crown), ("deck_crown", deck_crown)):
        pk_disp[name] = np.maximum(pk_disp[name], np.abs(np.array([ops.nodeDisp(n, k) for k in (1, 2, 3)]) - ref - grav_u[n]))

resid = {"%d%s" % key: [abs(ops.nodeDisp(col_top[key], dd) - ops.nodeDisp(col_base[key], dd) - grav_drift[key][dd - 1]) / col_h[key]
                        for dd in (1, 2)] for key in cols}
res = {
    "record": os.path.basename(REC), "scale": SCALE, "case": CASE, "disp56": DISP56, "dispspr": DISPSPR, "dispcol": DISPCOL, "damping": DAMPING, "completed": ok, "t_reached": round(t, 3),
    "t_end": round(t_end, 3), "runtime_s": round(time.time() - t0, 1),
    "col_height_m": {"%d%s" % k: round(v, 3) for k, v in col_h.items()},
    **{q: {"%d%s" % k: v for k, v in pk[q].items()} for q in pk},
    "springing_curv_vert_1pm": {s: v[0] for s, v in pk_spr.items()},
    "springing_curv_trans_1pm": {s: v[1] for s, v in pk_spr.items()},
    "arch_max_curv_vert_1pm": pk_arch[0], "arch_max_curv_trans_1pm": pk_arch[1], "arch_max_curv_trans_x_m": pk_arch[2],
    "crown_rel_m": pk_disp["crown"].tolist(), "deck_crown_rel_m": pk_disp["deck_crown"].tolist(),
    "residual_drift": resid,
    "N_grav_kN": {"%d%s" % k: v for k, v in N_GRAV.items()}, "N_min_kN": {"%d%s" % k: v for k, v in NMIN.items()},
    "N_max_kN": {"%d%s" % k: v for k, v in NMAX.items()},
}
json.dump(res, open(OUT, "w"), indent=1)
print(json.dumps({k: res[k] for k in ("completed", "t_reached", "runtime_s", "crown_rel_m", "deck_crown_rel_m")}))
