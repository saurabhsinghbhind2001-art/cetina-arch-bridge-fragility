"""Fragility curves from the IDA stripes (ida_results/<case>/RSNxxx_sa<level>.json), with the component limit states
of limit_states.py (fragility/column_limit_states.json). Lognormal fit by maximum likelihood (Baker 2015).
Components and damage measures:
  - column legs C1-C9: deformation drift (chord drift minus base rotation, ddrift) in X against that column's longitudinal drift limits, drift in Y against its transverse
    limits (yield / spalling / core crushing / ultimate, from moment-curvature analysis);
  - arch springings: vertical and transverse curvature against the springing section limits; beyond yield the
    end-point curvature of the force-based element is spread over a hinge of 0.5 x depth (localization, see
    limit_states.py);
  - C5/C6 shear (brittle, checked separately): longitudinal shear, mean of the two legs (tied by the cap, and the mean
    removes single-leg spikes), over the Priestley et al. (1994) capacity at the leg's displacement ductility; the
    Eurocode truss capacity is used as a lower-bound sensitivity case;
  - collapse: a drift above 5 %, or no convergence with any element variant at a deformation drift of 2 % or more.
    A run that does not converge below 2 % is a numerical failure and is left out at that level. A collapsed run
    exceeds every state.
System damage state = the worst component (series system).
Run: python fragility.py <ida_results folder> <case> <limit_states.json> <out prefix>"""
import glob, json, os, sys
import numpy as np
from scipy.optimize import minimize
from scipy.stats import norm, binom

DS = ["slight", "moderate", "extensive", "complete"]
COLLAPSE_DRIFT = 0.05
NUMERICAL_DRIFT = 0.02


def v_priestley(cap, mu):
    k_ratio = (0.29 if mu <= 2 else max(0.10, 0.29 - (mu - 2) * 0.095)) / 0.29
    return cap["Vc"] * k_ratio + cap["Vs"] + cap["Vp"]


def component_levels(r, L):
    """Damage level reached (0 none .. 4 complete) by each component, and the shear D/C values."""
    out = {}
    for key, d in r["drift_x"].items():
        c = f"C{key[:-1]}"
        for q, ax in (("ddrift_x", "long"), ("ddrift_y", "trans")):
            lim = L[c][ax]["drift"]
            out[f"{c} {ax}"] = max(out.get(f"{c} {ax}", 0), sum(r[q][key] > lim[ds] for ds in DS))
    A = L["arch_springing"]
    for q, ax in (("springing_curv_vert_1pm", "vertical"), ("springing_curv_trans_1pm", "transverse")):
        ky = A[ax]["curvature_1pm"]["slight"]
        k_ip = max(r[q].values())
        # regularized (force-based localization); a disp-based springing element (dispspr runs) does not localize
        k = k_ip if (k_ip <= ky or r.get("dispspr")) else ky + (k_ip - ky) * A["ip_weight_m"] / A["hinge_length_m"][ax]
        out[f"arch springing {ax}"] = sum(k > A[ax]["curvature_1pm"][ds] for ds in DS)
    dc = {}
    for c in (5, 6):
        v = 0.5 * (r["V_long"][f"{c}L"] + r["V_long"][f"{c}R"])
        lim = L[f"C{c}"]["long"]
        mu = max(r["ddrift_x"][f"{c}L"], r["ddrift_x"][f"{c}R"]) / lim["drift"]["slight"]
        cap = lim["shear_capacity_mu1"]
        dc[c] = (v / v_priestley(cap, mu), v / cap["V_EC_truss"])
    return out, dc


def fit(levels, n, k):
    """MLE lognormal (theta, beta) for k exceedances out of n at each level."""
    levels, n, k = map(np.asarray, (levels, n, k))
    def nll(p):
        th, be = np.exp(p)
        pr = np.clip(norm.cdf(np.log(levels / th) / be), 1e-9, 1 - 1e-9)
        return -binom.logpmf(k, n, pr).sum()
    th0 = levels[np.argmin(abs(k / n - 0.5))]
    res = minimize(nll, [np.log(th0), np.log(0.4)], method="Nelder-Mead")
    return tuple(np.exp(res.x))


def main(out, case, lsfile, prefix):
    L = json.load(open(lsfile))
    rows = {}
    for f in glob.glob(os.path.join(out, case, "*.json")):
        rec, lv = os.path.basename(f)[:-5].split("_sa")
        r = json.load(open(f))
        dd = max(list(r.get("ddrift_x", {}).values()) + list(r.get("ddrift_y", {}).values()) + [0.0])
        if not r.get("completed") and not r.get("skipped") and dd < NUMERICAL_DRIFT:
            continue   # numerical non-convergence at small drift: not collapse, left out at this level
        if r.get("skipped") or not r.get("completed"):
            rows.setdefault(float(lv), []).append((rec, True, None, None, None))
            continue
        drift = max(list(r["ddrift_x"].values()) + list(r["ddrift_y"].values()))
        comp, dc = component_levels(r, L)
        rows.setdefault(float(lv), []).append((rec, drift > COLLAPSE_DRIFT, drift, comp, dc))
    levels = sorted(rows)
    tests = {}
    for i, ds in enumerate(DS, 1):
        tests[f"system {ds}"] = lambda comp, dc, i=i: max(comp.values()) >= i
    for comp_name in ("C5 long", "C1 trans", "arch springing transverse", "arch springing vertical"):
        tests[f"{comp_name} moderate"] = lambda comp, dc, n=comp_name: comp[n] >= 2
    tests["C5/C6 shear failure (Priestley)"] = lambda comp, dc: max(v[0] for v in dc.values()) > 1
    tests["C5/C6 shear failure (EC truss, lower bound)"] = lambda comp, dc: max(v[1] for v in dc.values()) > 1
    tests["collapse"] = lambda comp, dc: False
    table = {}
    for name, test in tests.items():
        n = [len(rows[l]) for l in levels]
        k = [sum(1 for _, col, _, comp, dc in rows[l] if col or test(comp, dc)) for l in levels]
        th, be = fit(levels, n, k) if 0 < sum(k) < sum(n) else (float("nan"), float("nan"))
        table[name] = dict(median_sa_g=round(th, 3), beta=round(be, 3), n=n, k=k)
        print(f"{name:45s} median Sa(T1) {th:.3f} g  beta {be:.2f}   " + " ".join(f"{a}/{b}" for a, b in zip(k, n)))
    # governing component per system damage state: the component reaching it at the lowest level, per record
    gov = {}
    for i, ds in enumerate(DS, 1):
        cnt = {}
        for rec in sorted({r for l in levels for r, *_ in rows[l]}):
            for l in levels:
                hit = [x for x in rows[l] if x[0] == rec]
                if not hit or hit[0][1] or hit[0][3] is None:
                    continue
                names = [c for c, v in hit[0][3].items() if v >= i]
                if names:
                    for c in names:
                        cnt[c] = cnt.get(c, 0) + 1
                    break
        gov[ds] = dict(sorted(cnt.items(), key=lambda x: -x[1])[:5])
        print(f"first to reach {ds}: {gov[ds]}")
    json.dump(dict(case=case, levels_sa_g=levels, states=table, governing=gov), open(prefix + ".json", "w"), indent=1)

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 4.4))
    recs = sorted({r for l in levels for r, *_ in rows[l]})
    for rec in recs:
        pts = [(l, x[2] * 100) for l in levels for x in rows[l] if x[0] == rec and not x[1]]
        if pts:
            a1.plot([p[1] for p in pts], [p[0] for p in pts], color="0.65", lw=0.7)
    med = [np.median([x[2] * 100 if not x[1] else 99 for x in rows[l]]) for l in levels]
    a1.plot(med, levels, color="k", lw=2, label="median")
    a1.set_xlim(0, 6); a1.set_xlabel("max column drift (%)"); a1.set_ylabel("Sa(T1 = 0.94 s) (g)")
    a1.set_title(f"IDA curves, case {case}"); a1.legend()
    x = np.linspace(0.01, max(levels) * 1.15, 300)
    show = [f"system {ds}" for ds in DS] + ["C5/C6 shear failure (Priestley)", "C5/C6 shear failure (EC truss, lower bound)", "collapse"]
    colors = ["#4C78A8", "#59A14F", "#F28E2B", "#E15759", "#B07AA1", "#B07AA1", "#000000"]
    styles = ["-", "-", "-", "-", "-", "--", "-"]
    for name, c, ls in zip(show, colors, styles):
        t = table[name]
        if np.isnan(t["median_sa_g"]):
            continue
        a2.plot(x, norm.cdf(np.log(x / t["median_sa_g"]) / t["beta"]), color=c, ls=ls,
                label=f"{name}: {t['median_sa_g']:.2f} g, β {t['beta']:.2f}")
        a2.plot(levels, np.array(t["k"]) / np.array(t["n"]), "o", color=c, ms=3)
    a2.set_xlabel("Sa(T1 = 0.94 s) (g)"); a2.set_ylabel("P(exceed)"); a2.set_ylim(0, 1)
    a2.set_title("Fragility"); a2.legend(fontsize=7, loc="lower right")
    fig.tight_layout()
    fig.savefig(prefix + ".png", dpi=150)


if __name__ == "__main__":
    main(*sys.argv[1:5])
