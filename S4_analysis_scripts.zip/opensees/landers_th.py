"""Linear 3-component Landers (RSN 855) time history on the calibrated fibre-model geometry (elastic members).
Run: python landers_th.py  ->  peak relative displacements at the arch crown and deck right end.
Damping: mass-proportional alpha = 0.715 (Farahani). Uniform support excitation."""
import sys, os
import numpy as np
sys.argv = ["cetina_model.py", "elastic", "0", "v3", "pinned"]
import cetina_model as cm
ops = cm.ops

GM = os.path.join(os.path.dirname(__file__), "..", "ground_motions", "landers_rsn855", "landers_XYZ_ms2.csv")
d = np.loadtxt(GM, delimiter=",", skiprows=1)
dt_gm = d[1, 0] - d[0, 0]

def nearest(x, y, z):
    return min(ops.getNodeTags(), key=lambda n: np.linalg.norm(np.array(ops.nodeCoord(n)) - (x, y, z)))
crown = nearest(cm.X_CROWN, 0.0, cm.arch_z(cm.X_CROWN))
deck_end = cm.deck_at[cm.N_SPANS]
print("crown node", crown, ops.nodeCoord(crown), "deck end", deck_end, ops.nodeCoord(deck_end))

ops.constraints("Transformation"); ops.numberer("RCM"); ops.system("UmfPack")
lam = ops.eigen(3)
print("f1-3 (Hz):", np.round(np.sqrt(lam) / 2 / np.pi, 3))
ops.rayleigh(0.715, 0.0, 0.0, 0.0)
for i, dof in enumerate((1, 2, 3)):
    ops.timeSeries("Path", 10 + i, "-dt", dt_gm, "-values", *d[:, 1 + i])
    ops.pattern("UniformExcitation", 10 + i, dof, "-accel", 10 + i)
ops.test("NormDispIncr", 1e-8, 10); ops.algorithm("Linear"); ops.integrator("Newmark", 0.5, 0.25)
ops.analysis("Transient")
dt, nsteps = 0.01, int((d[-1, 0] + 5.0) / 0.01)
ug = {k: np.cumsum(np.cumsum(d[:, 1 + k]) * dt_gm) * dt_gm for k in range(3)}  # crude ground disp (info only)
peak = {"crown": np.zeros(3), "deck_end": np.zeros(3)}
hist = []
for s in range(nsteps):
    if ops.analyze(1, dt) != 0:
        print("failed at", s * dt); break
    rc = [ops.nodeDisp(crown, k + 1) for k in range(3)]
    rd = [ops.nodeDisp(deck_end, k + 1) for k in range(3)]
    peak["crown"] = np.maximum(peak["crown"], np.abs(rc))
    peak["deck_end"] = np.maximum(peak["deck_end"], np.abs(rd))
    hist.append([(s + 1) * dt] + rc + rd)
np.savetxt(os.path.join(os.path.dirname(__file__), "landers_th_relative_disp.csv"), np.array(hist), delimiter=",",
           fmt="%.5f", header="t,crown_ux,crown_uy,crown_uz,deckend_ux,deckend_uy,deckend_uz", comments="")
print("Peak RELATIVE displacement (m)   X long   Y trans   Z vert")
print("  arch crown                   %7.3f  %7.3f  %7.3f" % tuple(peak["crown"]))
print("  deck right end               %7.3f  %7.3f  %7.3f" % tuple(peak["deck_end"]))
