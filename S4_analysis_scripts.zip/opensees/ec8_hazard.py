"""Eurocode 8 hazard step: fragility curves combined with the EC8 elastic spectrum and the EC8 hazard-curve
approximation, for every analysis case.
  - Site: ground type A (limestone), Type 1 spectrum (S = 1.0, TB = 0.15, TC = 0.4, TD = 2.0 s), 5 % damping,
    importance factor 1.0. At T1 = 0.94 s (TC < T1 < TD): Sa(T1) = 2.5 agR TC / T1.
  - Hazard curve: H(a) = (1/475) (a / agR)^-k applied to Sa(T1) (the spectral shape is fixed, so Sa scales with
    agR). Return-period levels: agR(TR) = agR (TR/475)^(1/k). k = ln(475/95) / ln(ag475/ag95) = 2.32 from the
    Croatian map pair at Kastela (0.22 g / 0.11 g); k = 3 (EN 1998-1, 2.1(4) Note) is given as a sensitivity.
  - agR: 0.22 g, the 475-year ground-type-A value of the Croatian national map (HRN EN 1998-1/NA, Herak et al.)
    published for Kastela (Applied Sciences 2021, 11, 5997), the nearest documented point, about 25 km west of the
    bridge. The map value at the bridge itself was not available; 0.25 and 0.30 g bracket a higher inland value.
  - Mean annual frequency of exceedance (Cornell et al. 2002 closed form): lambda = H(theta) exp(k^2 beta^2 / 2),
    with beta the total dispersion (record-to-record and beta_c = 0.30 by SRSS). Probability in 50 years:
    1 - exp(-50 lambda). P(DS | TR) = Phi(ln(Sa_TR / theta) / beta).
Run: python ec8_hazard.py <project folder arch-bridge-review>"""
import csv, json, os, sys
import numpy as np
from scipy.stats import norm

ROOT = sys.argv[1]
FR = os.path.join(ROOT, "fragility")
T1, TC, BC = 0.94, 0.4, 0.30
KS = (round(np.log(5) / np.log(2), 2), 3.0)   # base (Croatian map 95/475 pair), EC8 default
AGR = (0.22, 0.25, 0.30)
TR = (95, 475, 2475)
CASES = {"xyz": "fragility_xyz.json", "xy (33 matched)": "fragility_xy_matched33.json",
         "uniform k-damping (10 rec)": "fragility_uniform_kcomm.json",
         "multi-support 1000 m/s": "fragility_mse_va1000.json", "multi-support 500 m/s": "fragility_mse_va500.json"}
STATES = ["system slight", "system moderate", "system extensive", "system complete", "collapse"]


def sa_t1(ag):
    return 2.5 * ag * TC / T1


rows = []
for K in KS:
  for agr in AGR:
      s475 = sa_t1(agr)
      for case, f in CASES.items():
          st = json.load(open(os.path.join(FR, f)))["states"]
          for s in STATES:
              th, br = st[s]["median_sa_g"], st[s]["beta"]
              bt = float(np.hypot(br, BC))
              lam = (1 / 475) * (th / s475) ** -K * np.exp(0.5 * K ** 2 * bt ** 2)
              row = dict(k=K, agR_g=agr, case=case, state=s.replace("system ", ""), median_sa_g=th, beta_total=round(bt, 3),
                         maf=float(f"{lam:.3g}"), return_period_yr=round(1 / lam), p50yr=round(1 - np.exp(-50 * lam), 4))
              for tr in TR:
                  sa = s475 * (tr / 475) ** (1 / K)
                  row[f"P_given_TR{tr}"] = round(float(norm.cdf(np.log(sa / th) / bt)), 3)
              rows.append(row)
with open(os.path.join(FR, "ec8_hazard_all_cases.csv"), "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0]))
    w.writeheader(); w.writerows(rows)
json.dump(dict(method=__doc__.split("Run:")[0].strip(),
               sa_t1_g={f"k{K}_agR{a}": {str(tr): round(sa_t1(a) * (tr / 475) ** (1 / K), 3) for tr in TR} for K in KS for a in AGR},
               rows=rows), open(os.path.join(FR, "ec8_hazard_all_cases.json"), "w"), indent=1)
for a in AGR:
    print("agR", a, "Sa(T1) at 95/475/2475 yr (base k):", [round(sa_t1(a) * (tr / 475) ** (1 / KS[0]), 3) for tr in TR])
for r in rows:
    if r["agR_g"] == 0.22:
        print(f"k {r['k']}  {r['case']:28s} {r['state']:10s} MAF {r['maf']:.2e}  TR {r['return_period_yr']:>7d}  P50 {r['p50yr']:.4f}  "
              f"P|95 {r['P_given_TR95']:.3f}  P|475 {r['P_given_TR475']:.3f}  P|2475 {r['P_given_TR2475']:.3f}")
