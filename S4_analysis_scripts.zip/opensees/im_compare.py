"""Intensity-measure comparison from the existing IDA runs (no new analyses). Records are scaled linearly, so a record's
capacity in any IM is its capacity in Sa(T1) times IM/Sa(T1) of the unscaled record. For each damage state the
record capacity is the geometric mean of the last level below and the first level at or above the state (collapse
counts as exceeding every state; numerical failures are left out). Efficiency = standard deviation of ln capacity
over records (lower is better). Sufficiency = p-value of the regression of ln capacity on magnitude and on
rupture distance (p > 0.05: no detectable dependence).
Run: python im_compare.py <project folder arch-bridge-review> <case xyz|xy>"""
import glob, json, os, sys
import numpy as np
from scipy.stats import linregress

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fragility

ROOT, CASE = sys.argv[1], sys.argv[2]
G = 9.80665
T1 = 0.94
DS = fragility.DS


def sa(acc, dt, T, z=0.05):
    """Pseudo-spectral acceleration (g) by the Newmark average-acceleration method."""
    w = 2 * np.pi / T
    m, c, k = 1.0, 2 * z * w, w * w
    kh = k + 2 * c / dt + 4 * m / dt ** 2
    u = v = 0.0
    a = -acc[0]
    umax = 0.0
    for p in -acc[1:]:
        dp = p + m * (4 * u / dt ** 2 + 4 * v / dt + a) + c * (2 * u / dt + v)
        un = dp / kh
        vn = 2 * (un - u) / dt - v
        a = 4 * (un - u) / dt ** 2 - 4 * v / dt - a
        u, v = un, vn
        umax = max(umax, abs(u))
    return w * w * umax / G


recs = {r["name"]: r for r in json.load(open(os.path.join(ROOT, "ground_motions", "ida36", "processed", "records.json")))["records"]}
L = json.load(open(os.path.join(ROOT, "fragility", "column_limit_states.json")))
TAVG = np.linspace(0.2 * T1, 1.5 * T1, 10)

ims = {}
for name in recs:
    f = os.path.join(ROOT, "ground_motions", "ida36", "processed", f"{name}.csv")
    d = np.loadtxt(f, delimiter=",", skiprows=1)
    dt = d[1, 0] - d[0, 0]
    ax, ay = d[:, 1], d[:, 2]
    vx, vy = np.cumsum(ax) * dt, np.cumsum(ay) * dt
    sx, sy = sa(ax, dt, T1), sa(ay, dt, T1)
    avg = np.exp(np.mean([np.log(np.sqrt(sa(ax, dt, t) * sa(ay, dt, t))) for t in TAVG]))
    ims[name] = {
        "Sa(T1) geo. mean": np.sqrt(sx * sy),
        "Sa(T1) transverse": sy,
        "Sa_avg(0.2-1.5 T1)": avg,
        "PGA geo. mean": np.sqrt(np.abs(ax).max() * np.abs(ay).max()) / G,
        "PGV geo. mean (m/s)": np.sqrt(np.abs(vx).max() * np.abs(vy).max()),
    }

# per record and level: highest system damage level reached (0-4, 5 = collapse); numerical failures skipped
lev = {}
for f in glob.glob(os.path.join(ROOT, "ida_results", CASE, "*.json")):
    rec, lv = os.path.basename(f)[:-5].split("_sa")
    if rec not in ims:
        continue
    r = json.load(open(f))
    dd = max(list(r.get("ddrift_x", {}).values()) + list(r.get("ddrift_y", {}).values()) + [0.0])
    if r.get("nonconverged") or (not r.get("completed") and not r.get("skipped") and dd < fragility.NUMERICAL_DRIFT):
        continue
    if r.get("skipped") or not r.get("completed") or dd > fragility.COLLAPSE_DRIFT:
        s = 5
    else:
        comp, _ = fragility.component_levels(r, L)
        s = max(comp.values())
    lev.setdefault(rec, {})[float(lv)] = s

states = DS + ["collapse"]
cap = {s: {} for s in states}
for rec, d in lev.items():
    ls = sorted(d)
    for i, s in enumerate(states, 1):
        hit = [l for l in ls if d[l] >= i]
        if not hit:
            continue
        below = [l for l in ls if l < hit[0]]
        cap[s][rec] = np.sqrt(hit[0] * below[-1]) if below else hit[0]

base = "Sa(T1) geo. mean"
res = {}
for s in states:
    names = sorted(cap[s])
    M = np.array([float(recs[n]["magnitude"]) for n in names])
    R = np.array([float(recs[n]["rrup_km"]) for n in names])
    res[s] = {"n_records": len(names)}
    for im in ims[names[0]]:
        c = np.log([cap[s][n] / ims[n][base] * ims[n][im] for n in names])
        res[s][im] = {"beta": round(float(np.std(c, ddof=1)), 3),
                      "median": round(float(np.exp(c.mean())), 3),
                      "p_M": round(float(linregress(M, c).pvalue), 3),
                      "p_lnR": round(float(linregress(np.log(R), c).pvalue), 3)}
json.dump(dict(case=CASE, T1_s=T1, method=__doc__.split("Run:")[0].strip(), states=res),
          open(os.path.join(ROOT, "fragility", f"im_compare_{CASE}.json"), "w"), indent=1)
for s in states:
    print(s, res[s]["n_records"])
    for im, v in res[s].items():
        if im != "n_records":
            print(f"   {im:22s} beta {v['beta']:.3f}  median {v['median']:.3f}  p_M {v['p_M']:.2f}  p_lnR {v['p_lnR']:.2f}")
