"""Screen finished IDA runs:
- runs that did not converge (with both element types);
- column shear above the bending limit of that column type, or a longitudinal shear in one leg far above its
  twin leg (the two legs are tied by the cap and carry nearly the same longitudinal shear), which flags a numerical spike.
Limits (24 Oct): 1.5 m deep legs level off at about 5.5-6 MN longitudinally; the 1.8 m wide twin-leg frames carry up
to about 10 MN transversely; the 2.4 m deep C2/C9 legs carry more (up to about 11 MN seen under the strongest pulses).
Run: python screen_ida.py <ida_results folder>"""
import glob, json, os, sys

LIMIT_KN = {"V_long": 7000.0, "V_trans": 11000.0}
BIG = (2, 9)
BIG_LONG_KN = 13000.0
TWIN_RATIO = 1.4   # longitudinal only: transversely the frame action loads the compression leg more
out = sys.argv[1]
n = bad = 0
for f in sorted(glob.glob(os.path.join(out, "*", "*.json"))):
    r = json.load(open(f))
    if r.get("skipped"):
        continue
    n += 1
    tag = os.path.relpath(f, out) + (" (disp56)" if r.get("disp56") else "")
    if not r.get("completed"):
        print(f"{tag}: not converged at t = {r.get('t_reached')} of {r.get('t_end')} s")
        continue
    msg = []
    for q in ("V_long", "V_trans"):
        v = r[q]
        for k, x in v.items():
            c = int(k[:-1])
            lim = BIG_LONG_KN if (q == "V_long" and c in BIG) else LIMIT_KN[q]
            twin = v[f"{c}{'R' if k[-1] == 'L' else 'L'}"]
            if x > lim or (q == "V_long" and x > 5000.0 and x > TWIN_RATIO * twin):
                msg.append(f"{q} {k} {x / 1000:.1f} MN (twin {twin / 1000:.1f})")
    if msg:
        bad += 1
        print(f"{tag}: " + ", ".join(msg))
print(f"{n} runs screened, {bad} with shear flags")
