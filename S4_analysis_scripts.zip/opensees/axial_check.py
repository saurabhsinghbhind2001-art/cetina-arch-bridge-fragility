"""Axial-force check for the vertical-component effect (26 Oct): 8 records (5 far-field, 3 near-fault pulse) at
Sa(T1) = 0.8 g, the level around the moderate-damage median, run with and without the vertical component
(nltha_axial.py, mass-proportional damping as the 33-record IDA). Reports, per case, the axial-force swing of the
C5/C6 legs and of the C1 legs about the gravity value, and the C5/C6 longitudinal deformation drift.
Results: ida_results_axial/<case>/<record>_sa0.8.json, summary fragility/axial_check.json.
Run: python axial_check.py <project folder arch-bridge-review> [workers]"""
import json, os, subprocess, sys
from concurrent.futures import ProcessPoolExecutor

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
RECORDS = ["RSN953", "RSN1602", "RSN1787", "RSN1111", "RSN1158", "RSN1063", "RSN1086", "RSN1165"]
LEVEL = "0.8"


def run(args):
    csv, sf, case, out = args
    if not os.path.exists(out):
        subprocess.run([sys.executable, os.path.join(HERE, "nltha_axial.py"), csv, str(sf), case, out], cwd=HERE,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=4 * 3600)
    return out


def main(root, workers=2):
    root = os.path.abspath(root)   # nltha_axial.py runs with cwd = opensees/
    proc = os.path.join(root, "ground_motions", "ida36", "processed")
    recs = {r["name"]: r for r in json.load(open(os.path.join(proc, "records.json")))["records"]}
    out = os.path.join(root, "ida_results_axial")
    jobs = []
    for case in ("xyz", "xy"):
        os.makedirs(os.path.join(out, case), exist_ok=True)
        for name in RECORDS:
            jobs.append((os.path.join(proc, name + ".csv"), recs[name]["scale"][LEVEL], case,
                         os.path.join(out, case, f"{name}_sa{LEVEL}.json")))
    with ProcessPoolExecutor(max_workers=workers) as ex:
        list(ex.map(run, jobs))
    summ = {}
    for name in RECORDS:
        row = {"set": recs[name]["set"], "pga_z_over_pga_h": round(recs[name]["pga_z_g"] / max(recs[name]["pga_x_g"],
                                                                                              recs[name]["pga_y_g"]), 2)}
        for case in ("xyz", "xy"):
            f = os.path.join(out, case, f"{name}_sa{LEVEL}.json")
            if not os.path.exists(f):
                continue
            r = json.load(open(f))
            if not r.get("completed"):
                row[case] = {"completed": False}
                continue
            sw = {}
            for grp, legs in (("C5/C6", ["5L", "5R", "6L", "6R"]), ("C1", ["1L", "1R"])):
                g = np.array([r["N_grav_kN"][k] for k in legs])
                lo = np.array([r["N_min_kN"][k] for k in legs])
                hi = np.array([r["N_max_kN"][k] for k in legs])
                sw[grp] = dict(N_grav_kN=round(float(g.mean())), swing_down_pct=round(float(100 * np.max((g - lo) / abs(g)))),
                               swing_up_pct=round(float(100 * np.max((hi - g) / abs(g)))))
            row[case] = dict(axial=sw, ddrift_x_C56=round(max(r["ddrift_x"][k] for k in ("5L", "5R", "6L", "6R")), 5),
                             springing_curv_vert=round(max(r["springing_curv_vert_1pm"].values()), 6))
        summ[name] = row
        print(name, json.dumps(row))
    json.dump(summ, open(os.path.join(root, "fragility", "axial_check.json"), "w"), indent=1)


if __name__ == "__main__":
    main(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 2)
