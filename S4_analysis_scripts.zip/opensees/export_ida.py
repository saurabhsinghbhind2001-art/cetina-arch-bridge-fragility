"""Export every IDA run to one spreadsheet: one row per run, all recorded results, and the damage state reached.
Sheets: runs (final set), runs_multisupport, runs_set2 (HHT, no corrected drift; superseded), runs_set1 (Newmark; superseded), legend.
Run: python export_ida.py <project folder arch-bridge-review> <out.xlsx>"""
import glob, json, os, sys
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
ROOT, OUT = sys.argv[1], sys.argv[2]
DS = ["none", "slight", "moderate", "extensive", "complete"]


def flat(r):
    row = {}
    for k, v in r.items():
        if isinstance(v, dict):
            for kk, vv in v.items():
                if isinstance(vv, list):
                    for ax, x in zip("xy", vv):
                        row[f"{k}_{kk}_{ax}"] = x
                else:
                    row[f"{k}_{kk}"] = vv
        elif isinstance(v, list):
            for i, vv in enumerate(v):
                row[f"{k}_{'xyz'[i] if len(v) == 3 else i}"] = vv
        else:
            row[k] = v
    return row


def table(folder, with_ds):
    L = json.load(open(os.path.join(ROOT, "fragility", "column_limit_states.json"))) if with_ds else None
    if with_ds:
        from fragility import component_levels
    recs = json.load(open(os.path.join(ROOT, "ground_motions", "ida36", "processed", "records.json")))["records"]
    meta = {r["name"]: r for r in recs}
    rows = []
    for f in sorted(glob.glob(os.path.join(folder, "*", "*.json"))):
        case = os.path.basename(os.path.dirname(f))
        name, lv = os.path.basename(f)[:-5].split("_sa")
        r = json.load(open(f))
        m = meta.get(name, {})
        row = dict(record=name, set=m.get("set"), event=m.get("event"), station=m.get("station"), case=case,
                   sa_t1_g=float(lv), sa_t1_unscaled_g=m.get("sa_t1_gm_g"))
        row.update({k: v for k, v in flat(r).items() if k not in ("record", "case")})
        if with_ds and r.get("completed") and not r.get("skipped"):
            comp, dc = component_levels(r, L)
            row["system_damage_state"] = DS[max(comp.values())]
            row["governing_component"] = max(comp, key=comp.get) if max(comp.values()) else ""
            row["C5C6_shear_DC_priestley"] = max(v[0] for v in dc.values())
            row["C5C6_shear_DC_EC_lower_bound"] = max(v[1] for v in dc.values())
        elif with_ds:
            row["system_damage_state"] = "collapse"
        rows.append(row)
    df = pd.DataFrame(rows)
    return df.sort_values(["case", "record", "sa_t1_g"]) if len(df) else df


legend = pd.DataFrame([
    ("sa_t1_g", "IDA level: Sa(T1 = 0.94 s, 5 %), geometric mean of the horizontals, g"),
    ("scale", "factor applied to all three components of the unscaled record"),
    ("case", "xyz = both horizontals and vertical; xy = horizontals only; mse_va1000 / mse_va500 = multi-support, apparent wave speed 1000 / 500 m/s; uniform_kcomm = uniform xyz reference with the same stiffness-proportional damping"),
    ("disp56 / dispspr / dispcol", "solver fallbacks: disp-based C5/C6 legs / plus arch springing elements / plus every column leg"),
    ("nonconverged", "stopped below 2 % drift with every fallback: numerical, left out of the fit at that level (not collapse)"),
    ("completed / disp56", "run reached the end of the record; disp56 = repeated with displacement-based C5/C6 legs"),
    ("collapsed / skipped", "collapse (no convergence or drift > 5 %); skipped = level above the record's collapse"),
    ("drift_x_*, drift_y_*", "peak chord drift of each leg (cap relative to base / height)"),
    ("ddrift_x_*, ddrift_y_*", "peak deformation drift: chord drift minus base rotation (damage measure)"),
    ("V_long_*, V_trans_*", "peak base shear of each leg, kN (longitudinal X / transverse Y)"),
    ("springing_curv_*", "peak springing section curvature, 1/m (vertical / transverse bending)"),
    ("arch_max_curv_*", "largest curvature anywhere else in the arch, 1/m, and its x position"),
    ("crown_rel_m_*, deck_crown_rel_m_*", "peak arch crown / deck crown displacement from the gravity state, m"),
    ("residual_drift_*", "residual chord drift of each leg at the end, [X, Y]"),
    ("system_damage_state", "worst component damage state (limit states in fragility/column_limit_states.json)"),
    ("C5C6_shear_DC_*", "C5/C6 longitudinal shear demand over capacity (Priestley mean; Eurocode lower bound)"),
], columns=["column", "meaning"])

with pd.ExcelWriter(OUT) as xw:
    table(os.path.join(ROOT, "ida_results"), True).to_excel(xw, sheet_name="runs", index=False)
    table(os.path.join(ROOT, "ida_results_mse"), True).to_excel(xw, sheet_name="runs_multisupport", index=False)
    table(os.path.join(ROOT, "ida_results_v2_no_ddrift"), False).to_excel(xw, sheet_name="runs_set2_superseded", index=False)
    table(os.path.join(ROOT, "ida_results_newmark_superseded"), False).to_excel(xw, sheet_name="runs_set1_superseded", index=False)
    legend.to_excel(xw, sheet_name="legend", index=False)
print("written", OUT)
