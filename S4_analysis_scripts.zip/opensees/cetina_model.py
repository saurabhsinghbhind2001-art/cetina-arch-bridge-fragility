"""
Cetina River deck arch bridge: 3D frame model for OpenSeesPy (draft v0.1)
Units: kN, m, tonne, s.  Axes: X longitudinal, Y transverse, Z vertical (same as the ANSYS v2 model).

Geometry, sections and materials follow Farahani & Maalek (2017) Figs 2-4 and Zderic et al. (2007).
Values marked ASSUMED are not given in the papers; replace them with the dimensions of the ANSYS v2 solid model.

MODEL = "elastic"  -> elastic beams everywhere (for modal calibration against v2)
MODEL = "fibre"    -> force-based fibre elements for arch and columns (Concrete02 + Steel02, 4 % rebar)
"""
import sys
import numpy as np
import openseespy.opensees as ops

MODEL = sys.argv[1] if len(sys.argv) > 1 else "elastic"

# ----------------------------------------------------------------------------- geometry
SPAN_DECK = 21.6                      # 10 deck spans (Fig. 2)
N_SPANS = 10
L_ARCH, RISE = 140.27, 20.58          # arch centreline span and rise (Fig. 2)
X_CROWN = 5.5 * SPAN_DECK             # crown midway between C5 and C6 (Fig. 2); springings 5.47 m inside C2 / C9
X_SPR_L, X_SPR_R = X_CROWN - L_ARCH / 2, X_CROWN + L_ARCH / 2
ARCH_D = 2.5                          # box depth
Z_CAP_BOT = 20.5 + 3.83               # V12 script: column top 20.5 m, springing axis at -3.83 m -> +24.33 here
CAP_D, CAP_B, CAP_LEN = 1.4, 1.5, 8.3 # cap-beam depth, width (long.), length (V12 script)
Z_CAP = Z_CAP_BOT + CAP_D / 2
Z_BRG = Z_CAP_BOT + CAP_D + 0.45      # girder soffit: cap top + 0.10 bearing + 0.35 (V12 script)
Y_COL = 2.70                          # column centrelines at +/-2.70 m (V12 script)
COL_BASE = {1: Z_CAP_BOT - 12.0,      # C1 height 12.0 m (Fig. 2)
            2: Z_CAP_BOT - 20.5,      # C2 height 20.5 m (Fig. 2)
            9: Z_CAP_BOT - 20.5}      # C9 mirrors C2 (ASSUMED)
BIG_COLS = (2, 9)                     # 2.4 x 1.8 m columns on the springings
MONOLITHIC = (1, 2, 3, 8, 9)          # columns fixed to deck; C4-C7 on longitudinally fixed bearings
BEARING_ROT_FIXED = not (len(sys.argv) > 4 and sys.argv[4] == "pinned")  # True reproduces v2 (bonded steel blocks); False = pot bearings, rotations free
N_ARCH_EL = 60
N_COL_EL = 4
N_DECK_EL = 4                         # per span

def arch_z(x):
    """Parabolic centreline (ASSUMED shape; replace with v2 centreline if it differs)."""
    s = (x - X_CROWN) / (L_ARCH / 2)
    return RISE * (1.0 - s * s)

# ----------------------------------------------------------------------------- materials
E_SET = sys.argv[3] if len(sys.argv) > 3 else "v2"
if E_SET == "paper":                  # Farahani Table 1 (static moduli)
    E_45, E_30, E_DECK = 3.62e7, 3.30e7, 3.62e7
elif E_SET in ("transformed", "v3"):          # paper moduli + 4 % rebar as transformed section: Ec*(1 + (Es/Ec - 1)*0.04)
    E_45, E_30, E_DECK = 3.62e7 * (1 + (210 / 36.2 - 1) * 0.04), 3.30e7 * (1 + (210 / 33.0 - 1) * 0.04), 3.62e7
else:                                 # ANSYS v2 Engineering Data: arch 48.2, columns 44.8, girders/slab 40.3 GPa
    E_45, E_30, E_DECK = 4.82e7, 4.48e7, 4.03e7
RHO = 2.5                             # t/m3 (25 kN/m3)
G = lambda E: E / 2.4
SURF_MASS = 449.0 / (N_SPANS * SPAN_DECK)  # t/m, surfacing mass used in v2 (approx 2 kN/m2)
CROSS_GIRDER_MASS = (400.8 if E_SET == "v3" else 471.0) / 11  # t per support line (V3 / v2 cross girders)

# ----------------------------------------------------------------------------- sections
def rects_props(rects):
    """rects: list of (b along local y, h along local z, yc, zc). Returns A, Iy(about y), Iz(about z), centroid."""
    A = sum(b * h for b, h, _, _ in rects)
    yc = sum(b * h * y for b, h, y, _ in rects) / A
    zc = sum(b * h * z for b, h, _, z in rects) / A
    Iy = sum(b * h**3 / 12 + b * h * (z - zc)**2 for b, h, _, z in rects)
    Iz = sum(h * b**3 / 12 + b * h * (y - yc)**2 for b, h, y, _ in rects)
    return A, Iy, Iz, yc, zc

def box(W, D, tw, tf):
    """Hollow box: W along transverse, D along depth, web thickness tw, flange thickness tf."""
    A = W * D - (W - 2 * tw) * (D - 2 * tf)
    I_dep = W * D**3 / 12 - (W - 2 * tw) * (D - 2 * tf)**3 / 12       # bending in the depth direction
    I_wid = D * W**3 / 12 - (D - 2 * tf) * (W - 2 * tw)**3 / 12       # bending in the width direction
    J = 4 * ((W - tw) * (D - tf))**2 / (2 * (W - tw) / tf + 2 * (D - tf) / tw)
    return A, I_dep, I_wid, J

ARCH = box(8.0, ARCH_D, 0.5, 0.4)     # webs 0.5, chords 0.4 between the first spandrel columns
ARCH_TF_SPR = 0.6                     # chords thicken to 0.6 m at the springings (Farahani p. 610)
# Component masses of the ANSYS v2 solid model (solve.out mass summary), used to calibrate non-structural mass
V2_MASS = {"arch": 3813.0, "columns + caps": 1546.0, "deck (slab + girders)": 2678.0}
if E_SET == "v3":   # V3 solid model (Mechanical selection info, 19 Oct): columns 953.9 + caps 438.2; girders 1775.6 + slab 1123.2
    V2_MASS = {"arch": 3727.3, "columns + caps": 1392.1, "deck (slab + girders)": 2898.8}
CALIBRATE_MASS = True
COL = box(1.8, 1.5, 0.3, 0.3)         # W = transverse 1.8, D = longitudinal 1.5
COL_BIG = box(1.8, 2.4, 0.3, 0.3)     # W = 1.8, D = 2.4
CAP = (CAP_B * CAP_D, CAP_B * CAP_D**3 / 12, CAP_D * CAP_B**3 / 12, 0.2)
# deck: 10.2 x 0.2 slab + 5 T-girders (web 0.4 x 0.9 + bulb 0.94 x 0.3, ASSUMED to match 693 m3 of girders)
deck_rects = [(10.2, 0.2, 0.0, 1.3)]   # V12 script: slab on 5 plain webs 0.4 x 1.2 (no girder flange)
for yg in (-3.8, -1.9, 0.0, 1.9, 3.8):
    if E_SET == "v3":                  # V13 geometry: web 0.4 x 1.09 + top flange 1.9 x 0.11 under the slab
        deck_rects += [(0.4, 1.09, yg, 0.545), (1.9, 0.11, yg, 1.145)]
    else:
        deck_rects += [(0.4, 1.2, yg, 0.6)]
A_D, I_DV, I_DT, _, ZC_D = rects_props(deck_rects)  # I_DV vertical bending, I_DT transverse bending
J_D = 10.2 * 0.2**3 / 3 + 5 * (1.2 * 0.4**3 / 3)
Z_DECK = Z_BRG + ZC_D

# ----------------------------------------------------------------------------- mass calibration to v2
def arch_tf(x):
    """Chord thickness: 0.4 m between C3 and C8, linear to 0.6 m at the springings."""
    xa, xb = 3 * SPAN_DECK, 8 * SPAN_DECK
    if x < xa:
        return 0.4 + (ARCH_TF_SPR - 0.4) * (xa - x) / (xa - X_SPR_L)
    if x > xb:
        return 0.4 + (ARCH_TF_SPR - 0.4) * (x - xb) / (X_SPR_R - xb)
    return 0.4

def _arch_struct_mass_and_length(n=2000):
    x = np.linspace(X_SPR_L, X_SPR_R, n + 1)
    z = arch_z(x)
    ds = np.hypot(np.diff(x), np.diff(z))
    xm = 0.5 * (x[1:] + x[:-1])
    return sum(RHO * box(8.0, ARCH_D, 0.5, arch_tf(xi))[0] * d for xi, d in zip(xm, ds)), ds.sum()

def _col_struct_mass_and_length():
    m = L = 0.0
    for k in range(1, 10):
        x = k * SPAN_DECK
        z0 = arch_z(x) + ARCH_D / 2 if X_SPR_L < x < X_SPR_R else COL_BASE[k]
        A = (COL_BIG if k in BIG_COLS else COL)[0]
        m += 2 * RHO * A * (Z_CAP - z0)
        L += 2 * (Z_CAP - z0)
    return m + 9 * RHO * CAP[0] * CAP_LEN, L

ARCH_EXTRA_MASS = COL_EXTRA_MASS = 0.0
DECK_MASS_FACTOR = 1.0
if CALIBRATE_MASS:
    m_a, L_a = _arch_struct_mass_and_length()
    ARCH_EXTRA_MASS = max(0.0, (V2_MASS["arch"] - m_a) / L_a)
    m_c, L_c = _col_struct_mass_and_length()
    COL_EXTRA_MASS = max(0.0, (V2_MASS["columns + caps"] - m_c) / L_c)
    DECK_MASS_FACTOR = V2_MASS["deck (slab + girders)"] / (RHO * A_D * N_SPANS * SPAN_DECK)

# ----------------------------------------------------------------------------- build
ops.wipe()
ops.model("basic", "-ndm", 3, "-ndf", 6)
_tag = {"n": 0, "e": 0, "t": 0}

def node(x, y, z):
    _tag["n"] += 1
    ops.node(_tag["n"], float(x), float(y), float(z))
    return _tag["n"]

def transf(vecxz):
    _tag["t"] += 1
    ops.geomTransf("PDelta", _tag["t"], *vecxz)
    return _tag["t"]

T_HORIZ = transf((0, 1, 0))   # members in the X-Z plane: local z = global Y
T_VERT = transf((0, 1, 0))    # columns: local z = global Y, local y = global X
T_CAP = transf((1, 0, 0))     # cap beams along Y: local z = global X

def elastic(i, j, A, E, Iz, Iy, J, t, mass=0.0):
    _tag["e"] += 1
    ops.element("elasticBeamColumn", _tag["e"], i, j, A, E, G(E), J, Iy, Iz, t, "-mass", mass)
    return _tag["e"]

def rigid(i, j, t):
    return elastic(i, j, 50.0, 100 * E_45, 50.0, 50.0, 50.0, t)

# fibre sections (MODEL == "fibre")
SEC = {}
if MODEL == "fibre":
    ops.uniaxialMaterial("Concrete02", 1, -45e3, -0.0025, -9e3, -0.012, 0.1, 3.8e3, 1.9e5)   # arch C45/55, confined walls (ASSUMED)
    ops.uniaxialMaterial("Concrete02", 2, -30e3, -0.0025, -6e3, -0.012, 0.1, 2.9e3, 1.6e5)   # columns C30/37
    ops.uniaxialMaterial("Steel02", 3, 500e3, 2.1e8, 0.01, 18.0, 0.925, 0.15)                 # B500 (Table 5)

    def box_fibre(tag, W, D, tw, tf, conc, Ec, J, rho=0.04):
        ops.section("Fiber", tag, "-GJ", G(Ec) * J)
        # local y = depth direction, local z = width direction
        ops.patch("rect", conc, 8, 2, -D / 2, -W / 2, D / 2, -W / 2 + tw)           # web 1
        ops.patch("rect", conc, 8, 2, -D / 2, W / 2 - tw, D / 2, W / 2)             # web 2
        ops.patch("rect", conc, 2, 8, -D / 2, -W / 2 + tw, -D / 2 + tf, W / 2 - tw) # flange 1
        ops.patch("rect", conc, 2, 8, D / 2 - tf, -W / 2 + tw, D / 2, W / 2 - tw)   # flange 2
        As = rho * (W * D - (W - 2 * tw) * (D - 2 * tf))
        n = 40
        c = 0.06
        per = As / n
        ops.layer("straight", 3, n // 4, per, -D / 2 + c, -W / 2 + c, -D / 2 + c, W / 2 - c)
        ops.layer("straight", 3, n // 4, per, D / 2 - c, -W / 2 + c, D / 2 - c, W / 2 - c)
        ops.layer("straight", 3, n // 4, per, -D / 2 + c, -W / 2 + c, D / 2 - c, -W / 2 + c)
        ops.layer("straight", 3, n // 4, per, -D / 2 + c, W / 2 - c, D / 2 - c, W / 2 - c)

    box_fibre(1, 8.0, ARCH_D, 0.5, 0.4, 1, E_45, ARCH[3])
    box_fibre(2, 1.8, 1.5, 0.3, 0.3, 2, E_30, COL[3])
    box_fibre(3, 1.8, 2.4, 0.3, 0.3, 2, E_30, COL_BIG[3])
    for s in (1, 2, 3):
        ops.beamIntegration("Lobatto", s, s, 5)

MASS_GROUPS = {}

def member(i, j, kind, t):
    """kind: 'arch', 'col', 'colbig'. Elastic or fibre depending on MODEL."""
    props = {"arch": (ARCH, E_45, 1), "col": (COL, E_30, 2), "colbig": (COL_BIG, E_30, 3)}[kind]
    (A, I_dep, I_wid, J), E, s = props
    ci, cj = np.array(ops.nodeCoord(i)), np.array(ops.nodeCoord(j))
    if kind == "arch":
        A, I_dep, I_wid, J = box(8.0, ARCH_D, 0.5, arch_tf(0.5 * (ci[0] + cj[0])))
    m = RHO * A + (ARCH_EXTRA_MASS if kind == "arch" else COL_EXTRA_MASS)
    grp = "arch" if kind == "arch" else "columns"
    MASS_GROUPS[grp] = MASS_GROUPS.get(grp, 0.0) + m * np.linalg.norm(cj - ci)
    if MODEL == "fibre":
        _tag["e"] += 1
        ops.element("forceBeamColumn", _tag["e"], i, j, t, s, "-mass", m)
        return _tag["e"]
    if kind == "arch":   # local y = vertical (depth), local z = transverse
        return elastic(i, j, A, E, I_dep, I_wid, J, t, m)
    return elastic(i, j, A, E, I_dep, I_wid, J, t, m)  # columns: local y = X (depth D), local z = Y (width W)

# --- arch
col_x = {k: k * SPAN_DECK for k in range(1, 10)}
on_arch = [k for k in col_x if X_SPR_L < col_x[k] < X_SPR_R]
xs = np.unique(np.r_[np.linspace(X_SPR_L, X_SPR_R, N_ARCH_EL + 1), [col_x[k] for k in on_arch]])
arch_nodes = [node(x, 0.0, arch_z(x)) for x in xs]
for a, b in zip(arch_nodes[:-1], arch_nodes[1:]):
    member(a, b, "arch", T_HORIZ)
ops.fix(arch_nodes[0], 1, 1, 1, 1, 1, 1)
ops.fix(arch_nodes[-1], 1, 1, 1, 1, 1, 1)
arch_at = {k: arch_nodes[int(np.argmin(abs(xs - col_x[k])))] for k in on_arch}

# --- columns, caps, deck connection
deck_x = np.linspace(0.0, N_SPANS * SPAN_DECK, N_SPANS * N_DECK_EL + 1)
deck_nodes = [node(x, 0.0, Z_DECK) for x in deck_x]
deck_at = {k: deck_nodes[k * N_DECK_EL] for k in range(0, N_SPANS + 1)}
for a, b in zip(deck_nodes[:-1], deck_nodes[1:]):
    elastic(a, b, A_D, E_DECK, I_DV, I_DT, J_D, T_HORIZ, DECK_MASS_FACTOR * RHO * A_D + SURF_MASS)
MASS_GROUPS["deck (slab + girders)"] = DECK_MASS_FACTOR * RHO * A_D * N_SPANS * SPAN_DECK
MASS_GROUPS["surfacing"] = SURF_MASS * N_SPANS * SPAN_DECK
MASS_GROUPS["cross girders"] = CROSS_GIRDER_MASS * 11
# deck torsional mass moment (slab + girders + surfacing over 10.2 m width)
m_line = DECK_MASS_FACTOR * RHO * A_D + SURF_MASS
for n_ in deck_nodes:
    h = SPAN_DECK / N_DECK_EL
    ops.mass(n_, 0, 0, 0, m_line * h * 10.2**2 / 12, 0, 0)
# abutments: free longitudinally, fixed transversely and vertically (Farahani)
for k in (0, N_SPANS):
    ops.fix(deck_at[k], 0, 1, 1, 1, 0, 0)

ops.uniaxialMaterial("Elastic", 100, 1e9)   # stiff spring for bearings / monolithic joints
for k in range(1, 10):
    x = col_x[k]
    kind = "colbig" if k in BIG_COLS else "col"
    cap_nodes = []
    for y in (-Y_COL, Y_COL):
        if k in on_arch:
            top_arch = node(x, y, arch_z(x) + ARCH_D / 2)
            # arch centroid -> wall top under the column: rigid offset (Y and Z)
            off = node(x, 0.0, arch_z(x) + ARCH_D / 2)
            rigid(arch_at[k], off, T_VERT)
            rigid(off, top_arch, T_CAP)
            base = top_arch
        else:
            base = node(x, y, COL_BASE[k])
            ops.fix(base, 1, 1, 1, 1, 1, 1)
        z0 = ops.nodeCoord(base)[2]
        h = Z_CAP - z0
        if h <= 0.3:
            raise ValueError(f"C{k}: no room for a column (arch top above cap level)")
        zz = np.linspace(z0, Z_CAP, N_COL_EL + 1)
        prev = base
        for z in zz[1:]:
            cur = node(x, y, z)
            member(prev, cur, kind, T_VERT)
            prev = cur
        cap_nodes.append(prev)
    # cap beam between the two column heads (overhang mass lumped)
    capm = node(x, 0.0, Z_CAP)
    A_c = CAP[0]
    elastic(cap_nodes[0], capm, A_c, E_30, CAP[1], CAP[2], CAP[3], T_CAP, RHO * A_c)
    elastic(capm, cap_nodes[1], A_c, E_30, CAP[1], CAP[2], CAP[3], T_CAP, RHO * A_c)
    MASS_GROUPS["caps"] = MASS_GROUPS.get("caps", 0.0) + RHO * A_c * CAP_LEN
    for cn in cap_nodes:
        ops.mass(cn, *(3 * [RHO * A_c * 0.9]), 0, 0, 0)
    # bearings / monolithic joints at y = +/-Y_COL
    for cn in cap_nodes:
        y = ops.nodeCoord(cn)[1]
        b_bot = node(x, y, Z_BRG)
        b_top = node(x, y, Z_BRG)
        rigid(cn, b_bot, T_VERT)
        rigid(b_top, deck_at[k], T_CAP)   # inclined offset bearing -> deck spine (in the Y-Z plane)
        _tag["e"] += 1
        if k in MONOLITHIC:
            ops.element("zeroLength", _tag["e"], b_bot, b_top, "-mat", *([100] * 6), "-dir", 1, 2, 3, 4, 5, 6)
        else:  # longitudinally (and transversely) fixed pot bearing, rotations free
            dirs = (1, 2, 3, 4, 5, 6) if BEARING_ROT_FIXED else (1, 2, 3)
            ops.element("zeroLength", _tag["e"], b_bot, b_top, "-mat", *([100] * len(dirs)), "-dir", *dirs)
    ops.mass(deck_at[k], *(3 * [CROSS_GIRDER_MASS]), 0, 0, 0)
for k in (0, N_SPANS):
    ops.mass(deck_at[k], *(3 * [CROSS_GIRDER_MASS]), 0, 0, 0)

# ----------------------------------------------------------------------------- run
def total_mass():
    m = 0.0
    for n_ in ops.getNodeTags():
        m += ops.nodeMass(n_, 1)
    return m

if __name__ == "__main__":
    # eigen on the initial tangent (gravity stage and IDA drivers come in the next script)
    ops.constraints("Transformation")
    ops.numberer("RCM")
    ops.system("UmfPack")
    N = int(sys.argv[2]) if len(sys.argv) > 2 else 15
    lam = ops.eigen(N)
    props = ops.modalProperties("-unorm", "-return")
    print(f"Total mass (lumped, from modalProperties): {props['totalMass'][0]:.0f} t")
    for g_, m_ in MASS_GROUPS.items():
        print(f"   {g_:24s} {m_:7.0f} t")
    print(f"{'mode':>4} {'f (Hz)':>8} {'T (s)':>7} {'MX %':>6} {'MY %':>6} {'MZ %':>6}")
    for i in range(N):
        f = np.sqrt(lam[i]) / 2 / np.pi
        print(f"{i+1:4d} {f:8.3f} {1/f:7.3f} {props['partiMassRatiosMX'][i]:6.1f} "
              f"{props['partiMassRatiosMY'][i]:6.1f} {props['partiMassRatiosMZ'][i]:6.1f}")
