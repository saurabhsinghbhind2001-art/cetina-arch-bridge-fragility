"""Extension of the multi-support IDA (run_mse.py) to the other 10 far-field records with a vertical component, at the
base-case apparent wave speed of 1000 m/s, with the uniform committed-stiffness reference on the same records.
Same job(), climbing, fallbacks and collapse / non-convergence rules as run_mse.py; results go to the same folders
(ida_results_mse/mse_va1000 and uniform_kcomm). Support motions: ground_motions/svgm_ext (svgm.py, same settings).
Run: python run_mse_ext.py <project folder arch-bridge-review> [workers]"""
import json, os, sys
from concurrent.futures import ProcessPoolExecutor, as_completed

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from run_mse import job

RECORDS = ["RSN900", "RSN848", "RSN752", "RSN767", "RSN1633", "RSN721", "RSN1244", "RSN1485", "RSN68", "RSN125"]


def main(root, workers=None):
    root = os.path.abspath(root)   # job() runs nltha.py with cwd = opensees/
    gm = os.path.join(root, "ground_motions")
    out = os.path.join(root, "ida_results_mse")
    recs = {r["name"]: r for r in json.load(open(os.path.join(gm, "ida36", "processed", "records.json")))["records"]}
    mse, uni = [], []
    for name in RECORDS:
        lv = sorted(recs[name]["scale"].items(), key=lambda x: float(x[0]))
        mse.append((os.path.join(gm, "svgm_ext", f"{name}_va1000.npz"), name, lv, "mse_va1000", out, {}))
        uni.append((os.path.join(gm, "ida36", "processed", f"{name}.csv"), name, lv, "uniform_kcomm", out,
                    {"NLTHA_DAMPING": "kcomm"}))
    with ProcessPoolExecutor(max_workers=workers or os.cpu_count()) as ex:
        for fut in as_completed([ex.submit(job, *j) for j in mse + uni]):
            name, case, done = fut.result()
            first = next((lv for lv, col in done if col), None)
            print(f"{name:8s} {case:13s} levels {len(done)}  first collapse at Sa {first} g", flush=True)


if __name__ == "__main__":
    main(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else None)
