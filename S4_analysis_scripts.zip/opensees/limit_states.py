"""Column limit states for the fragility analysis, from moment-curvature analysis of the fibre sections of the model.
Strain limits (Priestley, Calvi & Kowalsky 2007; hollow walls capped at the Concrete02 ultimate strain of the model):
  slight    first yield of the longitudinal bars        eps_s = fy/Es
  moderate  cover spalling                               eps_c = 0.004
  extensive core crushing or damage-control steel strain eps_c = 0.012 (hollow-wall cap) or eps_s = 0.06 (0.6 eps_su)
  complete  ultimate                                     eps_c = 0.018 (1.5 x extensive) or eps_s = 0.09 (0.9 eps_su)
Curvature -> chord drift with a plastic hinge (Priestley et al. 2007): theta = phi_y Ls / 3 + (phi - phi_y) Lp,
Lp = max(0.08 Ls + 0.022 fy db, 0.044 fy db) (fy in MPa, db in m), Ls the shear span:
  longitudinal: C4-C7 sit on pinned bearings -> cantilever, Ls = H; C1-C3, C8, C9 are monolithic with the deck -> Ls = H/2
  transverse:   two legs and the cap form a portal -> Ls = H/2 for every column
Axial load: the gravity load of each leg from the model. db = 32 mm is ASSUMED (bar size not known).
Shear capacity of the legs (Priestley, Verma & Xiao 1994, mean strength): V = Vc + Vs + Vp with
  Vc = k sqrt(fc) Ae, Ae = 0.8 x web area, k = 0.29 MPa^0.5 at displacement ductility <= 2 falling to 0.10 at >= 4,
  Vs = Asw fyh D' cot(30 deg) / s, Vp = N (D - c) / (2 Ls).
  Hoops Phi14@100 (Farahani p. 612). 4 legs per shear direction ASSUMED: an outer and an inner hoop in each of the
  two walls parallel to the shear (hollow box; the ANSYS model has the longitudinal bars only).
  The Eurocode truss value (cot theta = 1, z = 0.9 d) is given beside it as the lower bound.
Run: python limit_states.py <out.json>"""
import json, os, sys
import numpy as np

OUT = sys.argv[1]
sys.argv = ["cetina_model.py", "fibre", "0", "v3", "pinned"]
import openseespy.opensees as _ops

_ELE_MASS = {}
_ELE_TYPE = {}
_element = _ops.element


def _record(*a):
    _ELE_TYPE[a[1]] = a[0]
    if "-mass" in a:
        _ELE_MASS[a[1]] = (a[2], a[3], float(a[a.index("-mass") + 1]))
    return _element(*a)


_ops.element = _record
import cetina_model as cm
_ops.element = _element
ops = cm.ops

FY, ES, FC = 500.0, 210000.0, 30.0       # MPa
DB = float(os.environ.get("LS_DB", 0.032))   # m, ASSUMED: 4 % of a 1.62 m2 hollow leg is about 80 bars of 32 mm
LP_FACTOR = float(os.environ.get("LS_LP_FACTOR", 1.0))   # sensitivity only: scales every plastic hinge length
COVER_C = 0.06                            # bar centre from the face (as in box_fibre)
HOOP_A, HOOP_S, HOOP_LEGS = 154e-6, 0.10, int(os.environ.get("LS_HOOP_LEGS", 4))
STRAIN = {"slight": (None, FY / ES), "moderate": (0.004, None), "extensive": (0.012, 0.06), "complete": (0.018, 0.09)}
SEC = {"col": dict(W=1.8, D=1.5, tw=0.3, tf=0.3, conc=2), "colbig": dict(W=1.8, D=2.4, tw=0.3, tf=0.3, conc=2),
       "arch": dict(W=8.0, D=2.5, tw=0.5, tf=0.4, conc=1)}   # W transverse, D longitudinal (columns) or vertical (arch)
ARCH_STRAIN = {"slight": (None, FY / ES), "moderate": (0.004, None), "extensive": (0.012, 0.06), "complete": (0.018, 0.09)}
MONOLITHIC = (1, 2, 3, 8, 9)

# --- gravity axial load per leg (as nltha.py: nodal mass plus half of each element mass at each end)
coord = {n: np.array(ops.nodeCoord(n)) for n in ops.getNodeTags()}
mass = {n: ops.nodeMass(n, 1) for n in coord}
for i, j, m in _ELE_MASS.values():
    L = np.linalg.norm(coord[i] - coord[j])
    mass[i] += 0.5 * m * L
    mass[j] += 0.5 * m * L
ops.constraints("Transformation"); ops.numberer("RCM"); ops.system("UmfPack")
ops.timeSeries("Linear", 1); ops.pattern("Plain", 1, 1)
for n, m in mass.items():
    if m > 0:
        ops.load(n, 0, 0, -m * 9.81, 0, 0, 0)
ops.test("NormDispIncr", 1e-8, 50); ops.algorithm("Newton"); ops.integrator("LoadControl", 0.1); ops.analysis("Static")
assert ops.analyze(10) == 0
legs = {}
for e in [e for e, typ in _ELE_TYPE.items() if typ == "forceBeamColumn"]:
    i, j = ops.eleNodes(e)
    if abs(coord[i][0] - coord[j][0]) < 1e-6 and abs(coord[i][1] - coord[j][1]) < 1e-6 and abs(coord[i][1]) > 1:
        k = int(round(coord[i][0] / cm.SPAN_DECK))
        key = (k, "L" if coord[i][1] < 0 else "R")
        top = max(coord[i][2], coord[j][2])
        lo = min(coord[i][2], coord[j][2])
        if key not in legs:
            legs[key] = [e, lo, top]
        elif lo < legs[key][1]:
            legs[key][:2] = [e, lo]
        legs[key][2] = max(legs[key][2], top)
N_leg = {key: ops.eleResponse(v[0], "localForce")[0] for key, v in legs.items()}   # node-i axial force: compression positive
H_leg = {key: v[2] - v[1] for key, v in legs.items()}
arch_set = set(cm.arch_nodes)
arch_els = sorted((e for e, typ in _ELE_TYPE.items() if typ == "forceBeamColumn" and set(ops.eleNodes(e)) <= arch_set),
                  key=lambda e: coord[ops.eleNodes(e)[0]][0])
N_spr = ops.eleResponse(arch_els[0], "localForce")[0]   # axial compression at the left springing
L_spr_el = float(np.linalg.norm(coord[ops.eleNodes(arch_els[0])[1]] - coord[ops.eleNodes(arch_els[0])[0]]))


# --- moment-curvature of one section under axial compression N (kN)
def mphi(sec, N, axis):
    """axis 'long': bending from longitudinal sway (depth D, local y); 'trans': transverse sway (depth W, local z)."""
    ops.wipe()
    ops.model("basic", "-ndm", 3, "-ndf", 6)
    ops.uniaxialMaterial("Concrete02", 1, -45e3, -0.0025, -9e3, -0.012, 0.1, 3.8e3, 1.9e5)   # as cetina_model.py
    ops.uniaxialMaterial("Concrete02", 2, -30e3, -0.0025, -6e3, -0.012, 0.1, 2.9e3, 1.6e5)
    ops.uniaxialMaterial("Steel02", 3, 500e3, 2.1e8, 0.01, 18.0, 0.925, 0.15)
    s = SEC[sec]
    cm.box_fibre(1, s["W"], s["D"], s["tw"], s["tf"], s["conc"], cm.E_30, 1.0)
    ops.node(1, 0, 0, 0); ops.node(2, 0, 0, 0)
    ops.fix(1, 1, 1, 1, 1, 1, 1)
    dof = 6 if axis == "long" else 5           # rotation about local z (curvature kz, depth along y) or about y
    fixed = [1, 1, 1, 1, 1, 1]
    fixed[0] = 0; fixed[dof - 1] = 0
    ops.fix(2, *fixed)
    ops.element("zeroLengthSection", 1, 1, 2, 1)
    ops.timeSeries("Constant", 1); ops.pattern("Plain", 1, 1); ops.load(2, -N, 0, 0, 0, 0, 0)
    ops.system("BandGeneral"); ops.numberer("Plain"); ops.constraints("Plain")
    ops.test("NormDispIncr", 1e-9, 50); ops.algorithm("Newton"); ops.integrator("LoadControl", 1.0); ops.analysis("Static")
    ops.analyze(1)
    ops.timeSeries("Linear", 2); ops.pattern("Plain", 2, 2); ops.load(2, 0, 0, 0, 0, *( (0, 1) if dof == 6 else (1, 0) ))
    depth = s["D"] if axis == "long" else s["W"]
    dk = 2e-6 * 1.5 / depth
    ops.integrator("DisplacementControl", 2, dof, dk); ops.analysis("Static")
    out = []
    for _ in range(int(0.08 / dk)):
        if ops.analyze(1) != 0:
            break
        k = ops.nodeDisp(2, dof)
        e0 = ops.nodeDisp(2, 1)
        M = ops.getLoadFactor(2)
        ec = e0 - abs(k) * depth / 2            # extreme concrete (compression negative)
        es = e0 + abs(k) * (depth / 2 - COVER_C) # extreme tension bar
        out.append((abs(k), M, ec, es))
    return np.array(out)


def limits(sec, N, axis):
    a = mphi(sec, N, axis)
    res = {}
    for ds, (ec_lim, es_lim) in STRAIN.items():
        hit = np.zeros(len(a), bool)
        if ec_lim is not None:
            hit |= -a[:, 2] >= ec_lim
        if es_lim is not None:
            hit |= a[:, 3] >= es_lim
        i = int(np.argmax(hit)) if hit.any() else len(a) - 1
        res[ds] = (float(a[i, 0]), float(a[i, 1]))
    return res, a


def drift(phi, phi_y, Ls):
    Lp = LP_FACTOR * max(0.08 * Ls + 0.022 * FY * DB, 0.044 * FY * DB)
    return phi_y * Ls / 3 + max(phi - phi_y, 0.0) * Lp


def shear_capacity(sec, N, Ls, axis, mu):
    s = SEC[sec]
    D = s["D"] if axis == "long" else s["W"]     # section depth in the direction of the shear
    L_web = D                                      # the two walls parallel to the shear
    Ae = 0.8 * 2 * 0.3 * L_web
    k = 0.29 if mu <= 2 else max(0.10, 0.29 - (mu - 2) * (0.19 / 2))
    Vc = k * np.sqrt(FC) * Ae * 1e3                # kN
    Dp = D - 2 * (COVER_C - 0.02)
    Vs = HOOP_LEGS * HOOP_A * FY * 1e3 * Dp / HOOP_S / np.tan(np.radians(30))
    Vp = max(N, 0) * (D - 0.25 * D) / (2 * Ls)    # neutral axis depth taken as D/4
    Vec = HOOP_LEGS * HOOP_A * FY * 1e3 * 0.9 * (D - COVER_C) / HOOP_S
    return dict(Vc=Vc, Vs=Vs, Vp=Vp, V=Vc + Vs + Vp, V_EC_truss=Vec)


res = {}
for (k, side), N in sorted(N_leg.items()):
    if side != "L":
        continue
    sec = "colbig" if k in cm.BIG_COLS else "col"
    H = H_leg[(k, side)]
    row = dict(section=sec, H_m=round(H, 3), N_kN=round(N))
    for axis, Ls in (("long", H / 2 if k in MONOLITHIC else H), ("trans", H / 2)):
        lim, _ = limits(sec, N, axis)
        phi_y = lim["slight"][0]
        row[axis] = dict(Ls_m=round(Ls, 3),
                         curvature_1pm={ds: round(v[0], 5) for ds, v in lim.items()},
                         moment_kNm={ds: round(v[1]) for ds, v in lim.items()},
                         drift={ds: round(drift(v[0], phi_y, Ls), 5) for ds, v in lim.items()},
                         shear_flexure_kN=round(lim["extensive"][1] / Ls),   # shear when the hinge(s) reach the extensive moment
                         shear_capacity_mu1={q: round(v) for q, v in shear_capacity(sec, N, Ls, axis, 1).items()},
                         shear_capacity_mu4={q: round(v) for q, v in shear_capacity(sec, N, Ls, axis, 4).items()})
    res[f"C{k}"] = row
    print(f"C{k} {sec} H {H:.2f} m N {N:.0f} kN")
    for axis in ("long", "trans"):
        r = row[axis]
        print(f"   {axis:5s} Ls {r['Ls_m']:.2f}  drift % " + " ".join(f"{d}:{v * 100:.2f}" for d, v in r["drift"].items()) +
              f"  V_flex {r['shear_flexure_kN']}  V_cap mu1 {r['shear_capacity_mu1']['V']} mu4 {r['shear_capacity_mu4']['V']} EC {r['shear_capacity_mu1']['V_EC_truss']}")
# arch springing sections: curvature limits (the IDA records springing curvatures directly)
# the force-based springing element localizes in its end integration point once the section softens (weight L/20 for
# 5-point Lobatto), so its curvature is not objective; fragility.py spreads the plastic part over a hinge length
# Lp = 0.5 x section depth: kappa_hinge = kappa_y + (kappa_ip - kappa_y) (L/20) / Lp
row = dict(section="arch", N_kN=round(N_spr), element_length_m=round(L_spr_el, 3), ip_weight_m=round(L_spr_el / 20, 4),
           hinge_length_m={"vertical": LP_FACTOR * 0.5 * SEC["arch"]["D"], "transverse": LP_FACTOR * 0.5 * SEC["arch"]["W"]})
for axis in ("long", "trans"):          # long = vertical bending (depth 2.5 m), trans = transverse bending (width 8 m)
    lim, _ = limits("arch", N_spr, axis)
    row["vertical" if axis == "long" else "transverse"] = dict(curvature_1pm={ds: round(v[0], 6) for ds, v in lim.items()},
                                                               moment_kNm={ds: round(v[1]) for ds, v in lim.items()})
res["arch_springing"] = row
print(f"arch springing N {N_spr:.0f} kN")
for ax in ("vertical", "transverse"):
    print(f"   {ax:10s} curvature 1/m " + " ".join(f"{d}:{v:.2e}" for d, v in row[ax]["curvature_1pm"].items()))
json.dump(res, open(OUT, "w"), indent=1)
