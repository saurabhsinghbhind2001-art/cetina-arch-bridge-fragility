"""Parallel IDA driver: every record of ground_motions/ida36/records.json at every Sa(T1) level, through nltha.py.
One job is one record and case, run up the levels in order; a job stops climbing once a run fails to converge or
a column drift passes 5 % (both read as collapse; a run that stops early is first repeated with displacement-based
C5/C6 legs, see nltha.py), and the higher levels are recorded as collapsed without running.
Finished runs are skipped on a restart, so the driver can be stopped and started again.
Run: python run_ida.py <ida36 folder> <out folder> [cases, default xyz,xy] [workers, default all cores]"""
import json, os, subprocess, sys
from concurrent.futures import ProcessPoolExecutor, as_completed

HERE = os.path.dirname(os.path.abspath(__file__))
COLLAPSE_DRIFT = 0.05
TIMEOUT_S = 3600   # a run that has not finished in an hour is stuck in the fallback solvers and counts as non-converged


def job(rec_csv, name, scales, case, out):
    done = []
    collapsed = False
    for level, sf in scales:
        f = os.path.join(out, case, f"{name}_sa{level}.json")
        if collapsed:
            json.dump({"record": name, "case": case, "sa_g": float(level), "scale": sf, "collapsed": True,
                       "skipped": True}, open(f, "w"))
            continue
        def run(extra):
            try:
                subprocess.run([sys.executable, os.path.join(HERE, "nltha.py"), rec_csv, str(sf), case, f] + extra,
                               cwd=HERE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=TIMEOUT_S)
            except subprocess.TimeoutExpired:
                pass
        if not os.path.exists(f):
            run([])
        if os.path.exists(f):   # a force-based run that stopped early is repeated with disp-based C5/C6 legs
            r = json.load(open(f))
            if not (r.get("completed") or r.get("skipped") or r.get("disp56")):
                run(["disp56"])
        else:
            run(["disp56"])
        if not os.path.exists(f):
            r = {"record": name, "case": case, "scale": sf, "completed": False}
            json.dump(r, open(f, "w"))
        r = json.load(open(f))
        drift = max(list(r.get("drift_x", {}).values()) + list(r.get("drift_y", {}).values()) + [0.0])
        collapsed = r.get("skipped", False) or not r.get("completed", False) or drift > COLLAPSE_DRIFT
        if collapsed and not r.get("collapsed"):
            r["collapsed"] = True
            json.dump(r, open(f, "w"), indent=1)
        done.append((level, collapsed))
    return name, case, done


def main(ida, out, cases=("xyz", "xy"), workers=None):
    recs = json.load(open(os.path.join(ida, "records.json")))["records"]
    for c in cases:
        os.makedirs(os.path.join(out, c), exist_ok=True)
    jobs = [(os.path.join(ida, r["name"] + ".csv"), r["name"], sorted(r["scale"].items(), key=lambda x: float(x[0])), c, out)
            for c in cases for r in recs if c != "xyz" or r.get("has_vertical", True)]   # 723 and 725 have no vertical: xy only
    with ProcessPoolExecutor(max_workers=workers or os.cpu_count()) as ex:
        for fut in as_completed([ex.submit(job, *j) for j in jobs]):
            name, case, done = fut.result()
            first = next((lv for lv, col in done if col), None)
            print(f"{name:8s} {case:3s} levels {len(done)}  first collapse at Sa {first} g", flush=True)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], tuple(sys.argv[3].split(",")) if len(sys.argv) > 3 else ("xyz", "xy"),
         int(sys.argv[4]) if len(sys.argv) > 4 else None)
